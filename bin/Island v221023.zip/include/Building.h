#ifndef INCLUDED_Building
#define INCLUDED_Building

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Building)


class Building_obj : public ::hx::EnumBase_obj
{
	typedef ::hx::EnumBase_obj super;
		typedef Building_obj OBJ_;

	public:
		Building_obj() {};
		HX_DO_ENUM_RTTI;
		static void __boot();
		static void __register();
		static bool __GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::String GetEnumName( ) const { return HX_("Building",94,9e,79,2d); }
		::String __ToString() const { return HX_("Building.",1a,23,f1,9c) + _hx_tag; }

		static ::Building Blacksmith;
		static inline ::Building Blacksmith_dyn() { return Blacksmith; }
		static ::Building Farm;
		static inline ::Building Farm_dyn() { return Farm; }
		static ::Building House;
		static inline ::Building House_dyn() { return House; }
		static ::Building Mine;
		static inline ::Building Mine_dyn() { return Mine; }
		static ::Building Port;
		static inline ::Building Port_dyn() { return Port; }
		static ::Building Sawmill;
		static inline ::Building Sawmill_dyn() { return Sawmill; }
		static ::Building Temple;
		static inline ::Building Temple_dyn() { return Temple; }
};


#endif /* INCLUDED_Building */ 
