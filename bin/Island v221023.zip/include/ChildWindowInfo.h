#ifndef INCLUDED_ChildWindowInfo
#define INCLUDED_ChildWindowInfo

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(ChildWindowInfo)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)



class HXCPP_CLASS_ATTRIBUTES ChildWindowInfo_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef ChildWindowInfo_obj OBJ_;
		ChildWindowInfo_obj();

	public:
		enum { _hx_ClassId = 0x5745e65a };

		void __construct( ::TextWindow child,::hx::Null< int >  __o_pfrow,::hx::Null< int >  __o_pfcol, ::Dynamic __o_dFRow, ::Dynamic __o_dFCol, ::Dynamic dRows, ::Dynamic dCols,::hx::Null< bool >  __o_isVisible);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="ChildWindowInfo")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"ChildWindowInfo"); }
		static ::hx::ObjectPtr< ChildWindowInfo_obj > __new( ::TextWindow child,::hx::Null< int >  __o_pfrow,::hx::Null< int >  __o_pfcol, ::Dynamic __o_dFRow, ::Dynamic __o_dFCol, ::Dynamic dRows, ::Dynamic dCols,::hx::Null< bool >  __o_isVisible);
		static ::hx::ObjectPtr< ChildWindowInfo_obj > __alloc(::hx::Ctx *_hx_ctx, ::TextWindow child,::hx::Null< int >  __o_pfrow,::hx::Null< int >  __o_pfcol, ::Dynamic __o_dFRow, ::Dynamic __o_dFCol, ::Dynamic dRows, ::Dynamic dCols,::hx::Null< bool >  __o_isVisible);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~ChildWindowInfo_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("ChildWindowInfo",1a,01,1f,8b); }

		 ::TextWindow window;
		int parentFirstRow;
		int parentFirstColumn;
		int displayFirstRow;
		int displayFirstColumn;
		int displayRows;
		int displayColumns;
		bool isVisible;
};


#endif /* INCLUDED_ChildWindowInfo */ 
