#ifndef INCLUDED_ColoredChar
#define INCLUDED_ColoredChar

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(ColoredChar)



class HXCPP_CLASS_ATTRIBUTES ColoredChar_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef ColoredChar_obj OBJ_;
		ColoredChar_obj();

	public:
		enum { _hx_ClassId = 0x3f77f998 };

		void __construct(::String __o__hx_char,::String __o_color);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="ColoredChar")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"ColoredChar"); }
		static ::hx::ObjectPtr< ColoredChar_obj > __new(::String __o__hx_char,::String __o_color);
		static ::hx::ObjectPtr< ColoredChar_obj > __alloc(::hx::Ctx *_hx_ctx,::String __o__hx_char,::String __o_color);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~ColoredChar_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("ColoredChar",58,b4,7c,8c); }

		::String _hx_char;
		::String ansiColor;
};


#endif /* INCLUDED_ColoredChar */ 
