#ifndef INCLUDED_DescIter
#define INCLUDED_DescIter

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_STACK_FRAME(_hx_pos_50cb22b8a8f8fc03_62_new)
HX_DECLARE_CLASS0(DescIter)



class HXCPP_CLASS_ATTRIBUTES DescIter_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef DescIter_obj OBJ_;
		DescIter_obj();

	public:
		enum { _hx_ClassId = 0x213dfae9 };

		void __construct(int max,int min);
		inline void *operator new(size_t inSize, bool inContainer=false,const char *inName="DescIter")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,false,"DescIter"); }

		inline static ::hx::ObjectPtr< DescIter_obj > __new(int max,int min) {
			::hx::ObjectPtr< DescIter_obj > __this = new DescIter_obj();
			__this->__construct(max,min);
			return __this;
		}

		inline static ::hx::ObjectPtr< DescIter_obj > __alloc(::hx::Ctx *_hx_ctx,int max,int min) {
			DescIter_obj *__this = (DescIter_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(DescIter_obj), false, "DescIter"));
			*(void **)__this = DescIter_obj::_hx_vtable;
{
            	HX_STACKFRAME(&_hx_pos_50cb22b8a8f8fc03_62_new)
HXLINE(  63)		( ( ::DescIter)(__this) )->at = max;
HXLINE(  64)		( ( ::DescIter)(__this) )->end = min;
            	}
		
			return __this;
		}

		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~DescIter_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("DescIter",29,08,ad,c5); }

		int end;
		int at;
		bool hasNext();
		::Dynamic hasNext_dyn();

		int next();
		::Dynamic next_dyn();

};


#endif /* INCLUDED_DescIter */ 
