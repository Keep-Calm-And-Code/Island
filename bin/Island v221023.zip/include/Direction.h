#ifndef INCLUDED_Direction
#define INCLUDED_Direction

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Direction)


class Direction_obj : public ::hx::EnumBase_obj
{
	typedef ::hx::EnumBase_obj super;
		typedef Direction_obj OBJ_;

	public:
		Direction_obj() {};
		HX_DO_ENUM_RTTI;
		static void __boot();
		static void __register();
		static bool __GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::String GetEnumName( ) const { return HX_("Direction",1f,42,13,b2); }
		::String __ToString() const { return HX_("Direction.",2f,99,c6,1e) + _hx_tag; }

		static ::Direction Down;
		static inline ::Direction Down_dyn() { return Down; }
		static ::Direction Left;
		static inline ::Direction Left_dyn() { return Left; }
		static ::Direction Right;
		static inline ::Direction Right_dyn() { return Right; }
		static ::Direction Up;
		static inline ::Direction Up_dyn() { return Up; }
};


#endif /* INCLUDED_Direction */ 
