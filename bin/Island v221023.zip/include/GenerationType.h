#ifndef INCLUDED_GenerationType
#define INCLUDED_GenerationType

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(GenerationType)


class GenerationType_obj : public ::hx::EnumBase_obj
{
	typedef ::hx::EnumBase_obj super;
		typedef GenerationType_obj OBJ_;

	public:
		GenerationType_obj() {};
		HX_DO_ENUM_RTTI;
		static void __boot();
		static void __register();
		static bool __GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::String GetEnumName( ) const { return HX_("GenerationType",92,9f,63,12); }
		::String __ToString() const { return HX_("GenerationType.",5c,00,c8,04) + _hx_tag; }

		static ::GenerationType Empty;
		static inline ::GenerationType Empty_dyn() { return Empty; }
		static ::GenerationType Filled;
		static inline ::GenerationType Filled_dyn() { return Filled; }
		static ::GenerationType OneCell;
		static inline ::GenerationType OneCell_dyn() { return OneCell; }
		static ::GenerationType Random;
		static inline ::GenerationType Random_dyn() { return Random; }
};


#endif /* INCLUDED_GenerationType */ 
