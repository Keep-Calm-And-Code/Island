#ifndef INCLUDED_Grid
#define INCLUDED_Grid

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Cell)
HX_DECLARE_CLASS0(Grid)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)
HX_DECLARE_CLASS1(haxe,IMap)
HX_DECLARE_CLASS2(haxe,ds,StringMap)



class HXCPP_CLASS_ATTRIBUTES Grid_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Grid_obj OBJ_;
		Grid_obj();

	public:
		enum { _hx_ClassId = 0x0397f90a };

		void __construct(::String __o_name);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="Grid")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"Grid"); }
		static ::hx::ObjectPtr< Grid_obj > __new(::String __o_name);
		static ::hx::ObjectPtr< Grid_obj > __alloc(::hx::Ctx *_hx_ctx,::String __o_name);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Grid_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Grid",e6,02,45,2f); }

		::String name;
		 ::haxe::ds::StringMap cells;
		int size;
		::String activeCellKey;
		void addCellWithoutAdjacency( ::Cell cell,::String label);
		::Dynamic addCellWithoutAdjacency_dyn();

		virtual ::String set_activeCellKey(::String activeCell);
		::Dynamic set_activeCellKey_dyn();

		::String randomCellKey();
		::Dynamic randomCellKey_dyn();

};


#endif /* INCLUDED_Grid */ 
