#ifndef INCLUDED_HexGrid
#define INCLUDED_HexGrid

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

#ifndef INCLUDED_Grid
#include <Grid.h>
#endif
HX_DECLARE_CLASS0(Direction)
HX_DECLARE_CLASS0(Grid)
HX_DECLARE_CLASS0(HexGrid)
HX_DECLARE_CLASS0(Point2D)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)



class HXCPP_CLASS_ATTRIBUTES HexGrid_obj : public  ::Grid_obj
{
	public:
		typedef  ::Grid_obj super;
		typedef HexGrid_obj OBJ_;
		HexGrid_obj();

	public:
		enum { _hx_ClassId = 0x1b8f1c61 };

		void __construct(int gridRows,int gridCols,int cellRows,int cellCols,::String name);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="HexGrid")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"HexGrid"); }
		static ::hx::ObjectPtr< HexGrid_obj > __new(int gridRows,int gridCols,int cellRows,int cellCols,::String name);
		static ::hx::ObjectPtr< HexGrid_obj > __alloc(::hx::Ctx *_hx_ctx,int gridRows,int gridCols,int cellRows,int cellCols,::String name);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~HexGrid_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("HexGrid",21,77,6f,5b); }

		 ::TextWindow window;
		 ::TextWindow leftCellBracket;
		 ::TextWindow rightCellBracket;
		int gridRows;
		int gridCols;
		int cellRows;
		int cellCols;
		::String set_activeCellKey(::String key);

		bool isValidPoint(::String key);
		::Dynamic isValidPoint_dyn();

		::String toCellKey(int x,int y);
		::Dynamic toCellKey_dyn();

		 ::Dynamic toCellX(::String key);
		::Dynamic toCellX_dyn();

		 ::Dynamic toCellY(::String key);
		::Dynamic toCellY_dyn();

		int getRowFromCoords(int x,int y);
		::Dynamic getRowFromCoords_dyn();

		int getColumnFromCoords(int x,int y);
		::Dynamic getColumnFromCoords_dyn();

		void fillWithCells();
		::Dynamic fillWithCells_dyn();

		::Array< ::Dynamic> allCellCoords();
		::Dynamic allCellCoords_dyn();

		 ::Dynamic distanceSquaredToCell(::String from,::String to);
		::Dynamic distanceSquaredToCell_dyn();

		 ::Dynamic angleToCell(::String from,::String to);
		::Dynamic angleToCell_dyn();

		 ::Dynamic isLeftOf(::String to,::String from);
		::Dynamic isLeftOf_dyn();

		 ::Dynamic isRightOf(::String to,::String from);
		::Dynamic isRightOf_dyn();

		 ::Dynamic isUpOf(::String to,::String from);
		::Dynamic isUpOf_dyn();

		 ::Dynamic isDownOf(::String to,::String from);
		::Dynamic isDownOf_dyn();

		 ::Dynamic isInDirectionOf(::String to, ::Direction dir,::String from);
		::Dynamic isInDirectionOf_dyn();

		::String closestCellInDirection(::String p, ::Direction dir);
		::Dynamic closestCellInDirection_dyn();

		::String closestCellLeft(::String p);
		::Dynamic closestCellLeft_dyn();

		::String closestCellRight(::String p);
		::Dynamic closestCellRight_dyn();

		::String closestCellUp(::String p);
		::Dynamic closestCellUp_dyn();

		::String closestCellDown(::String p);
		::Dynamic closestCellDown_dyn();

		::Array< ::String > potentialNeighbors(::String key);
		::Dynamic potentialNeighbors_dyn();

		::Array< ::String > cellKeysWithPotentialNeighbors();
		::Dynamic cellKeysWithPotentialNeighbors_dyn();

		void display();
		::Dynamic display_dyn();

};


#endif /* INCLUDED_HexGrid */ 
