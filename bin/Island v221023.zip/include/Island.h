#ifndef INCLUDED_Island
#define INCLUDED_Island

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Building)
HX_DECLARE_CLASS0(Cell)
HX_DECLARE_CLASS0(Direction)
HX_DECLARE_CLASS0(GenerationType)
HX_DECLARE_CLASS0(Grid)
HX_DECLARE_CLASS0(HexGrid)
HX_DECLARE_CLASS0(Island)
HX_DECLARE_CLASS0(IslandCell)
HX_DECLARE_CLASS0(MenuState)
HX_DECLARE_CLASS0(Pile)
HX_DECLARE_CLASS0(Terrain)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)
HX_DECLARE_CLASS1(haxe,IMap)
HX_DECLARE_CLASS2(haxe,ds,BalancedTree)
HX_DECLARE_CLASS2(haxe,ds,EnumValueMap)



class HXCPP_CLASS_ATTRIBUTES Island_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Island_obj OBJ_;
		Island_obj();

	public:
		enum { _hx_ClassId = 0x1019d5b5 };

		void __construct(int size, ::GenerationType type,::String name);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="Island")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"Island"); }
		static ::hx::ObjectPtr< Island_obj > __new(int size, ::GenerationType type,::String name);
		static ::hx::ObjectPtr< Island_obj > __alloc(::hx::Ctx *_hx_ctx,int size, ::GenerationType type,::String name);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Island_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Island",f5,12,cf,ae); }

		static void __boot();
		static  ::Dynamic __meta__;
		static int cellRows;
		static int cellCols;
		static int baseHappiness;
		static int maxHappinessFromFood;
		::String name;
		 ::TextScreen mainWindow;
		 ::HexGrid grid;
		 ::TextWindow infoWindow;
		 ::TextWindow commandWindow;
		 ::MenuState menuState;
		int size;
		int turn;
		int population;
		 ::Pile resources;
		 ::haxe::ds::EnumValueMap buildings;
		 ::Terrain randomTerrain();
		::Dynamic randomTerrain_dyn();

		void makeCell(int x,int y, ::Terrain terrain);
		::Dynamic makeCell_dyn();

		void generateEmpty();
		::Dynamic generateEmpty_dyn();

		void generateOneCell();
		::Dynamic generateOneCell_dyn();

		void generateFilled();
		::Dynamic generateFilled_dyn();

		void growIsland();
		::Dynamic growIsland_dyn();

		void generateRandom();
		::Dynamic generateRandom_dyn();

		void write(::String s, ::Dynamic r, ::Dynamic c);
		::Dynamic write_dyn();

		 ::IslandCell getCell(::String key);
		::Dynamic getCell_dyn();

		 ::IslandCell getActiveCell();
		::Dynamic getActiveCell_dyn();

		::String getActiveCellKey();
		::Dynamic getActiveCellKey_dyn();

		 ::haxe::ds::EnumValueMap countBuildings();
		::Dynamic countBuildings_dyn();

		int countTerrain( ::Terrain terrain);
		::Dynamic countTerrain_dyn();

		int countJobs();
		::Dynamic countJobs_dyn();

		 ::Pile costToUpgrade();
		::Dynamic costToUpgrade_dyn();

		 ::Pile costToBuild( ::Building b);
		::Dynamic costToBuild_dyn();

		bool isValidLocation( ::Building b,::String key);
		::Dynamic isValidLocation_dyn();

		bool isCoastCellKey(::String key);
		::Dynamic isCoastCellKey_dyn();

		void display();
		::Dynamic display_dyn();

		void inputLoop();
		::Dynamic inputLoop_dyn();

		void commandMove( ::Direction dir);
		::Dynamic commandMove_dyn();

		void commandBuild( ::Building b);
		::Dynamic commandBuild_dyn();

		void commandUpgrade();
		::Dynamic commandUpgrade_dyn();

		void commandNextTurn();
		::Dynamic commandNextTurn_dyn();

		void growPopulation();
		::Dynamic growPopulation_dyn();

		void shrinkPopulation(int deficit);
		::Dynamic shrinkPopulation_dyn();

		 ::Pile calculateIncome();
		::Dynamic calculateIncome_dyn();

		 ::Pile calculateCellProduction( ::IslandCell cell);
		::Dynamic calculateCellProduction_dyn();

		 ::Pile calculatePrimaryProduction();
		::Dynamic calculatePrimaryProduction_dyn();

		 ::Pile calculateSecondaryProduction();
		::Dynamic calculateSecondaryProduction_dyn();

		 ::Pile calculateConsumption();
		::Dynamic calculateConsumption_dyn();

		Float calculateHappinessFromEmployment();
		::Dynamic calculateHappinessFromEmployment_dyn();

		Float calculateHappinessFromFood();
		::Dynamic calculateHappinessFromFood_dyn();

		Float calculateHappinessFromGoods();
		::Dynamic calculateHappinessFromGoods_dyn();

		int calculateHappinessFromTemples();
		::Dynamic calculateHappinessFromTemples_dyn();

		Float calculateHappiness();
		::Dynamic calculateHappiness_dyn();

};


#endif /* INCLUDED_Island */ 
