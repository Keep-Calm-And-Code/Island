#ifndef INCLUDED_IslandCell
#define INCLUDED_IslandCell

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
HX_DECLARE_CLASS0(Building)
HX_DECLARE_CLASS0(Cell)
HX_DECLARE_CLASS0(IslandCell)
HX_DECLARE_CLASS0(Terrain)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)



class HXCPP_CLASS_ATTRIBUTES IslandCell_obj : public  ::Cell_obj
{
	public:
		typedef  ::Cell_obj super;
		typedef IslandCell_obj OBJ_;
		IslandCell_obj();

	public:
		enum { _hx_ClassId = 0x4e45a1f7 };

		void __construct( ::Terrain __o_terrain,::String name);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="IslandCell")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"IslandCell"); }
		static ::hx::ObjectPtr< IslandCell_obj > __new( ::Terrain __o_terrain,::String name);
		static ::hx::ObjectPtr< IslandCell_obj > __alloc(::hx::Ctx *_hx_ctx, ::Terrain __o_terrain,::String name);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~IslandCell_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("IslandCell",37,7f,82,36); }

		 ::Terrain terrain;
		 ::Building building;
		int buildingLevel;
		void render();

};


#endif /* INCLUDED_IslandCell */ 
