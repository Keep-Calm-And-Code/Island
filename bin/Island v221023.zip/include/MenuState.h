#ifndef INCLUDED_MenuState
#define INCLUDED_MenuState

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(MenuState)


class MenuState_obj : public ::hx::EnumBase_obj
{
	typedef ::hx::EnumBase_obj super;
		typedef MenuState_obj OBJ_;

	public:
		MenuState_obj() {};
		HX_DO_ENUM_RTTI;
		static void __boot();
		static void __register();
		static bool __GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::String GetEnumName( ) const { return HX_("MenuState",d2,bf,b6,c0); }
		::String __ToString() const { return HX_("MenuState.",1c,18,31,df) + _hx_tag; }

		static ::MenuState Build;
		static inline ::MenuState Build_dyn() { return Build; }
		static ::MenuState Upgrade;
		static inline ::MenuState Upgrade_dyn() { return Upgrade; }
		static ::MenuState ViewPopulation;
		static inline ::MenuState ViewPopulation_dyn() { return ViewPopulation; }
};


#endif /* INCLUDED_MenuState */ 
