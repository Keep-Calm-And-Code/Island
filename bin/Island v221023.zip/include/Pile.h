#ifndef INCLUDED_Pile
#define INCLUDED_Pile

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Pile)
HX_DECLARE_CLASS0(Resource)
HX_DECLARE_CLASS1(haxe,IMap)
HX_DECLARE_CLASS2(haxe,ds,BalancedTree)
HX_DECLARE_CLASS2(haxe,ds,EnumValueMap)



class HXCPP_CLASS_ATTRIBUTES Pile_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Pile_obj OBJ_;
		Pile_obj();

	public:
		enum { _hx_ClassId = 0x098412f6 };

		void __construct( ::haxe::ds::EnumValueMap resources);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="Pile")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"Pile"); }
		static ::hx::ObjectPtr< Pile_obj > __new( ::haxe::ds::EnumValueMap resources);
		static ::hx::ObjectPtr< Pile_obj > __alloc(::hx::Ctx *_hx_ctx, ::haxe::ds::EnumValueMap resources);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Pile_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Pile",d2,1c,31,35); }

		 ::haxe::ds::EnumValueMap resources;
		virtual ::String toString();
		::Dynamic toString_dyn();

		::String toLeftAlignedString(::String prefix, ::Dynamic isResourceNameVisible);
		::Dynamic toLeftAlignedString_dyn();

		::String toResourceAlignedString(::String prefix, ::Dynamic isResourceNameVisible);
		::Dynamic toResourceAlignedString_dyn();

		 ::Dynamic get( ::Resource r);
		::Dynamic get_dyn();

		bool hasPile( ::Pile p);
		::Dynamic hasPile_dyn();

		 ::Pile add( ::Resource r,int n);
		::Dynamic add_dyn();

		 ::Pile cutoffAdd( ::Resource r,int n);
		::Dynamic cutoffAdd_dyn();

		void subtract( ::Resource r,int n);
		::Dynamic subtract_dyn();

		void cutoffSubtract( ::Resource r,int n);
		::Dynamic cutoffSubtract_dyn();

		 ::Pile addPile( ::Pile p);
		::Dynamic addPile_dyn();

		 ::Pile cutoffAddPile( ::Pile p);
		::Dynamic cutoffAddPile_dyn();

		 ::Pile subtractPile( ::Pile p);
		::Dynamic subtractPile_dyn();

		 ::Pile cutoffSubtractPile( ::Pile p);
		::Dynamic cutoffSubtractPile_dyn();

		 ::Pile multiplyAndRound(Float f);
		::Dynamic multiplyAndRound_dyn();

};


#endif /* INCLUDED_Pile */ 
