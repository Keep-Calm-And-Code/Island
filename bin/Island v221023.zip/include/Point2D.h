#ifndef INCLUDED_Point2D
#define INCLUDED_Point2D

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_STACK_FRAME(_hx_pos_fa19d541445307bf_426_new)
HX_DECLARE_CLASS0(Point2D)



class HXCPP_CLASS_ATTRIBUTES Point2D_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Point2D_obj OBJ_;
		Point2D_obj();

	public:
		enum { _hx_ClassId = 0x18c0077a };

		void __construct(int newx,int newy);
		inline void *operator new(size_t inSize, bool inContainer=false,const char *inName="Point2D")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,false,"Point2D"); }

		inline static ::hx::ObjectPtr< Point2D_obj > __new(int newx,int newy) {
			::hx::ObjectPtr< Point2D_obj > __this = new Point2D_obj();
			__this->__construct(newx,newy);
			return __this;
		}

		inline static ::hx::ObjectPtr< Point2D_obj > __alloc(::hx::Ctx *_hx_ctx,int newx,int newy) {
			Point2D_obj *__this = (Point2D_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Point2D_obj), false, "Point2D"));
			*(void **)__this = Point2D_obj::_hx_vtable;
{
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_426_new)
HXLINE( 427)		( ( ::Point2D)(__this) )->x = newx;
HXDLIN( 427)		( ( ::Point2D)(__this) )->y = newy;
            	}
		
			return __this;
		}

		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Point2D_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Point2D",02,bc,72,1e); }

		static ::String coordsToString(int x,int y);
		static ::Dynamic coordsToString_dyn();

		static bool isPoint(::String str);
		static ::Dynamic isPoint_dyn();

		static  ::Dynamic xFromString(::String str);
		static ::Dynamic xFromString_dyn();

		static  ::Dynamic yFromString(::String str);
		static ::Dynamic yFromString_dyn();

		static  ::Point2D pointFromString(::String str);
		static ::Dynamic pointFromString_dyn();

		int x;
		int y;
		virtual ::String toString();
		::Dynamic toString_dyn();

};


#endif /* INCLUDED_Point2D */ 
