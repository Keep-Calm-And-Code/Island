#ifndef INCLUDED_Resource
#define INCLUDED_Resource

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Resource)


class Resource_obj : public ::hx::EnumBase_obj
{
	typedef ::hx::EnumBase_obj super;
		typedef Resource_obj OBJ_;

	public:
		Resource_obj() {};
		HX_DO_ENUM_RTTI;
		static void __boot();
		static void __register();
		static bool __GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::String GetEnumName( ) const { return HX_("Resource",ee,18,52,ec); }
		::String __ToString() const { return HX_("Resource.",80,b7,83,db) + _hx_tag; }

		static ::Resource Fish;
		static inline ::Resource Fish_dyn() { return Fish; }
		static ::Resource Goods;
		static inline ::Resource Goods_dyn() { return Goods; }
		static ::Resource Grain;
		static inline ::Resource Grain_dyn() { return Grain; }
		static ::Resource Metal;
		static inline ::Resource Metal_dyn() { return Metal; }
		static ::Resource Tools;
		static inline ::Resource Tools_dyn() { return Tools; }
		static ::Resource Wood;
		static inline ::Resource Wood_dyn() { return Wood; }
};


#endif /* INCLUDED_Resource */ 
