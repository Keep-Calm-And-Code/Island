#ifndef INCLUDED_Terrain
#define INCLUDED_Terrain

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Terrain)


class Terrain_obj : public ::hx::EnumBase_obj
{
	typedef ::hx::EnumBase_obj super;
		typedef Terrain_obj OBJ_;

	public:
		Terrain_obj() {};
		HX_DO_ENUM_RTTI;
		static void __boot();
		static void __register();
		static bool __GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::String GetEnumName( ) const { return HX_("Terrain",95,d3,68,f6); }
		::String __ToString() const { return HX_("Terrain.",f9,4e,50,a5) + _hx_tag; }

		static ::Terrain Forest;
		static inline ::Terrain Forest_dyn() { return Forest; }
		static ::Terrain Grass;
		static inline ::Terrain Grass_dyn() { return Grass; }
		static ::Terrain Hills;
		static inline ::Terrain Hills_dyn() { return Hills; }
};


#endif /* INCLUDED_Terrain */ 
