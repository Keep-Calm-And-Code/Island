#ifndef INCLUDED_TextMenu
#define INCLUDED_TextMenu

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
HX_DECLARE_CLASS0(MenuOption)
HX_DECLARE_CLASS0(TextMenu)
HX_DECLARE_CLASS0(TextMenuType)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)



class HXCPP_CLASS_ATTRIBUTES TextMenu_obj : public  ::TextWindow_obj
{
	public:
		typedef  ::TextWindow_obj super;
		typedef TextMenu_obj OBJ_;
		TextMenu_obj();

	public:
		enum { _hx_ClassId = 0x2e5b1294 };

		void __construct();
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="TextMenu")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"TextMenu"); }
		static ::hx::ObjectPtr< TextMenu_obj > __new();
		static ::hx::ObjectPtr< TextMenu_obj > __alloc(::hx::Ctx *_hx_ctx);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~TextMenu_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("TextMenu",0c,55,06,25); }

		 ::TextMenuType orientation;
		::Array< ::Dynamic> menuOptions;
};


#endif /* INCLUDED_TextMenu */ 
