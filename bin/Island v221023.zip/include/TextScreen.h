#ifndef INCLUDED_TextScreen
#define INCLUDED_TextScreen

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(ChildWindowInfo)
HX_DECLARE_CLASS0(ColoredChar)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)



class HXCPP_CLASS_ATTRIBUTES TextScreen_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef TextScreen_obj OBJ_;
		TextScreen_obj();

	public:
		enum { _hx_ClassId = 0x0b23efa1 };

		void __construct( ::Dynamic __o_rows, ::Dynamic __o_columns);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="TextScreen")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"TextScreen"); }
		static ::hx::ObjectPtr< TextScreen_obj > __new( ::Dynamic __o_rows, ::Dynamic __o_columns);
		static ::hx::ObjectPtr< TextScreen_obj > __alloc(::hx::Ctx *_hx_ctx, ::Dynamic __o_rows, ::Dynamic __o_columns);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~TextScreen_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("TextScreen",19,c0,fe,74); }

		static void pad(::String str,int length);
		static ::Dynamic pad_dyn();

		static ::String padRight(::String str,int length);
		static ::Dynamic padRight_dyn();

		static ::String padLeft(::String str,int length);
		static ::Dynamic padLeft_dyn();

		::String defaultChar;
		::String defaultTextColor;
		int rows;
		int columns;
		::Array< ::Dynamic> displayBuffer;
		::Array< ::Dynamic> childWindowInfoList;
		virtual void write(::String text,::String color, ::Dynamic row, ::Dynamic column);
		::Dynamic write_dyn();

		void writeLeft(::String text,::String color, ::Dynamic rows, ::Dynamic column);
		::Dynamic writeLeft_dyn();

		virtual void clear(::String fill);
		::Dynamic clear_dyn();

		void addChild( ::TextWindow child,::hx::Null< int >  parentFirstRow,::hx::Null< int >  parentFirstCol,::hx::Null< int >  displayFirstRow,::hx::Null< int >  displayFirstCol, ::Dynamic displayRows, ::Dynamic displayCols,::hx::Null< bool >  isVisible);
		::Dynamic addChild_dyn();

		void removeChild(::String name);
		::Dynamic removeChild_dyn();

		 ::ChildWindowInfo findChild(::String name);
		::Dynamic findChild_dyn();

		virtual void render();
		::Dynamic render_dyn();

		void display();
		::Dynamic display_dyn();

		void displayColour();
		::Dynamic displayColour_dyn();

		void displayMonochrome();
		::Dynamic displayMonochrome_dyn();

};


#endif /* INCLUDED_TextScreen */ 
