#ifndef INCLUDED_TextWindow
#define INCLUDED_TextWindow

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
HX_DECLARE_CLASS0(ColoredChar)
HX_DECLARE_CLASS0(TextScreen)
HX_DECLARE_CLASS0(TextWindow)



class HXCPP_CLASS_ATTRIBUTES TextWindow_obj : public  ::TextScreen_obj
{
	public:
		typedef  ::TextScreen_obj super;
		typedef TextWindow_obj OBJ_;
		TextWindow_obj();

	public:
		enum { _hx_ClassId = 0x16534825 };

		void __construct( ::Dynamic __o_rows, ::Dynamic __o_columns,::String __o_name);
		inline void *operator new(size_t inSize, bool inContainer=true,const char *inName="TextWindow")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,true,"TextWindow"); }
		static ::hx::ObjectPtr< TextWindow_obj > __new( ::Dynamic __o_rows, ::Dynamic __o_columns,::String __o_name);
		static ::hx::ObjectPtr< TextWindow_obj > __alloc(::hx::Ctx *_hx_ctx, ::Dynamic __o_rows, ::Dynamic __o_columns,::String __o_name);
		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~TextWindow_obj();

		HX_DO_RTTI_ALL;
		::hx::Val __Field(const ::String &inString, ::hx::PropertyAccess inCallProp);
		::hx::Val __SetField(const ::String &inString,const ::hx::Val &inValue, ::hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("TextWindow",9d,18,2e,80); }

		::String name;
		::Array< ::Dynamic> dataBuffer;
		void write(::String text,::String color, ::Dynamic row, ::Dynamic column);

		virtual void clear(::String fill);

		virtual void render();

		void copyDataBuffer();
		::Dynamic copyDataBuffer_dyn();

};


#endif /* INCLUDED_TextWindow */ 
