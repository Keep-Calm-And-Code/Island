#ifndef INCLUDED_Utils
#define INCLUDED_Utils

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Utils)



class HXCPP_CLASS_ATTRIBUTES Utils_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Utils_obj OBJ_;
		Utils_obj();

	public:
		enum { _hx_ClassId = 0x3250836d };

		void __construct();
		inline void *operator new(size_t inSize, bool inContainer=false,const char *inName="Utils")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,false,"Utils"); }

		inline static ::hx::ObjectPtr< Utils_obj > __new() {
			::hx::ObjectPtr< Utils_obj > __this = new Utils_obj();
			__this->__construct();
			return __this;
		}

		inline static ::hx::ObjectPtr< Utils_obj > __alloc(::hx::Ctx *_hx_ctx) {
			Utils_obj *__this = (Utils_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Utils_obj), false, "Utils"));
			*(void **)__this = Utils_obj::_hx_vtable;
			return __this;
		}

		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Utils_obj();

		HX_DO_RTTI_ALL;
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		static void __register();
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Utils",11,1a,0c,3e); }

		static int randomInt(int min, ::Dynamic max);
		static ::Dynamic randomInt_dyn();

		static int maxInt(int a,int b);
		static ::Dynamic maxInt_dyn();

		static int minInt(int a,int b, ::Dynamic c);
		static ::Dynamic minInt_dyn();

		static Float round(Float f, ::Dynamic places);
		static ::Dynamic round_dyn();

		static int roundInt(Float f);
		static ::Dynamic roundInt_dyn();

		static ::String randomElement(::cpp::VirtualArray a);
		static ::Dynamic randomElement_dyn();

};


#endif /* INCLUDED_Utils */ 
