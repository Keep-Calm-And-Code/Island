#ifndef INCLUDED_Vector2D
#define INCLUDED_Vector2D

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Vector2D)



class HXCPP_CLASS_ATTRIBUTES Vector2D_obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Vector2D_obj OBJ_;
		Vector2D_obj();

	public:
		enum { _hx_ClassId = 0x51c44cfd };

		void __construct();
		inline void *operator new(size_t inSize, bool inContainer=false,const char *inName="Vector2D")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,false,"Vector2D"); }

		inline static ::hx::ObjectPtr< Vector2D_obj > __new() {
			::hx::ObjectPtr< Vector2D_obj > __this = new Vector2D_obj();
			__this->__construct();
			return __this;
		}

		inline static ::hx::ObjectPtr< Vector2D_obj > __alloc(::hx::Ctx *_hx_ctx) {
			Vector2D_obj *__this = (Vector2D_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Vector2D_obj), false, "Vector2D"));
			*(void **)__this = Vector2D_obj::_hx_vtable;
			return __this;
		}

		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Vector2D_obj();

		HX_DO_RTTI_ALL;
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		static void __register();
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Vector2D",75,8f,6f,48); }

		static ::Array< ::Dynamic> create(int h,int w);
		static ::Dynamic create_dyn();

};


#endif /* INCLUDED_Vector2D */ 
