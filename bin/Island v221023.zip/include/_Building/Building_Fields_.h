#ifndef INCLUDED__Building_Building_Fields_
#define INCLUDED__Building_Building_Fields_

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(Building)
HX_DECLARE_CLASS0(Pile)
HX_DECLARE_CLASS1(_Building,Building_Fields_)
HX_DECLARE_CLASS1(haxe,IMap)
HX_DECLARE_CLASS2(haxe,ds,BalancedTree)
HX_DECLARE_CLASS2(haxe,ds,EnumValueMap)

namespace _Building{


class HXCPP_CLASS_ATTRIBUTES Building_Fields__obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Building_Fields__obj OBJ_;
		Building_Fields__obj();

	public:
		enum { _hx_ClassId = 0x14cfff8a };

		void __construct();
		inline void *operator new(size_t inSize, bool inContainer=false,const char *inName="_Building.Building_Fields_")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,false,"_Building.Building_Fields_"); }

		inline static ::hx::ObjectPtr< Building_Fields__obj > __new() {
			::hx::ObjectPtr< Building_Fields__obj > __this = new Building_Fields__obj();
			__this->__construct();
			return __this;
		}

		inline static ::hx::ObjectPtr< Building_Fields__obj > __alloc(::hx::Ctx *_hx_ctx) {
			Building_Fields__obj *__this = (Building_Fields__obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Building_Fields__obj), false, "_Building.Building_Fields_"));
			*(void **)__this = Building_Fields__obj::_hx_vtable;
			return __this;
		}

		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Building_Fields__obj();

		HX_DO_RTTI_ALL;
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, ::hx::PropertyAccess inCallProp);
		static void __register();
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Building_Fields_",bb,ef,0f,c4); }

		static void __boot();
		static  ::haxe::ds::EnumValueMap names;
		static  ::Pile CostToBuild( ::Building b,int n);
		static ::Dynamic CostToBuild_dyn();

};

} // end namespace _Building

#endif /* INCLUDED__Building_Building_Fields_ */ 
