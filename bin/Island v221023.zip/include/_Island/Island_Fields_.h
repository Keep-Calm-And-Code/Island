#ifndef INCLUDED__Island_Island_Fields_
#define INCLUDED__Island_Island_Fields_

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(_Island,Island_Fields_)
HX_DECLARE_CLASS1(haxe,IMap)
HX_DECLARE_CLASS2(haxe,ds,BalancedTree)
HX_DECLARE_CLASS2(haxe,ds,EnumValueMap)

namespace _Island{


class HXCPP_CLASS_ATTRIBUTES Island_Fields__obj : public ::hx::Object
{
	public:
		typedef ::hx::Object super;
		typedef Island_Fields__obj OBJ_;
		Island_Fields__obj();

	public:
		enum { _hx_ClassId = 0x60672ccc };

		void __construct();
		inline void *operator new(size_t inSize, bool inContainer=false,const char *inName="_Island.Island_Fields_")
			{ return ::hx::Object::operator new(inSize,inContainer,inName); }
		inline void *operator new(size_t inSize, int extra)
			{ return ::hx::Object::operator new(inSize+extra,false,"_Island.Island_Fields_"); }

		inline static ::hx::ObjectPtr< Island_Fields__obj > __new() {
			::hx::ObjectPtr< Island_Fields__obj > __this = new Island_Fields__obj();
			__this->__construct();
			return __this;
		}

		inline static ::hx::ObjectPtr< Island_Fields__obj > __alloc(::hx::Ctx *_hx_ctx) {
			Island_Fields__obj *__this = (Island_Fields__obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Island_Fields__obj), false, "_Island.Island_Fields_"));
			*(void **)__this = Island_Fields__obj::_hx_vtable;
			return __this;
		}

		static void * _hx_vtable;
		static Dynamic __CreateEmpty();
		static Dynamic __Create(::hx::DynamicArray inArgs);
		//~Island_Fields__obj();

		HX_DO_RTTI_ALL;
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, ::hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, ::hx::PropertyAccess inCallProp);
		static void __register();
		bool _hx_isInstanceOf(int inClassId);
		::String __ToString() const { return HX_("Island_Fields_",1c,2d,72,73); }

		static void __boot();
		static  ::haxe::ds::EnumValueMap terrainNames;
		static  ::haxe::ds::EnumValueMap terrainChars;
};

} // end namespace _Island

#endif /* INCLUDED__Island_Island_Fields_ */ 
