#ifndef INCLUDED_haxe_IMap
#define INCLUDED_haxe_IMap

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(haxe,IMap)

namespace haxe{


class HXCPP_CLASS_ATTRIBUTES IMap_obj {
	public:
		typedef ::hx::Object super;
		HX_DO_INTERFACE_RTTI;

};

} // end namespace haxe

#endif /* INCLUDED_haxe_IMap */ 
