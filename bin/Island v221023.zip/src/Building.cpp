#include <hxcpp.h>

#ifndef INCLUDED_Building
#include <Building.h>
#endif

::Building Building_obj::Blacksmith;

::Building Building_obj::Farm;

::Building Building_obj::House;

::Building Building_obj::Mine;

::Building Building_obj::Port;

::Building Building_obj::Sawmill;

::Building Building_obj::Temple;

bool Building_obj::__GetStatic(const ::String &inName, ::Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Blacksmith",c4,03,96,99)) { outValue = Building_obj::Blacksmith; return true; }
	if (inName==HX_("Farm",d6,ed,8e,2e)) { outValue = Building_obj::Farm; return true; }
	if (inName==HX_("House",80,9f,91,be)) { outValue = Building_obj::House; return true; }
	if (inName==HX_("Mine",b3,7a,35,33)) { outValue = Building_obj::Mine; return true; }
	if (inName==HX_("Port",a1,af,35,35)) { outValue = Building_obj::Port; return true; }
	if (inName==HX_("Sawmill",65,d5,1e,11)) { outValue = Building_obj::Sawmill; return true; }
	if (inName==HX_("Temple",ad,82,d4,05)) { outValue = Building_obj::Temple; return true; }
	return super::__GetStatic(inName, outValue, inCallProp);
}

HX_DEFINE_CREATE_ENUM(Building_obj)

int Building_obj::__FindIndex(::String inName)
{
	if (inName==HX_("Blacksmith",c4,03,96,99)) return 4;
	if (inName==HX_("Farm",d6,ed,8e,2e)) return 1;
	if (inName==HX_("House",80,9f,91,be)) return 0;
	if (inName==HX_("Mine",b3,7a,35,33)) return 3;
	if (inName==HX_("Port",a1,af,35,35)) return 5;
	if (inName==HX_("Sawmill",65,d5,1e,11)) return 2;
	if (inName==HX_("Temple",ad,82,d4,05)) return 6;
	return super::__FindIndex(inName);
}

int Building_obj::__FindArgCount(::String inName)
{
	if (inName==HX_("Blacksmith",c4,03,96,99)) return 0;
	if (inName==HX_("Farm",d6,ed,8e,2e)) return 0;
	if (inName==HX_("House",80,9f,91,be)) return 0;
	if (inName==HX_("Mine",b3,7a,35,33)) return 0;
	if (inName==HX_("Port",a1,af,35,35)) return 0;
	if (inName==HX_("Sawmill",65,d5,1e,11)) return 0;
	if (inName==HX_("Temple",ad,82,d4,05)) return 0;
	return super::__FindArgCount(inName);
}

::hx::Val Building_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Blacksmith",c4,03,96,99)) return Blacksmith;
	if (inName==HX_("Farm",d6,ed,8e,2e)) return Farm;
	if (inName==HX_("House",80,9f,91,be)) return House;
	if (inName==HX_("Mine",b3,7a,35,33)) return Mine;
	if (inName==HX_("Port",a1,af,35,35)) return Port;
	if (inName==HX_("Sawmill",65,d5,1e,11)) return Sawmill;
	if (inName==HX_("Temple",ad,82,d4,05)) return Temple;
	return super::__Field(inName,inCallProp);
}

static ::String Building_obj_sStaticFields[] = {
	HX_("House",80,9f,91,be),
	HX_("Farm",d6,ed,8e,2e),
	HX_("Sawmill",65,d5,1e,11),
	HX_("Mine",b3,7a,35,33),
	HX_("Blacksmith",c4,03,96,99),
	HX_("Port",a1,af,35,35),
	HX_("Temple",ad,82,d4,05),
	::String(null())
};

::hx::Class Building_obj::__mClass;

Dynamic __Create_Building_obj() { return new Building_obj; }

void Building_obj::__register()
{

::hx::Static(__mClass) = ::hx::_hx_RegisterClass(HX_("Building",94,9e,79,2d), ::hx::TCanCast< Building_obj >,Building_obj_sStaticFields,0,
	&__Create_Building_obj, &__Create,
	&super::__SGetClass(), &CreateBuilding_obj, 0
#ifdef HXCPP_VISIT_ALLOCS
    , 0
#endif
#ifdef HXCPP_SCRIPTABLE
    , 0
#endif
);
	__mClass->mGetStaticField = &Building_obj::__GetStatic;
}

void Building_obj::__boot()
{
Blacksmith = ::hx::CreateConstEnum< Building_obj >(HX_("Blacksmith",c4,03,96,99),4);
Farm = ::hx::CreateConstEnum< Building_obj >(HX_("Farm",d6,ed,8e,2e),1);
House = ::hx::CreateConstEnum< Building_obj >(HX_("House",80,9f,91,be),0);
Mine = ::hx::CreateConstEnum< Building_obj >(HX_("Mine",b3,7a,35,33),3);
Port = ::hx::CreateConstEnum< Building_obj >(HX_("Port",a1,af,35,35),5);
Sawmill = ::hx::CreateConstEnum< Building_obj >(HX_("Sawmill",65,d5,1e,11),2);
Temple = ::hx::CreateConstEnum< Building_obj >(HX_("Temple",ad,82,d4,05),6);
}


