#include <hxcpp.h>

#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
#ifndef INCLUDED_Grid
#include <Grid.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_62625c996dbfc043_406_new,"Cell","new",0xdcb8f7b4,"Cell.new","Grid.hx",406,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_62625c996dbfc043_416_render,"Cell","render",0x34bc9082,"Cell.render","Grid.hx",416,0xd4729398)

void Cell_obj::__construct(int rows,int columns,::String name){
            	HX_STACKFRAME(&_hx_pos_62625c996dbfc043_406_new)
HXLINE( 407)		super::__construct(rows,columns,name);
HXLINE( 408)		this->neighbors = ::Array_obj< ::String >::__new(0);
HXLINE( 409)		this->defaultChar = HX_(".",2e,00,00,00);
HXLINE( 410)		this->clear(null());
            	}

Dynamic Cell_obj::__CreateEmpty() { return new Cell_obj; }

void *Cell_obj::_hx_vtable = 0;

Dynamic Cell_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Cell_obj > _hx_result = new Cell_obj();
	_hx_result->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return _hx_result;
}

bool Cell_obj::_hx_isInstanceOf(int inClassId) {
	if (inClassId<=(int)0x0b23efa1) {
		if (inClassId<=(int)0x00e943e6) {
			return inClassId==(int)0x00000001 || inClassId==(int)0x00e943e6;
		} else {
			return inClassId==(int)0x0b23efa1;
		}
	} else {
		return inClassId==(int)0x16534825;
	}
}

void Cell_obj::render(){
            	HX_STACKFRAME(&_hx_pos_62625c996dbfc043_416_render)
HXDLIN( 416)		this->clear(null());
            	}



::hx::ObjectPtr< Cell_obj > Cell_obj::__new(int rows,int columns,::String name) {
	::hx::ObjectPtr< Cell_obj > __this = new Cell_obj();
	__this->__construct(rows,columns,name);
	return __this;
}

::hx::ObjectPtr< Cell_obj > Cell_obj::__alloc(::hx::Ctx *_hx_ctx,int rows,int columns,::String name) {
	Cell_obj *__this = (Cell_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Cell_obj), true, "Cell"));
	*(void **)__this = Cell_obj::_hx_vtable;
	__this->__construct(rows,columns,name);
	return __this;
}

Cell_obj::Cell_obj()
{
}

void Cell_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Cell);
	HX_MARK_MEMBER_NAME(grid,"grid");
	HX_MARK_MEMBER_NAME(neighbors,"neighbors");
	 ::TextWindow_obj::__Mark(HX_MARK_ARG);
	HX_MARK_END_CLASS();
}

void Cell_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(grid,"grid");
	HX_VISIT_MEMBER_NAME(neighbors,"neighbors");
	 ::TextWindow_obj::__Visit(HX_VISIT_ARG);
}

::hx::Val Cell_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"grid") ) { return ::hx::Val( grid ); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"render") ) { return ::hx::Val( render_dyn() ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"neighbors") ) { return ::hx::Val( neighbors ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val Cell_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"grid") ) { grid=inValue.Cast<  ::Grid >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"neighbors") ) { neighbors=inValue.Cast< ::Array< ::String > >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Cell_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("grid",c6,d6,6b,44));
	outFields->push(HX_("neighbors",41,df,79,94));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo Cell_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::Grid */ ,(int)offsetof(Cell_obj,grid),HX_("grid",c6,d6,6b,44)},
	{::hx::fsObject /* ::Array< ::String > */ ,(int)offsetof(Cell_obj,neighbors),HX_("neighbors",41,df,79,94)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *Cell_obj_sStaticStorageInfo = 0;
#endif

static ::String Cell_obj_sMemberFields[] = {
	HX_("grid",c6,d6,6b,44),
	HX_("neighbors",41,df,79,94),
	HX_("render",56,6b,29,05),
	::String(null()) };

::hx::Class Cell_obj::__mClass;

void Cell_obj::__register()
{
	Cell_obj _hx_dummy;
	Cell_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Cell",c2,4d,96,2c);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(Cell_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< Cell_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Cell_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Cell_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

