#include <hxcpp.h>

#ifndef INCLUDED_ChildWindowInfo
#include <ChildWindowInfo.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_45365262d3aad453_57_new,"ChildWindowInfo","new",0x845a370c,"ChildWindowInfo.new","TextScreen.hx",57,0x3762d845)

void ChildWindowInfo_obj::__construct( ::TextWindow child,::hx::Null< int >  __o_pfrow,::hx::Null< int >  __o_pfcol, ::Dynamic __o_dFRow, ::Dynamic __o_dFCol, ::Dynamic dRows, ::Dynamic dCols,::hx::Null< bool >  __o_isVisible){
            		int pfrow = __o_pfrow.Default(0);
            		int pfcol = __o_pfcol.Default(0);
            		 ::Dynamic dFRow = __o_dFRow;
            		if (::hx::IsNull(__o_dFRow)) dFRow = 0;
            		 ::Dynamic dFCol = __o_dFCol;
            		if (::hx::IsNull(__o_dFCol)) dFCol = 0;
            		bool isVisible = __o_isVisible.Default(true);
            	HX_STACKFRAME(&_hx_pos_45365262d3aad453_57_new)
HXLINE(  58)		this->window = child;
HXLINE(  60)		this->parentFirstRow = pfrow;
HXLINE(  61)		this->parentFirstColumn = pfcol;
HXLINE(  63)		this->displayFirstRow = ( (int)(dFRow) );
HXLINE(  64)		this->displayFirstColumn = ( (int)(dFCol) );
HXLINE(  66)		if (::hx::IsNull( dRows )) {
HXLINE(  66)			this->displayRows = this->window->rows;
            		}
            		else {
HXLINE(  67)			this->displayRows = ( (int)(dRows) );
            		}
HXLINE(  68)		if (::hx::IsNull( dCols )) {
HXLINE(  68)			this->displayColumns = this->window->columns;
            		}
            		else {
HXLINE(  69)			this->displayColumns = ( (int)(dCols) );
            		}
HXLINE(  71)		this->isVisible = isVisible;
            	}

Dynamic ChildWindowInfo_obj::__CreateEmpty() { return new ChildWindowInfo_obj; }

void *ChildWindowInfo_obj::_hx_vtable = 0;

Dynamic ChildWindowInfo_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< ChildWindowInfo_obj > _hx_result = new ChildWindowInfo_obj();
	_hx_result->__construct(inArgs[0],inArgs[1],inArgs[2],inArgs[3],inArgs[4],inArgs[5],inArgs[6],inArgs[7]);
	return _hx_result;
}

bool ChildWindowInfo_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x5745e65a;
}


::hx::ObjectPtr< ChildWindowInfo_obj > ChildWindowInfo_obj::__new( ::TextWindow child,::hx::Null< int >  __o_pfrow,::hx::Null< int >  __o_pfcol, ::Dynamic __o_dFRow, ::Dynamic __o_dFCol, ::Dynamic dRows, ::Dynamic dCols,::hx::Null< bool >  __o_isVisible) {
	::hx::ObjectPtr< ChildWindowInfo_obj > __this = new ChildWindowInfo_obj();
	__this->__construct(child,__o_pfrow,__o_pfcol,__o_dFRow,__o_dFCol,dRows,dCols,__o_isVisible);
	return __this;
}

::hx::ObjectPtr< ChildWindowInfo_obj > ChildWindowInfo_obj::__alloc(::hx::Ctx *_hx_ctx, ::TextWindow child,::hx::Null< int >  __o_pfrow,::hx::Null< int >  __o_pfcol, ::Dynamic __o_dFRow, ::Dynamic __o_dFCol, ::Dynamic dRows, ::Dynamic dCols,::hx::Null< bool >  __o_isVisible) {
	ChildWindowInfo_obj *__this = (ChildWindowInfo_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(ChildWindowInfo_obj), true, "ChildWindowInfo"));
	*(void **)__this = ChildWindowInfo_obj::_hx_vtable;
	__this->__construct(child,__o_pfrow,__o_pfcol,__o_dFRow,__o_dFCol,dRows,dCols,__o_isVisible);
	return __this;
}

ChildWindowInfo_obj::ChildWindowInfo_obj()
{
}

void ChildWindowInfo_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(ChildWindowInfo);
	HX_MARK_MEMBER_NAME(window,"window");
	HX_MARK_MEMBER_NAME(parentFirstRow,"parentFirstRow");
	HX_MARK_MEMBER_NAME(parentFirstColumn,"parentFirstColumn");
	HX_MARK_MEMBER_NAME(displayFirstRow,"displayFirstRow");
	HX_MARK_MEMBER_NAME(displayFirstColumn,"displayFirstColumn");
	HX_MARK_MEMBER_NAME(displayRows,"displayRows");
	HX_MARK_MEMBER_NAME(displayColumns,"displayColumns");
	HX_MARK_MEMBER_NAME(isVisible,"isVisible");
	HX_MARK_END_CLASS();
}

void ChildWindowInfo_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(window,"window");
	HX_VISIT_MEMBER_NAME(parentFirstRow,"parentFirstRow");
	HX_VISIT_MEMBER_NAME(parentFirstColumn,"parentFirstColumn");
	HX_VISIT_MEMBER_NAME(displayFirstRow,"displayFirstRow");
	HX_VISIT_MEMBER_NAME(displayFirstColumn,"displayFirstColumn");
	HX_VISIT_MEMBER_NAME(displayRows,"displayRows");
	HX_VISIT_MEMBER_NAME(displayColumns,"displayColumns");
	HX_VISIT_MEMBER_NAME(isVisible,"isVisible");
}

::hx::Val ChildWindowInfo_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"window") ) { return ::hx::Val( window ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"isVisible") ) { return ::hx::Val( isVisible ); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"displayRows") ) { return ::hx::Val( displayRows ); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"parentFirstRow") ) { return ::hx::Val( parentFirstRow ); }
		if (HX_FIELD_EQ(inName,"displayColumns") ) { return ::hx::Val( displayColumns ); }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"displayFirstRow") ) { return ::hx::Val( displayFirstRow ); }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"parentFirstColumn") ) { return ::hx::Val( parentFirstColumn ); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"displayFirstColumn") ) { return ::hx::Val( displayFirstColumn ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val ChildWindowInfo_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"window") ) { window=inValue.Cast<  ::TextWindow >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"isVisible") ) { isVisible=inValue.Cast< bool >(); return inValue; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"displayRows") ) { displayRows=inValue.Cast< int >(); return inValue; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"parentFirstRow") ) { parentFirstRow=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"displayColumns") ) { displayColumns=inValue.Cast< int >(); return inValue; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"displayFirstRow") ) { displayFirstRow=inValue.Cast< int >(); return inValue; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"parentFirstColumn") ) { parentFirstColumn=inValue.Cast< int >(); return inValue; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"displayFirstColumn") ) { displayFirstColumn=inValue.Cast< int >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void ChildWindowInfo_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("window",f0,93,8c,52));
	outFields->push(HX_("parentFirstRow",14,5b,ee,b8));
	outFields->push(HX_("parentFirstColumn",1c,2e,2e,3d));
	outFields->push(HX_("displayFirstRow",2c,58,89,dd));
	outFields->push(HX_("displayFirstColumn",04,70,ac,bf));
	outFields->push(HX_("displayRows",7b,94,a1,33));
	outFields->push(HX_("displayColumns",bb,56,5b,68));
	outFields->push(HX_("isVisible",a8,f5,22,a7));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo ChildWindowInfo_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::TextWindow */ ,(int)offsetof(ChildWindowInfo_obj,window),HX_("window",f0,93,8c,52)},
	{::hx::fsInt,(int)offsetof(ChildWindowInfo_obj,parentFirstRow),HX_("parentFirstRow",14,5b,ee,b8)},
	{::hx::fsInt,(int)offsetof(ChildWindowInfo_obj,parentFirstColumn),HX_("parentFirstColumn",1c,2e,2e,3d)},
	{::hx::fsInt,(int)offsetof(ChildWindowInfo_obj,displayFirstRow),HX_("displayFirstRow",2c,58,89,dd)},
	{::hx::fsInt,(int)offsetof(ChildWindowInfo_obj,displayFirstColumn),HX_("displayFirstColumn",04,70,ac,bf)},
	{::hx::fsInt,(int)offsetof(ChildWindowInfo_obj,displayRows),HX_("displayRows",7b,94,a1,33)},
	{::hx::fsInt,(int)offsetof(ChildWindowInfo_obj,displayColumns),HX_("displayColumns",bb,56,5b,68)},
	{::hx::fsBool,(int)offsetof(ChildWindowInfo_obj,isVisible),HX_("isVisible",a8,f5,22,a7)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *ChildWindowInfo_obj_sStaticStorageInfo = 0;
#endif

static ::String ChildWindowInfo_obj_sMemberFields[] = {
	HX_("window",f0,93,8c,52),
	HX_("parentFirstRow",14,5b,ee,b8),
	HX_("parentFirstColumn",1c,2e,2e,3d),
	HX_("displayFirstRow",2c,58,89,dd),
	HX_("displayFirstColumn",04,70,ac,bf),
	HX_("displayRows",7b,94,a1,33),
	HX_("displayColumns",bb,56,5b,68),
	HX_("isVisible",a8,f5,22,a7),
	::String(null()) };

::hx::Class ChildWindowInfo_obj::__mClass;

void ChildWindowInfo_obj::__register()
{
	ChildWindowInfo_obj _hx_dummy;
	ChildWindowInfo_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("ChildWindowInfo",1a,01,1f,8b);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(ChildWindowInfo_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< ChildWindowInfo_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = ChildWindowInfo_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = ChildWindowInfo_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

