#include <hxcpp.h>

#ifndef INCLUDED_ColoredChar
#include <ColoredChar.h>
#endif
#ifndef INCLUDED_haxe_Exception
#include <haxe/Exception.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_632c93a8ac45a6d8_32_new,"ColoredChar","new",0x64e5614a,"ColoredChar.new","TextScreen.hx",32,0x3762d845)

void ColoredChar_obj::__construct(::String __o__hx_char,::String __o_color){
            		::String _hx_char = __o__hx_char;
            		if (::hx::IsNull(__o__hx_char)) _hx_char = HX_(" ",20,00,00,00);
            		::String color = __o_color;
            		if (::hx::IsNull(__o_color)) color = HX_("\x1b""[0;37m",3e,ae,9f,8f);
            	HX_STACKFRAME(&_hx_pos_632c93a8ac45a6d8_32_new)
HXLINE(  33)		if ((_hx_char.length != 1)) {
HXLINE(  33)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("Not a character; string length not 1",d7,ad,78,ef)));
            		}
HXLINE(  35)		this->_hx_char = _hx_char;
HXLINE(  36)		this->ansiColor = color;
            	}

Dynamic ColoredChar_obj::__CreateEmpty() { return new ColoredChar_obj; }

void *ColoredChar_obj::_hx_vtable = 0;

Dynamic ColoredChar_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< ColoredChar_obj > _hx_result = new ColoredChar_obj();
	_hx_result->__construct(inArgs[0],inArgs[1]);
	return _hx_result;
}

bool ColoredChar_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x3f77f998;
}


::hx::ObjectPtr< ColoredChar_obj > ColoredChar_obj::__new(::String __o__hx_char,::String __o_color) {
	::hx::ObjectPtr< ColoredChar_obj > __this = new ColoredChar_obj();
	__this->__construct(__o__hx_char,__o_color);
	return __this;
}

::hx::ObjectPtr< ColoredChar_obj > ColoredChar_obj::__alloc(::hx::Ctx *_hx_ctx,::String __o__hx_char,::String __o_color) {
	ColoredChar_obj *__this = (ColoredChar_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(ColoredChar_obj), true, "ColoredChar"));
	*(void **)__this = ColoredChar_obj::_hx_vtable;
	__this->__construct(__o__hx_char,__o_color);
	return __this;
}

ColoredChar_obj::ColoredChar_obj()
{
}

void ColoredChar_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(ColoredChar);
	HX_MARK_MEMBER_NAME(_hx_char,"char");
	HX_MARK_MEMBER_NAME(ansiColor,"ansiColor");
	HX_MARK_END_CLASS();
}

void ColoredChar_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(_hx_char,"char");
	HX_VISIT_MEMBER_NAME(ansiColor,"ansiColor");
}

::hx::Val ColoredChar_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"char") ) { return ::hx::Val( _hx_char ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"ansiColor") ) { return ::hx::Val( ansiColor ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val ColoredChar_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"char") ) { _hx_char=inValue.Cast< ::String >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"ansiColor") ) { ansiColor=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void ColoredChar_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("char",d6,5e,bf,41));
	outFields->push(HX_("ansiColor",a0,ef,4c,08));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo ColoredChar_obj_sMemberStorageInfo[] = {
	{::hx::fsString,(int)offsetof(ColoredChar_obj,_hx_char),HX_("char",d6,5e,bf,41)},
	{::hx::fsString,(int)offsetof(ColoredChar_obj,ansiColor),HX_("ansiColor",a0,ef,4c,08)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *ColoredChar_obj_sStaticStorageInfo = 0;
#endif

static ::String ColoredChar_obj_sMemberFields[] = {
	HX_("char",d6,5e,bf,41),
	HX_("ansiColor",a0,ef,4c,08),
	::String(null()) };

::hx::Class ColoredChar_obj::__mClass;

void ColoredChar_obj::__register()
{
	ColoredChar_obj _hx_dummy;
	ColoredChar_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("ColoredChar",58,b4,7c,8c);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(ColoredChar_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< ColoredChar_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = ColoredChar_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = ColoredChar_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

