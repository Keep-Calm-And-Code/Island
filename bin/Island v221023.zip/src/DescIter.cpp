#include <hxcpp.h>

#ifndef INCLUDED_DescIter
#include <DescIter.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_50cb22b8a8f8fc03_62_new,"DescIter","new",0x8efa719b,"DescIter.new","Utils.hx",62,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_50cb22b8a8f8fc03_67_hasNext,"DescIter","hasNext",0x6df60028,"DescIter.hasNext","Utils.hx",67,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_50cb22b8a8f8fc03_69_next,"DescIter","next",0x8c28f758,"DescIter.next","Utils.hx",69,0x4c60094d)

void DescIter_obj::__construct(int max,int min){
            	HX_STACKFRAME(&_hx_pos_50cb22b8a8f8fc03_62_new)
HXLINE(  63)		this->at = max;
HXLINE(  64)		this->end = min;
            	}

Dynamic DescIter_obj::__CreateEmpty() { return new DescIter_obj; }

void *DescIter_obj::_hx_vtable = 0;

Dynamic DescIter_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< DescIter_obj > _hx_result = new DescIter_obj();
	_hx_result->__construct(inArgs[0],inArgs[1]);
	return _hx_result;
}

bool DescIter_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x213dfae9;
}

bool DescIter_obj::hasNext(){
            	HX_STACKFRAME(&_hx_pos_50cb22b8a8f8fc03_67_hasNext)
HXDLIN(  67)		return (this->at >= this->end);
            	}


HX_DEFINE_DYNAMIC_FUNC0(DescIter_obj,hasNext,return )

int DescIter_obj::next(){
            	HX_STACKFRAME(&_hx_pos_50cb22b8a8f8fc03_69_next)
HXDLIN(  69)		return this->at--;
            	}


HX_DEFINE_DYNAMIC_FUNC0(DescIter_obj,next,return )


DescIter_obj::DescIter_obj()
{
}

::hx::Val DescIter_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"at") ) { return ::hx::Val( at ); }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"end") ) { return ::hx::Val( end ); }
		break;
	case 4:
		if (HX_FIELD_EQ(inName,"next") ) { return ::hx::Val( next_dyn() ); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"hasNext") ) { return ::hx::Val( hasNext_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val DescIter_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 2:
		if (HX_FIELD_EQ(inName,"at") ) { at=inValue.Cast< int >(); return inValue; }
		break;
	case 3:
		if (HX_FIELD_EQ(inName,"end") ) { end=inValue.Cast< int >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void DescIter_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("end",db,03,4d,00));
	outFields->push(HX_("at",f3,54,00,00));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo DescIter_obj_sMemberStorageInfo[] = {
	{::hx::fsInt,(int)offsetof(DescIter_obj,end),HX_("end",db,03,4d,00)},
	{::hx::fsInt,(int)offsetof(DescIter_obj,at),HX_("at",f3,54,00,00)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *DescIter_obj_sStaticStorageInfo = 0;
#endif

static ::String DescIter_obj_sMemberFields[] = {
	HX_("end",db,03,4d,00),
	HX_("at",f3,54,00,00),
	HX_("hasNext",6d,a5,46,18),
	HX_("next",f3,84,02,49),
	::String(null()) };

::hx::Class DescIter_obj::__mClass;

void DescIter_obj::__register()
{
	DescIter_obj _hx_dummy;
	DescIter_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("DescIter",29,08,ad,c5);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(DescIter_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< DescIter_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = DescIter_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = DescIter_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

