#include <hxcpp.h>

#ifndef INCLUDED_Direction
#include <Direction.h>
#endif

::Direction Direction_obj::Down;

::Direction Direction_obj::Left;

::Direction Direction_obj::Right;

::Direction Direction_obj::Up;

bool Direction_obj::__GetStatic(const ::String &inName, ::Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Down",82,24,47,2d)) { outValue = Direction_obj::Down; return true; }
	if (inName==HX_("Left",27,34,89,32)) { outValue = Direction_obj::Left; return true; }
	if (inName==HX_("Right",bc,7b,91,7c)) { outValue = Direction_obj::Right; return true; }
	if (inName==HX_("Up",7b,4a,00,00)) { outValue = Direction_obj::Up; return true; }
	return super::__GetStatic(inName, outValue, inCallProp);
}

HX_DEFINE_CREATE_ENUM(Direction_obj)

int Direction_obj::__FindIndex(::String inName)
{
	if (inName==HX_("Down",82,24,47,2d)) return 3;
	if (inName==HX_("Left",27,34,89,32)) return 0;
	if (inName==HX_("Right",bc,7b,91,7c)) return 1;
	if (inName==HX_("Up",7b,4a,00,00)) return 2;
	return super::__FindIndex(inName);
}

int Direction_obj::__FindArgCount(::String inName)
{
	if (inName==HX_("Down",82,24,47,2d)) return 0;
	if (inName==HX_("Left",27,34,89,32)) return 0;
	if (inName==HX_("Right",bc,7b,91,7c)) return 0;
	if (inName==HX_("Up",7b,4a,00,00)) return 0;
	return super::__FindArgCount(inName);
}

::hx::Val Direction_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Down",82,24,47,2d)) return Down;
	if (inName==HX_("Left",27,34,89,32)) return Left;
	if (inName==HX_("Right",bc,7b,91,7c)) return Right;
	if (inName==HX_("Up",7b,4a,00,00)) return Up;
	return super::__Field(inName,inCallProp);
}

static ::String Direction_obj_sStaticFields[] = {
	HX_("Left",27,34,89,32),
	HX_("Right",bc,7b,91,7c),
	HX_("Up",7b,4a,00,00),
	HX_("Down",82,24,47,2d),
	::String(null())
};

::hx::Class Direction_obj::__mClass;

Dynamic __Create_Direction_obj() { return new Direction_obj; }

void Direction_obj::__register()
{

::hx::Static(__mClass) = ::hx::_hx_RegisterClass(HX_("Direction",1f,42,13,b2), ::hx::TCanCast< Direction_obj >,Direction_obj_sStaticFields,0,
	&__Create_Direction_obj, &__Create,
	&super::__SGetClass(), &CreateDirection_obj, 0
#ifdef HXCPP_VISIT_ALLOCS
    , 0
#endif
#ifdef HXCPP_SCRIPTABLE
    , 0
#endif
);
	__mClass->mGetStaticField = &Direction_obj::__GetStatic;
}

void Direction_obj::__boot()
{
Down = ::hx::CreateConstEnum< Direction_obj >(HX_("Down",82,24,47,2d),3);
Left = ::hx::CreateConstEnum< Direction_obj >(HX_("Left",27,34,89,32),0);
Right = ::hx::CreateConstEnum< Direction_obj >(HX_("Right",bc,7b,91,7c),1);
Up = ::hx::CreateConstEnum< Direction_obj >(HX_("Up",7b,4a,00,00),2);
}


