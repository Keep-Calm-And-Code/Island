#include <hxcpp.h>

#ifndef INCLUDED_GenerationType
#include <GenerationType.h>
#endif

::GenerationType GenerationType_obj::Empty;

::GenerationType GenerationType_obj::Filled;

::GenerationType GenerationType_obj::OneCell;

::GenerationType GenerationType_obj::Random;

bool GenerationType_obj::__GetStatic(const ::String &inName, ::Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Empty",6d,aa,07,03)) { outValue = GenerationType_obj::Empty; return true; }
	if (inName==HX_("Filled",c2,81,c3,b9)) { outValue = GenerationType_obj::Filled; return true; }
	if (inName==HX_("OneCell",08,3b,70,24)) { outValue = GenerationType_obj::OneCell; return true; }
	if (inName==HX_("Random",23,96,23,ec)) { outValue = GenerationType_obj::Random; return true; }
	return super::__GetStatic(inName, outValue, inCallProp);
}

HX_DEFINE_CREATE_ENUM(GenerationType_obj)

int GenerationType_obj::__FindIndex(::String inName)
{
	if (inName==HX_("Empty",6d,aa,07,03)) return 0;
	if (inName==HX_("Filled",c2,81,c3,b9)) return 2;
	if (inName==HX_("OneCell",08,3b,70,24)) return 1;
	if (inName==HX_("Random",23,96,23,ec)) return 3;
	return super::__FindIndex(inName);
}

int GenerationType_obj::__FindArgCount(::String inName)
{
	if (inName==HX_("Empty",6d,aa,07,03)) return 0;
	if (inName==HX_("Filled",c2,81,c3,b9)) return 0;
	if (inName==HX_("OneCell",08,3b,70,24)) return 0;
	if (inName==HX_("Random",23,96,23,ec)) return 0;
	return super::__FindArgCount(inName);
}

::hx::Val GenerationType_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Empty",6d,aa,07,03)) return Empty;
	if (inName==HX_("Filled",c2,81,c3,b9)) return Filled;
	if (inName==HX_("OneCell",08,3b,70,24)) return OneCell;
	if (inName==HX_("Random",23,96,23,ec)) return Random;
	return super::__Field(inName,inCallProp);
}

static ::String GenerationType_obj_sStaticFields[] = {
	HX_("Empty",6d,aa,07,03),
	HX_("OneCell",08,3b,70,24),
	HX_("Filled",c2,81,c3,b9),
	HX_("Random",23,96,23,ec),
	::String(null())
};

::hx::Class GenerationType_obj::__mClass;

Dynamic __Create_GenerationType_obj() { return new GenerationType_obj; }

void GenerationType_obj::__register()
{

::hx::Static(__mClass) = ::hx::_hx_RegisterClass(HX_("GenerationType",92,9f,63,12), ::hx::TCanCast< GenerationType_obj >,GenerationType_obj_sStaticFields,0,
	&__Create_GenerationType_obj, &__Create,
	&super::__SGetClass(), &CreateGenerationType_obj, 0
#ifdef HXCPP_VISIT_ALLOCS
    , 0
#endif
#ifdef HXCPP_SCRIPTABLE
    , 0
#endif
);
	__mClass->mGetStaticField = &GenerationType_obj::__GetStatic;
}

void GenerationType_obj::__boot()
{
Empty = ::hx::CreateConstEnum< GenerationType_obj >(HX_("Empty",6d,aa,07,03),0);
Filled = ::hx::CreateConstEnum< GenerationType_obj >(HX_("Filled",c2,81,c3,b9),2);
OneCell = ::hx::CreateConstEnum< GenerationType_obj >(HX_("OneCell",08,3b,70,24),1);
Random = ::hx::CreateConstEnum< GenerationType_obj >(HX_("Random",23,96,23,ec),3);
}


