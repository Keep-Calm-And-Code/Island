#include <hxcpp.h>

#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
#ifndef INCLUDED_Grid
#include <Grid.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_44a4d65fa7a2b7f8_22_new,"Grid","new",0x0fd30ed8,"Grid.new","Grid.hx",22,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_44a4d65fa7a2b7f8_31_addCellWithoutAdjacency,"Grid","addCellWithoutAdjacency",0xb66f383b,"Grid.addCellWithoutAdjacency","Grid.hx",31,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_44a4d65fa7a2b7f8_84_set_activeCellKey,"Grid","set_activeCellKey",0x25c51fd2,"Grid.set_activeCellKey","Grid.hx",84,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_44a4d65fa7a2b7f8_93_randomCellKey,"Grid","randomCellKey",0x4c97f1d2,"Grid.randomCellKey","Grid.hx",93,0xd4729398)

void Grid_obj::__construct(::String __o_name){
            		::String name = __o_name;
            		if (::hx::IsNull(__o_name)) name = HX_("",00,00,00,00);
            	HX_GC_STACKFRAME(&_hx_pos_44a4d65fa7a2b7f8_22_new)
HXLINE(  23)		this->name = name;
HXLINE(  25)		this->cells =  ::haxe::ds::StringMap_obj::__alloc( HX_CTX );
HXLINE(  27)		this->size = 0;
            	}

Dynamic Grid_obj::__CreateEmpty() { return new Grid_obj; }

void *Grid_obj::_hx_vtable = 0;

Dynamic Grid_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Grid_obj > _hx_result = new Grid_obj();
	_hx_result->__construct(inArgs[0]);
	return _hx_result;
}

bool Grid_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x0397f90a;
}

void Grid_obj::addCellWithoutAdjacency( ::Cell cell,::String label){
            	HX_STACKFRAME(&_hx_pos_44a4d65fa7a2b7f8_31_addCellWithoutAdjacency)
HXLINE(  33)		if (::hx::IsNull( label )) {
HXLINE(  33)			label = cell->name;
            		}
HXLINE(  35)		if (this->cells->exists(label)) {
HXLINE(  36)			( ( ::Cell)(this->cells->get(label)) )->grid = null();
HXLINE(  37)			this->cells->remove(label);
            		}
HXLINE(  40)		cell->grid = ::hx::ObjectPtr<OBJ_>(this);
HXLINE(  41)		this->cells->set(label,cell);
HXLINE(  42)		this->size++;
            	}


HX_DEFINE_DYNAMIC_FUNC2(Grid_obj,addCellWithoutAdjacency,(void))

::String Grid_obj::set_activeCellKey(::String activeCell){
            	HX_STACKFRAME(&_hx_pos_44a4d65fa7a2b7f8_84_set_activeCellKey)
HXDLIN(  84)		if (this->cells->exists(activeCell)) {
HXLINE(  85)			return (this->activeCellKey = activeCell);
            		}
            		else {
HXLINE(  88)			return (this->activeCellKey = null());
            		}
HXLINE(  84)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC1(Grid_obj,set_activeCellKey,return )

::String Grid_obj::randomCellKey(){
            	HX_STACKFRAME(&_hx_pos_44a4d65fa7a2b7f8_93_randomCellKey)
HXLINE(  94)		if ((this->size == 0)) {
HXLINE(  94)			return null();
            		}
HXLINE(  96)		int count = ::Utils_obj::randomInt(0,(this->size - 1));
HXLINE(  98)		 ::Dynamic keys = this->cells->keys();
HXLINE(  99)		{
HXLINE(  99)			int _g = 0;
HXDLIN(  99)			int _g1 = count;
HXDLIN(  99)			while((_g < _g1)){
HXLINE(  99)				_g = (_g + 1);
HXDLIN(  99)				int i = (_g - 1);
HXLINE( 100)				keys->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
            			}
            		}
HXLINE( 102)		return ( (::String)(keys->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
            	}


HX_DEFINE_DYNAMIC_FUNC0(Grid_obj,randomCellKey,return )


::hx::ObjectPtr< Grid_obj > Grid_obj::__new(::String __o_name) {
	::hx::ObjectPtr< Grid_obj > __this = new Grid_obj();
	__this->__construct(__o_name);
	return __this;
}

::hx::ObjectPtr< Grid_obj > Grid_obj::__alloc(::hx::Ctx *_hx_ctx,::String __o_name) {
	Grid_obj *__this = (Grid_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Grid_obj), true, "Grid"));
	*(void **)__this = Grid_obj::_hx_vtable;
	__this->__construct(__o_name);
	return __this;
}

Grid_obj::Grid_obj()
{
}

void Grid_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Grid);
	HX_MARK_MEMBER_NAME(name,"name");
	HX_MARK_MEMBER_NAME(cells,"cells");
	HX_MARK_MEMBER_NAME(size,"size");
	HX_MARK_MEMBER_NAME(activeCellKey,"activeCellKey");
	HX_MARK_END_CLASS();
}

void Grid_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(name,"name");
	HX_VISIT_MEMBER_NAME(cells,"cells");
	HX_VISIT_MEMBER_NAME(size,"size");
	HX_VISIT_MEMBER_NAME(activeCellKey,"activeCellKey");
}

::hx::Val Grid_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { return ::hx::Val( name ); }
		if (HX_FIELD_EQ(inName,"size") ) { return ::hx::Val( size ); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"cells") ) { return ::hx::Val( cells ); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"activeCellKey") ) { return ::hx::Val( activeCellKey ); }
		if (HX_FIELD_EQ(inName,"randomCellKey") ) { return ::hx::Val( randomCellKey_dyn() ); }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"set_activeCellKey") ) { return ::hx::Val( set_activeCellKey_dyn() ); }
		break;
	case 23:
		if (HX_FIELD_EQ(inName,"addCellWithoutAdjacency") ) { return ::hx::Val( addCellWithoutAdjacency_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val Grid_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { name=inValue.Cast< ::String >(); return inValue; }
		if (HX_FIELD_EQ(inName,"size") ) { size=inValue.Cast< int >(); return inValue; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"cells") ) { cells=inValue.Cast<  ::haxe::ds::StringMap >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"activeCellKey") ) { if (inCallProp == ::hx::paccAlways) return ::hx::Val( set_activeCellKey(inValue.Cast< ::String >()) );activeCellKey=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Grid_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("name",4b,72,ff,48));
	outFields->push(HX_("cells",91,4c,c0,43));
	outFields->push(HX_("size",c1,a0,53,4c));
	outFields->push(HX_("activeCellKey",f7,9b,84,a5));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo Grid_obj_sMemberStorageInfo[] = {
	{::hx::fsString,(int)offsetof(Grid_obj,name),HX_("name",4b,72,ff,48)},
	{::hx::fsObject /*  ::haxe::ds::StringMap */ ,(int)offsetof(Grid_obj,cells),HX_("cells",91,4c,c0,43)},
	{::hx::fsInt,(int)offsetof(Grid_obj,size),HX_("size",c1,a0,53,4c)},
	{::hx::fsString,(int)offsetof(Grid_obj,activeCellKey),HX_("activeCellKey",f7,9b,84,a5)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *Grid_obj_sStaticStorageInfo = 0;
#endif

static ::String Grid_obj_sMemberFields[] = {
	HX_("name",4b,72,ff,48),
	HX_("cells",91,4c,c0,43),
	HX_("size",c1,a0,53,4c),
	HX_("activeCellKey",f7,9b,84,a5),
	HX_("addCellWithoutAdjacency",c3,ed,44,82),
	HX_("set_activeCellKey",5a,7f,62,cf),
	HX_("randomCellKey",5a,ed,1c,02),
	::String(null()) };

::hx::Class Grid_obj::__mClass;

void Grid_obj::__register()
{
	Grid_obj _hx_dummy;
	Grid_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Grid",e6,02,45,2f);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(Grid_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< Grid_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Grid_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Grid_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

