#include <hxcpp.h>

#ifndef INCLUDED_95f339a1d026d52c
#define INCLUDED_95f339a1d026d52c
#include "hxMath.h"
#endif
#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
#ifndef INCLUDED_ChildWindowInfo
#include <ChildWindowInfo.h>
#endif
#ifndef INCLUDED_Direction
#include <Direction.h>
#endif
#ifndef INCLUDED_Grid
#include <Grid.h>
#endif
#ifndef INCLUDED_HexGrid
#include <HexGrid.h>
#endif
#ifndef INCLUDED_Point2D
#include <Point2D.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_5626eb4025a6df3e_121_new,"HexGrid","new",0x0cebbc93,"HexGrid.new","Grid.hx",121,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_147_set_activeCellKey,"HexGrid","set_activeCellKey",0xbba03ecd,"HexGrid.set_activeCellKey","Grid.hx",147,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_168_isValidPoint,"HexGrid","isValidPoint",0x04cebbab,"HexGrid.isValidPoint","Grid.hx",168,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_181_toCellKey,"HexGrid","toCellKey",0x47671d55,"HexGrid.toCellKey","Grid.hx",181,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_185_toCellX,"HexGrid","toCellX",0xa2b21aae,"HexGrid.toCellX","Grid.hx",185,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_189_toCellY,"HexGrid","toCellY",0xa2b21aaf,"HexGrid.toCellY","Grid.hx",189,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_215_getRowFromCoords,"HexGrid","getRowFromCoords",0x1822cd59,"HexGrid.getRowFromCoords","Grid.hx",215,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_220_getColumnFromCoords,"HexGrid","getColumnFromCoords",0x84494e87,"HexGrid.getColumnFromCoords","Grid.hx",220,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_224_fillWithCells,"HexGrid","fillWithCells",0xaf7ca39b,"HexGrid.fillWithCells","Grid.hx",224,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_233_allCellCoords,"HexGrid","allCellCoords",0xc53879d4,"HexGrid.allCellCoords","Grid.hx",233,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_236_distanceSquaredToCell,"HexGrid","distanceSquaredToCell",0x7f6275c2,"HexGrid.distanceSquaredToCell","Grid.hx",236,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_252_angleToCell,"HexGrid","angleToCell",0x172e3c23,"HexGrid.angleToCell","Grid.hx",252,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_263_isLeftOf,"HexGrid","isLeftOf",0x7f953375,"HexGrid.isLeftOf","Grid.hx",263,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_267_isRightOf,"HexGrid","isRightOf",0x417a11bc,"HexGrid.isRightOf","Grid.hx",267,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_271_isUpOf,"HexGrid","isUpOf",0x36eb7309,"HexGrid.isUpOf","Grid.hx",271,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_275_isDownOf,"HexGrid","isDownOf",0x19f43090,"HexGrid.isDownOf","Grid.hx",275,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_279_isInDirectionOf,"HexGrid","isInDirectionOf",0xee5857ba,"HexGrid.isInDirectionOf","Grid.hx",279,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_299_closestCellInDirection,"HexGrid","closestCellInDirection",0x232c506c,"HexGrid.closestCellInDirection","Grid.hx",299,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_338_closestCellLeft,"HexGrid","closestCellLeft",0xb123d2f5,"HexGrid.closestCellLeft","Grid.hx",338,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_342_closestCellRight,"HexGrid","closestCellRight",0xc541d12e,"HexGrid.closestCellRight","Grid.hx",342,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_346_closestCellUp,"HexGrid","closestCellUp",0xfa55f9c9,"HexGrid.closestCellUp","Grid.hx",346,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_350_closestCellDown,"HexGrid","closestCellDown",0xabe1c350,"HexGrid.closestCellDown","Grid.hx",350,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_355_potentialNeighbors,"HexGrid","potentialNeighbors",0x09879ab0,"HexGrid.potentialNeighbors","Grid.hx",355,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_379_cellKeysWithPotentialNeighbors,"HexGrid","cellKeysWithPotentialNeighbors",0xf90ad32c,"HexGrid.cellKeysWithPotentialNeighbors","Grid.hx",379,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_5626eb4025a6df3e_394_display,"HexGrid","display",0x4db7abf5,"HexGrid.display","Grid.hx",394,0xd4729398)

void HexGrid_obj::__construct(int gridRows,int gridCols,int cellRows,int cellCols,::String name){
            	HX_GC_STACKFRAME(&_hx_pos_5626eb4025a6df3e_121_new)
HXLINE( 122)		this->gridRows = gridRows;
HXDLIN( 122)		this->gridCols = gridCols;
HXLINE( 123)		this->cellRows = cellRows;
HXDLIN( 123)		this->cellCols = cellCols;
HXLINE( 125)		int rows = (gridRows * cellRows);
HXLINE( 126)		int cols = this->getColumnFromCoords(gridCols,(gridRows - 1));
HXLINE( 128)		this->window =  ::TextWindow_obj::__alloc( HX_CTX ,rows,cols,null());
HXLINE( 130)		this->leftCellBracket =  ::TextWindow_obj::__alloc( HX_CTX ,cellRows,1,HX_("leftCellBracket",df,73,88,5d));
HXLINE( 131)		this->leftCellBracket->write(HX_("[",5b,00,00,00),null(),0,null());
HXLINE( 132)		this->leftCellBracket->write(HX_("[",5b,00,00,00),null(),(cellRows - 1),null());
HXLINE( 134)		this->rightCellBracket =  ::TextWindow_obj::__alloc( HX_CTX ,cellRows,1,HX_("rightCellBracket",2a,86,e3,62));
HXLINE( 135)		this->rightCellBracket->write(HX_("]",5d,00,00,00),null(),0,null());
HXLINE( 136)		this->rightCellBracket->write(HX_("]",5d,00,00,00),null(),(cellRows - 1),null());
HXLINE( 138)		this->window->addChild(this->leftCellBracket,null(),null(),null(),null(),null(),null(),false);
HXLINE( 139)		this->window->addChild(this->rightCellBracket,null(),null(),null(),null(),null(),null(),false);
HXLINE( 143)		super::__construct(name);
            	}

Dynamic HexGrid_obj::__CreateEmpty() { return new HexGrid_obj; }

void *HexGrid_obj::_hx_vtable = 0;

Dynamic HexGrid_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< HexGrid_obj > _hx_result = new HexGrid_obj();
	_hx_result->__construct(inArgs[0],inArgs[1],inArgs[2],inArgs[3],inArgs[4]);
	return _hx_result;
}

bool HexGrid_obj::_hx_isInstanceOf(int inClassId) {
	if (inClassId<=(int)0x0397f90a) {
		return inClassId==(int)0x00000001 || inClassId==(int)0x0397f90a;
	} else {
		return inClassId==(int)0x1b8f1c61;
	}
}

::String HexGrid_obj::set_activeCellKey(::String key){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_147_set_activeCellKey)
HXDLIN( 147)		if (this->cells->exists(key)) {
HXLINE( 148)			 ::Dynamic x = ::Point2D_obj::xFromString(key);
HXLINE( 149)			 ::Dynamic y = ::Point2D_obj::yFromString(key);
HXLINE( 151)			int row = this->getRowFromCoords(( (int)(x) ),( (int)(y) ));
HXLINE( 152)			int col = this->getColumnFromCoords(( (int)(x) ),( (int)(y) ));
HXLINE( 154)			this->window->findChild(HX_("leftCellBracket",df,73,88,5d))->parentFirstRow = row;
HXLINE( 155)			this->window->findChild(HX_("leftCellBracket",df,73,88,5d))->parentFirstColumn = (col - 1);
HXLINE( 157)			this->window->findChild(HX_("rightCellBracket",2a,86,e3,62))->parentFirstRow = row;
HXLINE( 158)			this->window->findChild(HX_("rightCellBracket",2a,86,e3,62))->parentFirstColumn = (col + this->cellCols);
HXLINE( 160)			return (this->activeCellKey = key);
            		}
            		else {
HXLINE( 163)			return (this->activeCellKey = null());
            		}
HXLINE( 147)		return null();
            	}


bool HexGrid_obj::isValidPoint(::String key){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_168_isValidPoint)
HXLINE( 169)		if (!(::Point2D_obj::isPoint(key))) {
HXLINE( 169)			return false;
            		}
HXLINE( 171)		 ::Dynamic x = ::Point2D_obj::xFromString(key);
HXLINE( 172)		bool _hx_tmp;
HXDLIN( 172)		if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 172)			int a = ( (int)(x) );
HXDLIN( 172)			int b = this->gridCols;
HXDLIN( 172)			bool aNeg = (a < 0);
HXDLIN( 172)			bool bNeg = (b < 0);
HXDLIN( 172)			if ((aNeg != bNeg)) {
HXLINE( 172)				_hx_tmp = aNeg;
            			}
            			else {
HXLINE( 172)				_hx_tmp = (a >= b);
            			}
            		}
            		else {
HXLINE( 172)			_hx_tmp = true;
            		}
HXDLIN( 172)		if (_hx_tmp) {
HXLINE( 172)			return false;
            		}
HXLINE( 174)		 ::Dynamic y = ::Point2D_obj::yFromString(key);
HXLINE( 175)		bool _hx_tmp1;
HXDLIN( 175)		if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 175)			int a = ( (int)(y) );
HXDLIN( 175)			int b = this->gridRows;
HXDLIN( 175)			bool aNeg = (a < 0);
HXDLIN( 175)			bool bNeg = (b < 0);
HXDLIN( 175)			if ((aNeg != bNeg)) {
HXLINE( 175)				_hx_tmp1 = aNeg;
            			}
            			else {
HXLINE( 175)				_hx_tmp1 = (a >= b);
            			}
            		}
            		else {
HXLINE( 175)			_hx_tmp1 = true;
            		}
HXDLIN( 175)		if (_hx_tmp1) {
HXLINE( 175)			return false;
            		}
HXLINE( 177)		return true;
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,isValidPoint,return )

::String HexGrid_obj::toCellKey(int x,int y){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_181_toCellKey)
HXDLIN( 181)		return ::Point2D_obj::coordsToString(x,y);
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,toCellKey,return )

 ::Dynamic HexGrid_obj::toCellX(::String key){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_185_toCellX)
HXDLIN( 185)		return ::Point2D_obj::xFromString(key);
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,toCellX,return )

 ::Dynamic HexGrid_obj::toCellY(::String key){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_189_toCellY)
HXDLIN( 189)		return ::Point2D_obj::yFromString(key);
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,toCellY,return )

int HexGrid_obj::getRowFromCoords(int x,int y){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_215_getRowFromCoords)
HXDLIN( 215)		return (y * this->cellRows);
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,getRowFromCoords,return )

int HexGrid_obj::getColumnFromCoords(int x,int y){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_220_getColumnFromCoords)
HXDLIN( 220)		int _hx_int = (y * (this->cellCols + 1));
HXDLIN( 220)		Float a;
HXDLIN( 220)		if ((_hx_int < 0)) {
HXDLIN( 220)			a = (((Float)4294967296.0) + _hx_int);
            		}
            		else {
HXDLIN( 220)			a = (_hx_int + ((Float)0.0));
            		}
HXDLIN( 220)		int int1 = 2;
HXDLIN( 220)		Float a1;
HXDLIN( 220)		if ((int1 < 0)) {
HXDLIN( 220)			a1 = (((Float)4294967296.0) + int1);
            		}
            		else {
HXDLIN( 220)			a1 = (int1 + ((Float)0.0));
            		}
HXDLIN( 220)		int a2 = (1 + ::Std_obj::_hx_int((a / a1)));
HXDLIN( 220)		return (a2 + (x * (this->cellCols + 1)));
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,getColumnFromCoords,return )

void HexGrid_obj::fillWithCells(){
            	HX_GC_STACKFRAME(&_hx_pos_5626eb4025a6df3e_224_fillWithCells)
HXDLIN( 224)		int _g = 0;
HXDLIN( 224)		int _g1 = this->gridRows;
HXDLIN( 224)		while((_g < _g1)){
HXDLIN( 224)			_g = (_g + 1);
HXDLIN( 224)			int i = (_g - 1);
HXLINE( 225)			{
HXLINE( 225)				int _g1 = 0;
HXDLIN( 225)				int _g2 = this->gridCols;
HXDLIN( 225)				while((_g1 < _g2)){
HXLINE( 225)					_g1 = (_g1 + 1);
HXDLIN( 225)					int j = (_g1 - 1);
HXLINE( 226)					int cell = this->cellRows;
HXDLIN( 226)					int cell1 = this->cellCols;
HXDLIN( 226)					 ::Cell cell2 =  ::Cell_obj::__alloc( HX_CTX ,cell,cell1,::Point2D_obj::coordsToString(j,i));
HXLINE( 227)					{
HXLINE( 227)						cell2->name = ::Point2D_obj::coordsToString(j,i);
HXDLIN( 227)						this->addCellWithoutAdjacency(cell2,cell2->name);
HXDLIN( 227)						{
HXLINE( 227)							{
HXLINE( 227)								::String k = ::Point2D_obj::coordsToString(j,(i - 1));
HXDLIN( 227)								{
HXLINE( 227)									::String key1 = cell2->name;
HXDLIN( 227)									bool _hx_tmp;
HXDLIN( 227)									if (this->cells->exists(key1)) {
HXLINE( 227)										_hx_tmp = this->cells->exists(k);
            									}
            									else {
HXLINE( 227)										_hx_tmp = false;
            									}
HXDLIN( 227)									if (_hx_tmp) {
HXLINE( 227)										if (!(( ( ::Cell)(this->cells->get(key1)) )->neighbors->contains(k))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(key1)) )->neighbors->push(k);
            										}
HXDLIN( 227)										if (!(( ( ::Cell)(this->cells->get(k)) )->neighbors->contains(key1))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(k)) )->neighbors->push(key1);
            										}
            									}
            								}
            							}
HXDLIN( 227)							{
HXLINE( 227)								::String k1 = ::Point2D_obj::coordsToString((j + 1),(i - 1));
HXDLIN( 227)								{
HXLINE( 227)									::String key11 = cell2->name;
HXDLIN( 227)									bool _hx_tmp1;
HXDLIN( 227)									if (this->cells->exists(key11)) {
HXLINE( 227)										_hx_tmp1 = this->cells->exists(k1);
            									}
            									else {
HXLINE( 227)										_hx_tmp1 = false;
            									}
HXDLIN( 227)									if (_hx_tmp1) {
HXLINE( 227)										if (!(( ( ::Cell)(this->cells->get(key11)) )->neighbors->contains(k1))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(key11)) )->neighbors->push(k1);
            										}
HXDLIN( 227)										if (!(( ( ::Cell)(this->cells->get(k1)) )->neighbors->contains(key11))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(k1)) )->neighbors->push(key11);
            										}
            									}
            								}
            							}
HXDLIN( 227)							{
HXLINE( 227)								::String k2 = ::Point2D_obj::coordsToString((j - 1),i);
HXDLIN( 227)								{
HXLINE( 227)									::String key12 = cell2->name;
HXDLIN( 227)									bool _hx_tmp2;
HXDLIN( 227)									if (this->cells->exists(key12)) {
HXLINE( 227)										_hx_tmp2 = this->cells->exists(k2);
            									}
            									else {
HXLINE( 227)										_hx_tmp2 = false;
            									}
HXDLIN( 227)									if (_hx_tmp2) {
HXLINE( 227)										if (!(( ( ::Cell)(this->cells->get(key12)) )->neighbors->contains(k2))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(key12)) )->neighbors->push(k2);
            										}
HXDLIN( 227)										if (!(( ( ::Cell)(this->cells->get(k2)) )->neighbors->contains(key12))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(k2)) )->neighbors->push(key12);
            										}
            									}
            								}
            							}
HXDLIN( 227)							{
HXLINE( 227)								::String k3 = ::Point2D_obj::coordsToString((j + 1),i);
HXDLIN( 227)								{
HXLINE( 227)									::String key13 = cell2->name;
HXDLIN( 227)									bool _hx_tmp3;
HXDLIN( 227)									if (this->cells->exists(key13)) {
HXLINE( 227)										_hx_tmp3 = this->cells->exists(k3);
            									}
            									else {
HXLINE( 227)										_hx_tmp3 = false;
            									}
HXDLIN( 227)									if (_hx_tmp3) {
HXLINE( 227)										if (!(( ( ::Cell)(this->cells->get(key13)) )->neighbors->contains(k3))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(key13)) )->neighbors->push(k3);
            										}
HXDLIN( 227)										if (!(( ( ::Cell)(this->cells->get(k3)) )->neighbors->contains(key13))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(k3)) )->neighbors->push(key13);
            										}
            									}
            								}
            							}
HXDLIN( 227)							{
HXLINE( 227)								::String k4 = ::Point2D_obj::coordsToString((j - 1),(i + 1));
HXDLIN( 227)								{
HXLINE( 227)									::String key14 = cell2->name;
HXDLIN( 227)									bool _hx_tmp4;
HXDLIN( 227)									if (this->cells->exists(key14)) {
HXLINE( 227)										_hx_tmp4 = this->cells->exists(k4);
            									}
            									else {
HXLINE( 227)										_hx_tmp4 = false;
            									}
HXDLIN( 227)									if (_hx_tmp4) {
HXLINE( 227)										if (!(( ( ::Cell)(this->cells->get(key14)) )->neighbors->contains(k4))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(key14)) )->neighbors->push(k4);
            										}
HXDLIN( 227)										if (!(( ( ::Cell)(this->cells->get(k4)) )->neighbors->contains(key14))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(k4)) )->neighbors->push(key14);
            										}
            									}
            								}
            							}
HXDLIN( 227)							{
HXLINE( 227)								::String k5 = ::Point2D_obj::coordsToString(j,(i + 1));
HXDLIN( 227)								{
HXLINE( 227)									::String key15 = cell2->name;
HXDLIN( 227)									bool _hx_tmp5;
HXDLIN( 227)									if (this->cells->exists(key15)) {
HXLINE( 227)										_hx_tmp5 = this->cells->exists(k5);
            									}
            									else {
HXLINE( 227)										_hx_tmp5 = false;
            									}
HXDLIN( 227)									if (_hx_tmp5) {
HXLINE( 227)										if (!(( ( ::Cell)(this->cells->get(key15)) )->neighbors->contains(k5))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(key15)) )->neighbors->push(k5);
            										}
HXDLIN( 227)										if (!(( ( ::Cell)(this->cells->get(k5)) )->neighbors->contains(key15))) {
HXLINE( 227)											( ( ::Cell)(this->cells->get(k5)) )->neighbors->push(key15);
            										}
            									}
            								}
            							}
            						}
HXDLIN( 227)						 ::TextWindow _hx_tmp6 = this->window;
HXDLIN( 227)						int _hx_tmp7 = this->getRowFromCoords(j,i);
HXDLIN( 227)						_hx_tmp6->addChild(cell2,_hx_tmp7,this->getColumnFromCoords(j,i),null(),null(),null(),null(),null());
            					}
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(HexGrid_obj,fillWithCells,(void))

::Array< ::Dynamic> HexGrid_obj::allCellCoords(){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_233_allCellCoords)
HXDLIN( 233)		::Array< ::Dynamic> _g = ::Array_obj< ::Dynamic>::__new(0);
HXDLIN( 233)		{
HXDLIN( 233)			 ::Dynamic str = this->cells->keys();
HXDLIN( 233)			while(( (bool)(str->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXDLIN( 233)				::String str1 = ( (::String)(str->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXDLIN( 233)				_g->push(::Point2D_obj::pointFromString(str1));
            			}
            		}
HXDLIN( 233)		return _g;
            	}


HX_DEFINE_DYNAMIC_FUNC0(HexGrid_obj,allCellCoords,return )

 ::Dynamic HexGrid_obj::distanceSquaredToCell(::String from,::String to){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_236_distanceSquaredToCell)
HXLINE( 237)		bool _hx_tmp;
HXDLIN( 237)		if (!(::Point2D_obj::isPoint(from))) {
HXLINE( 237)			_hx_tmp = false;
            		}
            		else {
HXLINE( 237)			 ::Dynamic x = ::Point2D_obj::xFromString(from);
HXDLIN( 237)			bool _hx_tmp1;
HXDLIN( 237)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 237)				int a = ( (int)(x) );
HXDLIN( 237)				int b = this->gridCols;
HXDLIN( 237)				bool aNeg = (a < 0);
HXDLIN( 237)				bool bNeg = (b < 0);
HXDLIN( 237)				if ((aNeg != bNeg)) {
HXLINE( 237)					_hx_tmp1 = aNeg;
            				}
            				else {
HXLINE( 237)					_hx_tmp1 = (a >= b);
            				}
            			}
            			else {
HXLINE( 237)				_hx_tmp1 = true;
            			}
HXDLIN( 237)			if (_hx_tmp1) {
HXLINE( 237)				_hx_tmp = false;
            			}
            			else {
HXLINE( 237)				 ::Dynamic y = ::Point2D_obj::yFromString(from);
HXDLIN( 237)				bool _hx_tmp1;
HXDLIN( 237)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 237)					int a = ( (int)(y) );
HXDLIN( 237)					int b = this->gridRows;
HXDLIN( 237)					bool aNeg = (a < 0);
HXDLIN( 237)					bool bNeg = (b < 0);
HXDLIN( 237)					if ((aNeg != bNeg)) {
HXLINE( 237)						_hx_tmp1 = aNeg;
            					}
            					else {
HXLINE( 237)						_hx_tmp1 = (a >= b);
            					}
            				}
            				else {
HXLINE( 237)					_hx_tmp1 = true;
            				}
HXDLIN( 237)				if (_hx_tmp1) {
HXLINE( 237)					_hx_tmp = false;
            				}
            				else {
HXLINE( 237)					_hx_tmp = true;
            				}
            			}
            		}
HXDLIN( 237)		if (!(_hx_tmp)) {
HXLINE( 237)			return null();
            		}
HXLINE( 238)		bool _hx_tmp1;
HXDLIN( 238)		if (!(::Point2D_obj::isPoint(to))) {
HXLINE( 238)			_hx_tmp1 = false;
            		}
            		else {
HXLINE( 238)			 ::Dynamic x = ::Point2D_obj::xFromString(to);
HXDLIN( 238)			bool _hx_tmp;
HXDLIN( 238)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 238)				int a = ( (int)(x) );
HXDLIN( 238)				int b = this->gridCols;
HXDLIN( 238)				bool aNeg = (a < 0);
HXDLIN( 238)				bool bNeg = (b < 0);
HXDLIN( 238)				if ((aNeg != bNeg)) {
HXLINE( 238)					_hx_tmp = aNeg;
            				}
            				else {
HXLINE( 238)					_hx_tmp = (a >= b);
            				}
            			}
            			else {
HXLINE( 238)				_hx_tmp = true;
            			}
HXDLIN( 238)			if (_hx_tmp) {
HXLINE( 238)				_hx_tmp1 = false;
            			}
            			else {
HXLINE( 238)				 ::Dynamic y = ::Point2D_obj::yFromString(to);
HXDLIN( 238)				bool _hx_tmp;
HXDLIN( 238)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 238)					int a = ( (int)(y) );
HXDLIN( 238)					int b = this->gridRows;
HXDLIN( 238)					bool aNeg = (a < 0);
HXDLIN( 238)					bool bNeg = (b < 0);
HXDLIN( 238)					if ((aNeg != bNeg)) {
HXLINE( 238)						_hx_tmp = aNeg;
            					}
            					else {
HXLINE( 238)						_hx_tmp = (a >= b);
            					}
            				}
            				else {
HXLINE( 238)					_hx_tmp = true;
            				}
HXDLIN( 238)				if (_hx_tmp) {
HXLINE( 238)					_hx_tmp1 = false;
            				}
            				else {
HXLINE( 238)					_hx_tmp1 = true;
            				}
            			}
            		}
HXDLIN( 238)		if (!(_hx_tmp1)) {
HXLINE( 238)			return null();
            		}
HXLINE( 240)		 ::Dynamic dx = ::Point2D_obj::xFromString(to);
HXDLIN( 240)		int dx1 = (( (int)(dx) ) - ( (int)(::Point2D_obj::xFromString(from)) ));
HXLINE( 241)		 ::Dynamic dy = ::Point2D_obj::yFromString(to);
HXDLIN( 241)		int dy1 = (( (int)(dy) ) - ( (int)(::Point2D_obj::yFromString(from)) ));
HXLINE( 243)		return (((dx1 + dy1) * (dx1 + dy1)) - (dx1 * dy1));
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,distanceSquaredToCell,return )

 ::Dynamic HexGrid_obj::angleToCell(::String from,::String to){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_252_angleToCell)
HXLINE( 253)		bool _hx_tmp;
HXDLIN( 253)		if (!(::Point2D_obj::isPoint(from))) {
HXLINE( 253)			_hx_tmp = false;
            		}
            		else {
HXLINE( 253)			 ::Dynamic x = ::Point2D_obj::xFromString(from);
HXDLIN( 253)			bool _hx_tmp1;
HXDLIN( 253)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 253)				int a = ( (int)(x) );
HXDLIN( 253)				int b = this->gridCols;
HXDLIN( 253)				bool aNeg = (a < 0);
HXDLIN( 253)				bool bNeg = (b < 0);
HXDLIN( 253)				if ((aNeg != bNeg)) {
HXLINE( 253)					_hx_tmp1 = aNeg;
            				}
            				else {
HXLINE( 253)					_hx_tmp1 = (a >= b);
            				}
            			}
            			else {
HXLINE( 253)				_hx_tmp1 = true;
            			}
HXDLIN( 253)			if (_hx_tmp1) {
HXLINE( 253)				_hx_tmp = false;
            			}
            			else {
HXLINE( 253)				 ::Dynamic y = ::Point2D_obj::yFromString(from);
HXDLIN( 253)				bool _hx_tmp1;
HXDLIN( 253)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 253)					int a = ( (int)(y) );
HXDLIN( 253)					int b = this->gridRows;
HXDLIN( 253)					bool aNeg = (a < 0);
HXDLIN( 253)					bool bNeg = (b < 0);
HXDLIN( 253)					if ((aNeg != bNeg)) {
HXLINE( 253)						_hx_tmp1 = aNeg;
            					}
            					else {
HXLINE( 253)						_hx_tmp1 = (a >= b);
            					}
            				}
            				else {
HXLINE( 253)					_hx_tmp1 = true;
            				}
HXDLIN( 253)				if (_hx_tmp1) {
HXLINE( 253)					_hx_tmp = false;
            				}
            				else {
HXLINE( 253)					_hx_tmp = true;
            				}
            			}
            		}
HXDLIN( 253)		if (!(_hx_tmp)) {
HXLINE( 253)			return null();
            		}
HXLINE( 254)		bool _hx_tmp1;
HXDLIN( 254)		if (!(::Point2D_obj::isPoint(to))) {
HXLINE( 254)			_hx_tmp1 = false;
            		}
            		else {
HXLINE( 254)			 ::Dynamic x = ::Point2D_obj::xFromString(to);
HXDLIN( 254)			bool _hx_tmp;
HXDLIN( 254)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 254)				int a = ( (int)(x) );
HXDLIN( 254)				int b = this->gridCols;
HXDLIN( 254)				bool aNeg = (a < 0);
HXDLIN( 254)				bool bNeg = (b < 0);
HXDLIN( 254)				if ((aNeg != bNeg)) {
HXLINE( 254)					_hx_tmp = aNeg;
            				}
            				else {
HXLINE( 254)					_hx_tmp = (a >= b);
            				}
            			}
            			else {
HXLINE( 254)				_hx_tmp = true;
            			}
HXDLIN( 254)			if (_hx_tmp) {
HXLINE( 254)				_hx_tmp1 = false;
            			}
            			else {
HXLINE( 254)				 ::Dynamic y = ::Point2D_obj::yFromString(to);
HXDLIN( 254)				bool _hx_tmp;
HXDLIN( 254)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 254)					int a = ( (int)(y) );
HXDLIN( 254)					int b = this->gridRows;
HXDLIN( 254)					bool aNeg = (a < 0);
HXDLIN( 254)					bool bNeg = (b < 0);
HXDLIN( 254)					if ((aNeg != bNeg)) {
HXLINE( 254)						_hx_tmp = aNeg;
            					}
            					else {
HXLINE( 254)						_hx_tmp = (a >= b);
            					}
            				}
            				else {
HXLINE( 254)					_hx_tmp = true;
            				}
HXDLIN( 254)				if (_hx_tmp) {
HXLINE( 254)					_hx_tmp1 = false;
            				}
            				else {
HXLINE( 254)					_hx_tmp1 = true;
            				}
            			}
            		}
HXDLIN( 254)		if (!(_hx_tmp1)) {
HXLINE( 254)			return null();
            		}
HXLINE( 256)		 ::Dynamic dx = ::Point2D_obj::xFromString(to);
HXDLIN( 256)		int dx1 = (( (int)(dx) ) - ( (int)(::Point2D_obj::xFromString(from)) ));
HXLINE( 257)		 ::Dynamic dy = ::Point2D_obj::yFromString(to);
HXDLIN( 257)		int dy1 = (( (int)(dy) ) - ( (int)(::Point2D_obj::yFromString(from)) ));
HXLINE( 259)		return ::Math_obj::acos(((dx1 + (( (Float)(dy1) ) / ( (Float)(2) ))) / ::Math_obj::sqrt(( (Float)(this->distanceSquaredToCell(from,to)) ))));
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,angleToCell,return )

 ::Dynamic HexGrid_obj::isLeftOf(::String to,::String from){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_263_isLeftOf)
HXDLIN( 263)		return this->isInDirectionOf(to,::Direction_obj::Left_dyn(),from);
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,isLeftOf,return )

 ::Dynamic HexGrid_obj::isRightOf(::String to,::String from){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_267_isRightOf)
HXDLIN( 267)		return this->isInDirectionOf(to,::Direction_obj::Right_dyn(),from);
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,isRightOf,return )

 ::Dynamic HexGrid_obj::isUpOf(::String to,::String from){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_271_isUpOf)
HXDLIN( 271)		return this->isInDirectionOf(to,::Direction_obj::Up_dyn(),from);
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,isUpOf,return )

 ::Dynamic HexGrid_obj::isDownOf(::String to,::String from){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_275_isDownOf)
HXDLIN( 275)		return this->isInDirectionOf(to,::Direction_obj::Down_dyn(),from);
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,isDownOf,return )

 ::Dynamic HexGrid_obj::isInDirectionOf(::String to, ::Direction dir,::String from){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_279_isInDirectionOf)
HXLINE( 280)		bool _hx_tmp;
HXDLIN( 280)		if (!(::Point2D_obj::isPoint(from))) {
HXLINE( 280)			_hx_tmp = false;
            		}
            		else {
HXLINE( 280)			 ::Dynamic x = ::Point2D_obj::xFromString(from);
HXDLIN( 280)			bool _hx_tmp1;
HXDLIN( 280)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 280)				int a = ( (int)(x) );
HXDLIN( 280)				int b = this->gridCols;
HXDLIN( 280)				bool aNeg = (a < 0);
HXDLIN( 280)				bool bNeg = (b < 0);
HXDLIN( 280)				if ((aNeg != bNeg)) {
HXLINE( 280)					_hx_tmp1 = aNeg;
            				}
            				else {
HXLINE( 280)					_hx_tmp1 = (a >= b);
            				}
            			}
            			else {
HXLINE( 280)				_hx_tmp1 = true;
            			}
HXDLIN( 280)			if (_hx_tmp1) {
HXLINE( 280)				_hx_tmp = false;
            			}
            			else {
HXLINE( 280)				 ::Dynamic y = ::Point2D_obj::yFromString(from);
HXDLIN( 280)				bool _hx_tmp1;
HXDLIN( 280)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 280)					int a = ( (int)(y) );
HXDLIN( 280)					int b = this->gridRows;
HXDLIN( 280)					bool aNeg = (a < 0);
HXDLIN( 280)					bool bNeg = (b < 0);
HXDLIN( 280)					if ((aNeg != bNeg)) {
HXLINE( 280)						_hx_tmp1 = aNeg;
            					}
            					else {
HXLINE( 280)						_hx_tmp1 = (a >= b);
            					}
            				}
            				else {
HXLINE( 280)					_hx_tmp1 = true;
            				}
HXDLIN( 280)				if (_hx_tmp1) {
HXLINE( 280)					_hx_tmp = false;
            				}
            				else {
HXLINE( 280)					_hx_tmp = true;
            				}
            			}
            		}
HXDLIN( 280)		if (!(_hx_tmp)) {
HXLINE( 280)			return null();
            		}
HXLINE( 281)		bool _hx_tmp1;
HXDLIN( 281)		if (!(::Point2D_obj::isPoint(to))) {
HXLINE( 281)			_hx_tmp1 = false;
            		}
            		else {
HXLINE( 281)			 ::Dynamic x = ::Point2D_obj::xFromString(to);
HXDLIN( 281)			bool _hx_tmp;
HXDLIN( 281)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 281)				int a = ( (int)(x) );
HXDLIN( 281)				int b = this->gridCols;
HXDLIN( 281)				bool aNeg = (a < 0);
HXDLIN( 281)				bool bNeg = (b < 0);
HXDLIN( 281)				if ((aNeg != bNeg)) {
HXLINE( 281)					_hx_tmp = aNeg;
            				}
            				else {
HXLINE( 281)					_hx_tmp = (a >= b);
            				}
            			}
            			else {
HXLINE( 281)				_hx_tmp = true;
            			}
HXDLIN( 281)			if (_hx_tmp) {
HXLINE( 281)				_hx_tmp1 = false;
            			}
            			else {
HXLINE( 281)				 ::Dynamic y = ::Point2D_obj::yFromString(to);
HXDLIN( 281)				bool _hx_tmp;
HXDLIN( 281)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 281)					int a = ( (int)(y) );
HXDLIN( 281)					int b = this->gridRows;
HXDLIN( 281)					bool aNeg = (a < 0);
HXDLIN( 281)					bool bNeg = (b < 0);
HXDLIN( 281)					if ((aNeg != bNeg)) {
HXLINE( 281)						_hx_tmp = aNeg;
            					}
            					else {
HXLINE( 281)						_hx_tmp = (a >= b);
            					}
            				}
            				else {
HXLINE( 281)					_hx_tmp = true;
            				}
HXDLIN( 281)				if (_hx_tmp) {
HXLINE( 281)					_hx_tmp1 = false;
            				}
            				else {
HXLINE( 281)					_hx_tmp1 = true;
            				}
            			}
            		}
HXDLIN( 281)		if (!(_hx_tmp1)) {
HXLINE( 281)			return null();
            		}
HXLINE( 283)		 ::Dynamic dx = ::Point2D_obj::xFromString(to);
HXDLIN( 283)		int dx1 = (( (int)(dx) ) - ( (int)(::Point2D_obj::xFromString(from)) ));
HXLINE( 284)		 ::Dynamic dy = ::Point2D_obj::yFromString(to);
HXDLIN( 284)		int dy1 = (( (int)(dy) ) - ( (int)(::Point2D_obj::yFromString(from)) ));
HXLINE( 286)		switch((int)(dir->_hx_getIndex())){
            			case (int)0: {
HXLINE( 288)				return ((2 * dx1) < -(dy1));
            			}
            			break;
            			case (int)1: {
HXLINE( 290)				return ((2 * dx1) > -(dy1));
            			}
            			break;
            			case (int)2: {
HXLINE( 292)				return (dy1 < 0);
            			}
            			break;
            			case (int)3: {
HXLINE( 294)				return (dy1 > 0);
            			}
            			break;
            		}
HXLINE( 286)		return false;
            	}


HX_DEFINE_DYNAMIC_FUNC3(HexGrid_obj,isInDirectionOf,return )

::String HexGrid_obj::closestCellInDirection(::String p, ::Direction dir){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_299_closestCellInDirection)
HXLINE( 300)		bool _hx_tmp;
HXDLIN( 300)		if (!(::Point2D_obj::isPoint(p))) {
HXLINE( 300)			_hx_tmp = false;
            		}
            		else {
HXLINE( 300)			 ::Dynamic x = ::Point2D_obj::xFromString(p);
HXDLIN( 300)			bool _hx_tmp1;
HXDLIN( 300)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 300)				int a = ( (int)(x) );
HXDLIN( 300)				int b = this->gridCols;
HXDLIN( 300)				bool aNeg = (a < 0);
HXDLIN( 300)				bool bNeg = (b < 0);
HXDLIN( 300)				if ((aNeg != bNeg)) {
HXLINE( 300)					_hx_tmp1 = aNeg;
            				}
            				else {
HXLINE( 300)					_hx_tmp1 = (a >= b);
            				}
            			}
            			else {
HXLINE( 300)				_hx_tmp1 = true;
            			}
HXDLIN( 300)			if (_hx_tmp1) {
HXLINE( 300)				_hx_tmp = false;
            			}
            			else {
HXLINE( 300)				 ::Dynamic y = ::Point2D_obj::yFromString(p);
HXDLIN( 300)				bool _hx_tmp1;
HXDLIN( 300)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 300)					int a = ( (int)(y) );
HXDLIN( 300)					int b = this->gridRows;
HXDLIN( 300)					bool aNeg = (a < 0);
HXDLIN( 300)					bool bNeg = (b < 0);
HXDLIN( 300)					if ((aNeg != bNeg)) {
HXLINE( 300)						_hx_tmp1 = aNeg;
            					}
            					else {
HXLINE( 300)						_hx_tmp1 = (a >= b);
            					}
            				}
            				else {
HXLINE( 300)					_hx_tmp1 = true;
            				}
HXDLIN( 300)				if (_hx_tmp1) {
HXLINE( 300)					_hx_tmp = false;
            				}
            				else {
HXLINE( 300)					_hx_tmp = true;
            				}
            			}
            		}
HXDLIN( 300)		if (!(_hx_tmp)) {
HXLINE( 300)			return null();
            		}
HXLINE( 302)		::String closestCell = p;
HXLINE( 303)		 ::Dynamic closestDistanceSquared = 0;
HXLINE( 304)		int closestYDiff = 0;
HXLINE( 308)		 ::Dynamic x = ::Point2D_obj::xFromString(p);
HXLINE( 309)		 ::Dynamic y = ::Point2D_obj::yFromString(p);
HXLINE( 311)		{
HXLINE( 311)			 ::Dynamic q = this->cells->keys();
HXDLIN( 311)			while(( (bool)(q->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 311)				::String q1 = ( (::String)(q->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXLINE( 312)				bool _hx_tmp;
HXDLIN( 312)				if (!(::Point2D_obj::isPoint(q1))) {
HXLINE( 312)					_hx_tmp = false;
            				}
            				else {
HXLINE( 312)					 ::Dynamic x = ::Point2D_obj::xFromString(q1);
HXDLIN( 312)					bool _hx_tmp1;
HXDLIN( 312)					if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 312)						int a = ( (int)(x) );
HXDLIN( 312)						int b = this->gridCols;
HXDLIN( 312)						bool aNeg = (a < 0);
HXDLIN( 312)						bool bNeg = (b < 0);
HXDLIN( 312)						if ((aNeg != bNeg)) {
HXLINE( 312)							_hx_tmp1 = aNeg;
            						}
            						else {
HXLINE( 312)							_hx_tmp1 = (a >= b);
            						}
            					}
            					else {
HXLINE( 312)						_hx_tmp1 = true;
            					}
HXDLIN( 312)					if (_hx_tmp1) {
HXLINE( 312)						_hx_tmp = false;
            					}
            					else {
HXLINE( 312)						 ::Dynamic y = ::Point2D_obj::yFromString(q1);
HXDLIN( 312)						bool _hx_tmp1;
HXDLIN( 312)						if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 312)							int a = ( (int)(y) );
HXDLIN( 312)							int b = this->gridRows;
HXDLIN( 312)							bool aNeg = (a < 0);
HXDLIN( 312)							bool bNeg = (b < 0);
HXDLIN( 312)							if ((aNeg != bNeg)) {
HXLINE( 312)								_hx_tmp1 = aNeg;
            							}
            							else {
HXLINE( 312)								_hx_tmp1 = (a >= b);
            							}
            						}
            						else {
HXLINE( 312)							_hx_tmp1 = true;
            						}
HXDLIN( 312)						if (_hx_tmp1) {
HXLINE( 312)							_hx_tmp = false;
            						}
            						else {
HXLINE( 312)							_hx_tmp = true;
            						}
            					}
            				}
HXDLIN( 312)				if (_hx_tmp) {
HXLINE( 313)					if (( (bool)(this->isInDirectionOf(q1,dir,p)) )) {
HXLINE( 315)						bool _hx_tmp;
HXDLIN( 315)						if (::hx::IsNotEq( closestDistanceSquared,0 )) {
HXLINE( 315)							_hx_tmp = ::hx::IsLess( this->distanceSquaredToCell(p,q1),closestDistanceSquared );
            						}
            						else {
HXLINE( 315)							_hx_tmp = true;
            						}
HXDLIN( 315)						if (_hx_tmp) {
HXLINE( 316)							closestCell = q1;
HXLINE( 317)							closestDistanceSquared = this->distanceSquaredToCell(p,q1);
HXLINE( 318)							 ::Dynamic closestYDiff1 = ::Point2D_obj::yFromString(q1);
HXDLIN( 318)							closestYDiff = (( (int)(closestYDiff1) ) - ( (int)(::Point2D_obj::yFromString(p)) ));
            						}
            						else {
HXLINE( 320)							if (::hx::IsEq( this->distanceSquaredToCell(p,q1),closestDistanceSquared )) {
HXLINE( 321)								 ::Dynamic yDiff = ::Point2D_obj::yFromString(q1);
HXDLIN( 321)								int yDiff1 = (( (int)(yDiff) ) - ( (int)(::Point2D_obj::yFromString(p)) ));
HXLINE( 322)								bool _hx_tmp;
HXDLIN( 322)								if (!((::Math_obj::abs(( (Float)(yDiff1) )) < ::Math_obj::abs(( (Float)(closestYDiff) ))))) {
HXLINE( 323)									if ((::Math_obj::abs(( (Float)(yDiff1) )) == ::Math_obj::abs(( (Float)(closestYDiff) )))) {
HXLINE( 322)										_hx_tmp = (yDiff1 > 0);
            									}
            									else {
HXLINE( 322)										_hx_tmp = false;
            									}
            								}
            								else {
HXLINE( 322)									_hx_tmp = true;
            								}
HXDLIN( 322)								if (_hx_tmp) {
HXLINE( 324)									closestCell = q1;
HXLINE( 325)									closestDistanceSquared = this->distanceSquaredToCell(p,q1);
HXLINE( 326)									 ::Dynamic closestYDiff1 = ::Point2D_obj::yFromString(q1);
HXDLIN( 326)									closestYDiff = (( (int)(closestYDiff1) ) - ( (int)(::Point2D_obj::yFromString(p)) ));
            								}
            							}
            						}
            					}
            				}
            			}
            		}
HXLINE( 333)		return closestCell;
            	}


HX_DEFINE_DYNAMIC_FUNC2(HexGrid_obj,closestCellInDirection,return )

::String HexGrid_obj::closestCellLeft(::String p){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_338_closestCellLeft)
HXDLIN( 338)		return this->closestCellInDirection(p,::Direction_obj::Left_dyn());
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,closestCellLeft,return )

::String HexGrid_obj::closestCellRight(::String p){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_342_closestCellRight)
HXDLIN( 342)		return this->closestCellInDirection(p,::Direction_obj::Right_dyn());
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,closestCellRight,return )

::String HexGrid_obj::closestCellUp(::String p){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_346_closestCellUp)
HXDLIN( 346)		return this->closestCellInDirection(p,::Direction_obj::Up_dyn());
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,closestCellUp,return )

::String HexGrid_obj::closestCellDown(::String p){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_350_closestCellDown)
HXDLIN( 350)		return this->closestCellInDirection(p,::Direction_obj::Down_dyn());
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,closestCellDown,return )

::Array< ::String > HexGrid_obj::potentialNeighbors(::String key){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_355_potentialNeighbors)
HXLINE( 356)		bool _hx_tmp;
HXDLIN( 356)		if (!(::Point2D_obj::isPoint(key))) {
HXLINE( 356)			_hx_tmp = false;
            		}
            		else {
HXLINE( 356)			 ::Dynamic x = ::Point2D_obj::xFromString(key);
HXDLIN( 356)			bool _hx_tmp1;
HXDLIN( 356)			if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 356)				int a = ( (int)(x) );
HXDLIN( 356)				int b = this->gridCols;
HXDLIN( 356)				bool aNeg = (a < 0);
HXDLIN( 356)				bool bNeg = (b < 0);
HXDLIN( 356)				if ((aNeg != bNeg)) {
HXLINE( 356)					_hx_tmp1 = aNeg;
            				}
            				else {
HXLINE( 356)					_hx_tmp1 = (a >= b);
            				}
            			}
            			else {
HXLINE( 356)				_hx_tmp1 = true;
            			}
HXDLIN( 356)			if (_hx_tmp1) {
HXLINE( 356)				_hx_tmp = false;
            			}
            			else {
HXLINE( 356)				 ::Dynamic y = ::Point2D_obj::yFromString(key);
HXDLIN( 356)				bool _hx_tmp1;
HXDLIN( 356)				if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 356)					int a = ( (int)(y) );
HXDLIN( 356)					int b = this->gridRows;
HXDLIN( 356)					bool aNeg = (a < 0);
HXDLIN( 356)					bool bNeg = (b < 0);
HXDLIN( 356)					if ((aNeg != bNeg)) {
HXLINE( 356)						_hx_tmp1 = aNeg;
            					}
            					else {
HXLINE( 356)						_hx_tmp1 = (a >= b);
            					}
            				}
            				else {
HXLINE( 356)					_hx_tmp1 = true;
            				}
HXDLIN( 356)				if (_hx_tmp1) {
HXLINE( 356)					_hx_tmp = false;
            				}
            				else {
HXLINE( 356)					_hx_tmp = true;
            				}
            			}
            		}
HXDLIN( 356)		if (_hx_tmp) {
HXLINE( 358)			::Array< ::String > neighbors = ::Array_obj< ::String >::__new(0);
HXLINE( 360)			 ::Dynamic x = ::Point2D_obj::xFromString(key);
HXDLIN( 360)			 ::Dynamic y = ::Point2D_obj::yFromString(key);
HXLINE( 362)			{
HXLINE( 362)				{
HXLINE( 362)					::String n = ::Point2D_obj::coordsToString(( (int)(x) ),(( (int)(y) ) - 1));
HXLINE( 368)					bool _hx_tmp;
HXDLIN( 368)					bool _hx_tmp1;
HXDLIN( 368)					if (!(::Point2D_obj::isPoint(n))) {
HXLINE( 368)						_hx_tmp1 = false;
            					}
            					else {
HXLINE( 368)						 ::Dynamic x = ::Point2D_obj::xFromString(n);
HXDLIN( 368)						bool _hx_tmp;
HXDLIN( 368)						if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 368)							int a = ( (int)(x) );
HXDLIN( 368)							int b = this->gridCols;
HXDLIN( 368)							bool aNeg = (a < 0);
HXDLIN( 368)							bool bNeg = (b < 0);
HXDLIN( 368)							if ((aNeg != bNeg)) {
HXLINE( 368)								_hx_tmp = aNeg;
            							}
            							else {
HXLINE( 368)								_hx_tmp = (a >= b);
            							}
            						}
            						else {
HXLINE( 368)							_hx_tmp = true;
            						}
HXDLIN( 368)						if (_hx_tmp) {
HXLINE( 368)							_hx_tmp1 = false;
            						}
            						else {
HXLINE( 368)							 ::Dynamic y = ::Point2D_obj::yFromString(n);
HXDLIN( 368)							bool _hx_tmp;
HXDLIN( 368)							if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 368)								int a = ( (int)(y) );
HXDLIN( 368)								int b = this->gridRows;
HXDLIN( 368)								bool aNeg = (a < 0);
HXDLIN( 368)								bool bNeg = (b < 0);
HXDLIN( 368)								if ((aNeg != bNeg)) {
HXLINE( 368)									_hx_tmp = aNeg;
            								}
            								else {
HXLINE( 368)									_hx_tmp = (a >= b);
            								}
            							}
            							else {
HXLINE( 368)								_hx_tmp = true;
            							}
HXDLIN( 368)							if (_hx_tmp) {
HXLINE( 368)								_hx_tmp1 = false;
            							}
            							else {
HXLINE( 368)								_hx_tmp1 = true;
            							}
            						}
            					}
HXDLIN( 368)					if (_hx_tmp1) {
HXLINE( 368)						_hx_tmp = !(( ( ::Cell)(this->cells->get(key)) )->neighbors->contains(n));
            					}
            					else {
HXLINE( 368)						_hx_tmp = false;
            					}
HXDLIN( 368)					if (_hx_tmp) {
HXLINE( 368)						neighbors->push(n);
            					}
            				}
HXLINE( 362)				{
HXLINE( 362)					::String n1 = ::Point2D_obj::coordsToString((x + 1),(( (int)(y) ) - 1));
HXLINE( 368)					bool _hx_tmp2;
HXDLIN( 368)					bool _hx_tmp3;
HXDLIN( 368)					if (!(::Point2D_obj::isPoint(n1))) {
HXLINE( 368)						_hx_tmp3 = false;
            					}
            					else {
HXLINE( 368)						 ::Dynamic x = ::Point2D_obj::xFromString(n1);
HXDLIN( 368)						bool _hx_tmp;
HXDLIN( 368)						if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 368)							int a = ( (int)(x) );
HXDLIN( 368)							int b = this->gridCols;
HXDLIN( 368)							bool aNeg = (a < 0);
HXDLIN( 368)							bool bNeg = (b < 0);
HXDLIN( 368)							if ((aNeg != bNeg)) {
HXLINE( 368)								_hx_tmp = aNeg;
            							}
            							else {
HXLINE( 368)								_hx_tmp = (a >= b);
            							}
            						}
            						else {
HXLINE( 368)							_hx_tmp = true;
            						}
HXDLIN( 368)						if (_hx_tmp) {
HXLINE( 368)							_hx_tmp3 = false;
            						}
            						else {
HXLINE( 368)							 ::Dynamic y = ::Point2D_obj::yFromString(n1);
HXDLIN( 368)							bool _hx_tmp;
HXDLIN( 368)							if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 368)								int a = ( (int)(y) );
HXDLIN( 368)								int b = this->gridRows;
HXDLIN( 368)								bool aNeg = (a < 0);
HXDLIN( 368)								bool bNeg = (b < 0);
HXDLIN( 368)								if ((aNeg != bNeg)) {
HXLINE( 368)									_hx_tmp = aNeg;
            								}
            								else {
HXLINE( 368)									_hx_tmp = (a >= b);
            								}
            							}
            							else {
HXLINE( 368)								_hx_tmp = true;
            							}
HXDLIN( 368)							if (_hx_tmp) {
HXLINE( 368)								_hx_tmp3 = false;
            							}
            							else {
HXLINE( 368)								_hx_tmp3 = true;
            							}
            						}
            					}
HXDLIN( 368)					if (_hx_tmp3) {
HXLINE( 368)						_hx_tmp2 = !(( ( ::Cell)(this->cells->get(key)) )->neighbors->contains(n1));
            					}
            					else {
HXLINE( 368)						_hx_tmp2 = false;
            					}
HXDLIN( 368)					if (_hx_tmp2) {
HXLINE( 368)						neighbors->push(n1);
            					}
            				}
HXLINE( 363)				{
HXLINE( 363)					::String n2 = ::Point2D_obj::coordsToString((( (int)(x) ) - 1),( (int)(y) ));
HXLINE( 368)					bool _hx_tmp4;
HXDLIN( 368)					bool _hx_tmp5;
HXDLIN( 368)					if (!(::Point2D_obj::isPoint(n2))) {
HXLINE( 368)						_hx_tmp5 = false;
            					}
            					else {
HXLINE( 368)						 ::Dynamic x = ::Point2D_obj::xFromString(n2);
HXDLIN( 368)						bool _hx_tmp;
HXDLIN( 368)						if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 368)							int a = ( (int)(x) );
HXDLIN( 368)							int b = this->gridCols;
HXDLIN( 368)							bool aNeg = (a < 0);
HXDLIN( 368)							bool bNeg = (b < 0);
HXDLIN( 368)							if ((aNeg != bNeg)) {
HXLINE( 368)								_hx_tmp = aNeg;
            							}
            							else {
HXLINE( 368)								_hx_tmp = (a >= b);
            							}
            						}
            						else {
HXLINE( 368)							_hx_tmp = true;
            						}
HXDLIN( 368)						if (_hx_tmp) {
HXLINE( 368)							_hx_tmp5 = false;
            						}
            						else {
HXLINE( 368)							 ::Dynamic y = ::Point2D_obj::yFromString(n2);
HXDLIN( 368)							bool _hx_tmp;
HXDLIN( 368)							if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 368)								int a = ( (int)(y) );
HXDLIN( 368)								int b = this->gridRows;
HXDLIN( 368)								bool aNeg = (a < 0);
HXDLIN( 368)								bool bNeg = (b < 0);
HXDLIN( 368)								if ((aNeg != bNeg)) {
HXLINE( 368)									_hx_tmp = aNeg;
            								}
            								else {
HXLINE( 368)									_hx_tmp = (a >= b);
            								}
            							}
            							else {
HXLINE( 368)								_hx_tmp = true;
            							}
HXDLIN( 368)							if (_hx_tmp) {
HXLINE( 368)								_hx_tmp5 = false;
            							}
            							else {
HXLINE( 368)								_hx_tmp5 = true;
            							}
            						}
            					}
HXDLIN( 368)					if (_hx_tmp5) {
HXLINE( 368)						_hx_tmp4 = !(( ( ::Cell)(this->cells->get(key)) )->neighbors->contains(n2));
            					}
            					else {
HXLINE( 368)						_hx_tmp4 = false;
            					}
HXDLIN( 368)					if (_hx_tmp4) {
HXLINE( 368)						neighbors->push(n2);
            					}
            				}
HXLINE( 363)				{
HXLINE( 363)					::String n3 = ::Point2D_obj::coordsToString((x + 1),( (int)(y) ));
HXLINE( 368)					bool _hx_tmp6;
HXDLIN( 368)					bool _hx_tmp7;
HXDLIN( 368)					if (!(::Point2D_obj::isPoint(n3))) {
HXLINE( 368)						_hx_tmp7 = false;
            					}
            					else {
HXLINE( 368)						 ::Dynamic x = ::Point2D_obj::xFromString(n3);
HXDLIN( 368)						bool _hx_tmp;
HXDLIN( 368)						if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 368)							int a = ( (int)(x) );
HXDLIN( 368)							int b = this->gridCols;
HXDLIN( 368)							bool aNeg = (a < 0);
HXDLIN( 368)							bool bNeg = (b < 0);
HXDLIN( 368)							if ((aNeg != bNeg)) {
HXLINE( 368)								_hx_tmp = aNeg;
            							}
            							else {
HXLINE( 368)								_hx_tmp = (a >= b);
            							}
            						}
            						else {
HXLINE( 368)							_hx_tmp = true;
            						}
HXDLIN( 368)						if (_hx_tmp) {
HXLINE( 368)							_hx_tmp7 = false;
            						}
            						else {
HXLINE( 368)							 ::Dynamic y = ::Point2D_obj::yFromString(n3);
HXDLIN( 368)							bool _hx_tmp;
HXDLIN( 368)							if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 368)								int a = ( (int)(y) );
HXDLIN( 368)								int b = this->gridRows;
HXDLIN( 368)								bool aNeg = (a < 0);
HXDLIN( 368)								bool bNeg = (b < 0);
HXDLIN( 368)								if ((aNeg != bNeg)) {
HXLINE( 368)									_hx_tmp = aNeg;
            								}
            								else {
HXLINE( 368)									_hx_tmp = (a >= b);
            								}
            							}
            							else {
HXLINE( 368)								_hx_tmp = true;
            							}
HXDLIN( 368)							if (_hx_tmp) {
HXLINE( 368)								_hx_tmp7 = false;
            							}
            							else {
HXLINE( 368)								_hx_tmp7 = true;
            							}
            						}
            					}
HXDLIN( 368)					if (_hx_tmp7) {
HXLINE( 368)						_hx_tmp6 = !(( ( ::Cell)(this->cells->get(key)) )->neighbors->contains(n3));
            					}
            					else {
HXLINE( 368)						_hx_tmp6 = false;
            					}
HXDLIN( 368)					if (_hx_tmp6) {
HXLINE( 368)						neighbors->push(n3);
            					}
            				}
HXLINE( 364)				{
HXLINE( 364)					::String n4 = ::Point2D_obj::coordsToString((( (int)(x) ) - 1),(y + 1));
HXLINE( 368)					bool _hx_tmp8;
HXDLIN( 368)					bool _hx_tmp9;
HXDLIN( 368)					if (!(::Point2D_obj::isPoint(n4))) {
HXLINE( 368)						_hx_tmp9 = false;
            					}
            					else {
HXLINE( 368)						 ::Dynamic x = ::Point2D_obj::xFromString(n4);
HXDLIN( 368)						bool _hx_tmp;
HXDLIN( 368)						if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 368)							int a = ( (int)(x) );
HXDLIN( 368)							int b = this->gridCols;
HXDLIN( 368)							bool aNeg = (a < 0);
HXDLIN( 368)							bool bNeg = (b < 0);
HXDLIN( 368)							if ((aNeg != bNeg)) {
HXLINE( 368)								_hx_tmp = aNeg;
            							}
            							else {
HXLINE( 368)								_hx_tmp = (a >= b);
            							}
            						}
            						else {
HXLINE( 368)							_hx_tmp = true;
            						}
HXDLIN( 368)						if (_hx_tmp) {
HXLINE( 368)							_hx_tmp9 = false;
            						}
            						else {
HXLINE( 368)							 ::Dynamic y = ::Point2D_obj::yFromString(n4);
HXDLIN( 368)							bool _hx_tmp;
HXDLIN( 368)							if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 368)								int a = ( (int)(y) );
HXDLIN( 368)								int b = this->gridRows;
HXDLIN( 368)								bool aNeg = (a < 0);
HXDLIN( 368)								bool bNeg = (b < 0);
HXDLIN( 368)								if ((aNeg != bNeg)) {
HXLINE( 368)									_hx_tmp = aNeg;
            								}
            								else {
HXLINE( 368)									_hx_tmp = (a >= b);
            								}
            							}
            							else {
HXLINE( 368)								_hx_tmp = true;
            							}
HXDLIN( 368)							if (_hx_tmp) {
HXLINE( 368)								_hx_tmp9 = false;
            							}
            							else {
HXLINE( 368)								_hx_tmp9 = true;
            							}
            						}
            					}
HXDLIN( 368)					if (_hx_tmp9) {
HXLINE( 368)						_hx_tmp8 = !(( ( ::Cell)(this->cells->get(key)) )->neighbors->contains(n4));
            					}
            					else {
HXLINE( 368)						_hx_tmp8 = false;
            					}
HXDLIN( 368)					if (_hx_tmp8) {
HXLINE( 368)						neighbors->push(n4);
            					}
            				}
HXLINE( 364)				{
HXLINE( 364)					::String n5 = ::Point2D_obj::coordsToString(( (int)(x) ),(y + 1));
HXLINE( 368)					bool _hx_tmp10;
HXDLIN( 368)					bool _hx_tmp11;
HXDLIN( 368)					if (!(::Point2D_obj::isPoint(n5))) {
HXLINE( 368)						_hx_tmp11 = false;
            					}
            					else {
HXLINE( 368)						 ::Dynamic x = ::Point2D_obj::xFromString(n5);
HXDLIN( 368)						bool _hx_tmp;
HXDLIN( 368)						if (::hx::IsGreaterEq( x,0 )) {
HXLINE( 368)							int a = ( (int)(x) );
HXDLIN( 368)							int b = this->gridCols;
HXDLIN( 368)							bool aNeg = (a < 0);
HXDLIN( 368)							bool bNeg = (b < 0);
HXDLIN( 368)							if ((aNeg != bNeg)) {
HXLINE( 368)								_hx_tmp = aNeg;
            							}
            							else {
HXLINE( 368)								_hx_tmp = (a >= b);
            							}
            						}
            						else {
HXLINE( 368)							_hx_tmp = true;
            						}
HXDLIN( 368)						if (_hx_tmp) {
HXLINE( 368)							_hx_tmp11 = false;
            						}
            						else {
HXLINE( 368)							 ::Dynamic y = ::Point2D_obj::yFromString(n5);
HXDLIN( 368)							bool _hx_tmp;
HXDLIN( 368)							if (::hx::IsGreaterEq( y,0 )) {
HXLINE( 368)								int a = ( (int)(y) );
HXDLIN( 368)								int b = this->gridRows;
HXDLIN( 368)								bool aNeg = (a < 0);
HXDLIN( 368)								bool bNeg = (b < 0);
HXDLIN( 368)								if ((aNeg != bNeg)) {
HXLINE( 368)									_hx_tmp = aNeg;
            								}
            								else {
HXLINE( 368)									_hx_tmp = (a >= b);
            								}
            							}
            							else {
HXLINE( 368)								_hx_tmp = true;
            							}
HXDLIN( 368)							if (_hx_tmp) {
HXLINE( 368)								_hx_tmp11 = false;
            							}
            							else {
HXLINE( 368)								_hx_tmp11 = true;
            							}
            						}
            					}
HXDLIN( 368)					if (_hx_tmp11) {
HXLINE( 368)						_hx_tmp10 = !(( ( ::Cell)(this->cells->get(key)) )->neighbors->contains(n5));
            					}
            					else {
HXLINE( 368)						_hx_tmp10 = false;
            					}
HXDLIN( 368)					if (_hx_tmp10) {
HXLINE( 368)						neighbors->push(n5);
            					}
            				}
            			}
HXLINE( 371)			return neighbors;
            		}
HXLINE( 374)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC1(HexGrid_obj,potentialNeighbors,return )

::Array< ::String > HexGrid_obj::cellKeysWithPotentialNeighbors(){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_379_cellKeysWithPotentialNeighbors)
HXLINE( 381)		::Array< ::String > keys = ::Array_obj< ::String >::__new(0);
HXLINE( 383)		{
HXLINE( 383)			 ::Dynamic k = this->cells->keys();
HXDLIN( 383)			while(( (bool)(k->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 383)				::String k1 = ( (::String)(k->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXLINE( 384)				if ((this->potentialNeighbors(k1)->length > 0)) {
HXLINE( 385)					keys->push(k1);
            				}
            			}
            		}
HXLINE( 389)		return keys;
            	}


HX_DEFINE_DYNAMIC_FUNC0(HexGrid_obj,cellKeysWithPotentialNeighbors,return )

void HexGrid_obj::display(){
            	HX_STACKFRAME(&_hx_pos_5626eb4025a6df3e_394_display)
HXDLIN( 394)		this->window->display();
            	}


HX_DEFINE_DYNAMIC_FUNC0(HexGrid_obj,display,(void))


::hx::ObjectPtr< HexGrid_obj > HexGrid_obj::__new(int gridRows,int gridCols,int cellRows,int cellCols,::String name) {
	::hx::ObjectPtr< HexGrid_obj > __this = new HexGrid_obj();
	__this->__construct(gridRows,gridCols,cellRows,cellCols,name);
	return __this;
}

::hx::ObjectPtr< HexGrid_obj > HexGrid_obj::__alloc(::hx::Ctx *_hx_ctx,int gridRows,int gridCols,int cellRows,int cellCols,::String name) {
	HexGrid_obj *__this = (HexGrid_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(HexGrid_obj), true, "HexGrid"));
	*(void **)__this = HexGrid_obj::_hx_vtable;
	__this->__construct(gridRows,gridCols,cellRows,cellCols,name);
	return __this;
}

HexGrid_obj::HexGrid_obj()
{
}

void HexGrid_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(HexGrid);
	HX_MARK_MEMBER_NAME(window,"window");
	HX_MARK_MEMBER_NAME(leftCellBracket,"leftCellBracket");
	HX_MARK_MEMBER_NAME(rightCellBracket,"rightCellBracket");
	HX_MARK_MEMBER_NAME(gridRows,"gridRows");
	HX_MARK_MEMBER_NAME(gridCols,"gridCols");
	HX_MARK_MEMBER_NAME(cellRows,"cellRows");
	HX_MARK_MEMBER_NAME(cellCols,"cellCols");
	 ::Grid_obj::__Mark(HX_MARK_ARG);
	HX_MARK_END_CLASS();
}

void HexGrid_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(window,"window");
	HX_VISIT_MEMBER_NAME(leftCellBracket,"leftCellBracket");
	HX_VISIT_MEMBER_NAME(rightCellBracket,"rightCellBracket");
	HX_VISIT_MEMBER_NAME(gridRows,"gridRows");
	HX_VISIT_MEMBER_NAME(gridCols,"gridCols");
	HX_VISIT_MEMBER_NAME(cellRows,"cellRows");
	HX_VISIT_MEMBER_NAME(cellCols,"cellCols");
	 ::Grid_obj::__Visit(HX_VISIT_ARG);
}

::hx::Val HexGrid_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"window") ) { return ::hx::Val( window ); }
		if (HX_FIELD_EQ(inName,"isUpOf") ) { return ::hx::Val( isUpOf_dyn() ); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"toCellX") ) { return ::hx::Val( toCellX_dyn() ); }
		if (HX_FIELD_EQ(inName,"toCellY") ) { return ::hx::Val( toCellY_dyn() ); }
		if (HX_FIELD_EQ(inName,"display") ) { return ::hx::Val( display_dyn() ); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"gridRows") ) { return ::hx::Val( gridRows ); }
		if (HX_FIELD_EQ(inName,"gridCols") ) { return ::hx::Val( gridCols ); }
		if (HX_FIELD_EQ(inName,"cellRows") ) { return ::hx::Val( cellRows ); }
		if (HX_FIELD_EQ(inName,"cellCols") ) { return ::hx::Val( cellCols ); }
		if (HX_FIELD_EQ(inName,"isLeftOf") ) { return ::hx::Val( isLeftOf_dyn() ); }
		if (HX_FIELD_EQ(inName,"isDownOf") ) { return ::hx::Val( isDownOf_dyn() ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"toCellKey") ) { return ::hx::Val( toCellKey_dyn() ); }
		if (HX_FIELD_EQ(inName,"isRightOf") ) { return ::hx::Val( isRightOf_dyn() ); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"angleToCell") ) { return ::hx::Val( angleToCell_dyn() ); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"isValidPoint") ) { return ::hx::Val( isValidPoint_dyn() ); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"fillWithCells") ) { return ::hx::Val( fillWithCells_dyn() ); }
		if (HX_FIELD_EQ(inName,"allCellCoords") ) { return ::hx::Val( allCellCoords_dyn() ); }
		if (HX_FIELD_EQ(inName,"closestCellUp") ) { return ::hx::Val( closestCellUp_dyn() ); }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"leftCellBracket") ) { return ::hx::Val( leftCellBracket ); }
		if (HX_FIELD_EQ(inName,"isInDirectionOf") ) { return ::hx::Val( isInDirectionOf_dyn() ); }
		if (HX_FIELD_EQ(inName,"closestCellLeft") ) { return ::hx::Val( closestCellLeft_dyn() ); }
		if (HX_FIELD_EQ(inName,"closestCellDown") ) { return ::hx::Val( closestCellDown_dyn() ); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"rightCellBracket") ) { return ::hx::Val( rightCellBracket ); }
		if (HX_FIELD_EQ(inName,"getRowFromCoords") ) { return ::hx::Val( getRowFromCoords_dyn() ); }
		if (HX_FIELD_EQ(inName,"closestCellRight") ) { return ::hx::Val( closestCellRight_dyn() ); }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"set_activeCellKey") ) { return ::hx::Val( set_activeCellKey_dyn() ); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"potentialNeighbors") ) { return ::hx::Val( potentialNeighbors_dyn() ); }
		break;
	case 19:
		if (HX_FIELD_EQ(inName,"getColumnFromCoords") ) { return ::hx::Val( getColumnFromCoords_dyn() ); }
		break;
	case 21:
		if (HX_FIELD_EQ(inName,"distanceSquaredToCell") ) { return ::hx::Val( distanceSquaredToCell_dyn() ); }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"closestCellInDirection") ) { return ::hx::Val( closestCellInDirection_dyn() ); }
		break;
	case 30:
		if (HX_FIELD_EQ(inName,"cellKeysWithPotentialNeighbors") ) { return ::hx::Val( cellKeysWithPotentialNeighbors_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val HexGrid_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"window") ) { window=inValue.Cast<  ::TextWindow >(); return inValue; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"gridRows") ) { gridRows=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"gridCols") ) { gridCols=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"cellRows") ) { cellRows=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"cellCols") ) { cellCols=inValue.Cast< int >(); return inValue; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"leftCellBracket") ) { leftCellBracket=inValue.Cast<  ::TextWindow >(); return inValue; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"rightCellBracket") ) { rightCellBracket=inValue.Cast<  ::TextWindow >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void HexGrid_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("window",f0,93,8c,52));
	outFields->push(HX_("leftCellBracket",df,73,88,5d));
	outFields->push(HX_("rightCellBracket",2a,86,e3,62));
	outFields->push(HX_("gridRows",ff,d2,ed,4d));
	outFields->push(HX_("gridCols",19,96,03,44));
	outFields->push(HX_("cellRows",db,bb,d3,1a));
	outFields->push(HX_("cellCols",f5,7e,e9,10));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo HexGrid_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::TextWindow */ ,(int)offsetof(HexGrid_obj,window),HX_("window",f0,93,8c,52)},
	{::hx::fsObject /*  ::TextWindow */ ,(int)offsetof(HexGrid_obj,leftCellBracket),HX_("leftCellBracket",df,73,88,5d)},
	{::hx::fsObject /*  ::TextWindow */ ,(int)offsetof(HexGrid_obj,rightCellBracket),HX_("rightCellBracket",2a,86,e3,62)},
	{::hx::fsInt,(int)offsetof(HexGrid_obj,gridRows),HX_("gridRows",ff,d2,ed,4d)},
	{::hx::fsInt,(int)offsetof(HexGrid_obj,gridCols),HX_("gridCols",19,96,03,44)},
	{::hx::fsInt,(int)offsetof(HexGrid_obj,cellRows),HX_("cellRows",db,bb,d3,1a)},
	{::hx::fsInt,(int)offsetof(HexGrid_obj,cellCols),HX_("cellCols",f5,7e,e9,10)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *HexGrid_obj_sStaticStorageInfo = 0;
#endif

static ::String HexGrid_obj_sMemberFields[] = {
	HX_("window",f0,93,8c,52),
	HX_("leftCellBracket",df,73,88,5d),
	HX_("rightCellBracket",2a,86,e3,62),
	HX_("gridRows",ff,d2,ed,4d),
	HX_("gridCols",19,96,03,44),
	HX_("cellRows",db,bb,d3,1a),
	HX_("cellCols",f5,7e,e9,10),
	HX_("set_activeCellKey",5a,7f,62,cf),
	HX_("isValidPoint",3e,46,ee,e6),
	HX_("toCellKey",e2,88,4f,1d),
	HX_("toCellX",fb,98,44,10),
	HX_("toCellY",fc,98,44,10),
	HX_("getRowFromCoords",6c,9d,b6,e5),
	HX_("getColumnFromCoords",54,8c,86,bd),
	HX_("fillWithCells",a8,59,f6,a8),
	HX_("allCellCoords",e1,2f,b2,be),
	HX_("distanceSquaredToCell",cf,80,c4,70),
	HX_("angleToCell",f0,64,b2,88),
	HX_("isLeftOf",88,38,31,f2),
	HX_("isRightOf",49,7d,62,17),
	HX_("isUpOf",5c,fd,11,6b),
	HX_("isDownOf",a3,35,90,8c),
	HX_("isInDirectionOf",07,6b,35,82),
	HX_("closestCellInDirection",bf,f0,93,67),
	HX_("closestCellLeft",42,e6,00,45),
	HX_("closestCellRight",41,a1,d5,92),
	HX_("closestCellUp",d6,af,cf,f3),
	HX_("closestCellDown",9d,d6,be,3f),
	HX_("potentialNeighbors",83,d5,bd,3f),
	HX_("cellKeysWithPotentialNeighbors",7f,7e,57,c2),
	HX_("display",42,2a,4a,bb),
	::String(null()) };

::hx::Class HexGrid_obj::__mClass;

void HexGrid_obj::__register()
{
	HexGrid_obj _hx_dummy;
	HexGrid_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("HexGrid",21,77,6f,5b);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(HexGrid_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< HexGrid_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = HexGrid_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = HexGrid_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

