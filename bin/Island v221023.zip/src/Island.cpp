#include <hxcpp.h>

#ifndef INCLUDED_95f339a1d026d52c
#define INCLUDED_95f339a1d026d52c
#include "hxMath.h"
#endif
#ifndef INCLUDED_Building
#include <Building.h>
#endif
#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
#ifndef INCLUDED_Direction
#include <Direction.h>
#endif
#ifndef INCLUDED_GenerationType
#include <GenerationType.h>
#endif
#ifndef INCLUDED_Grid
#include <Grid.h>
#endif
#ifndef INCLUDED_HexGrid
#include <HexGrid.h>
#endif
#ifndef INCLUDED_Island
#include <Island.h>
#endif
#ifndef INCLUDED_IslandCell
#include <IslandCell.h>
#endif
#ifndef INCLUDED_MenuState
#include <MenuState.h>
#endif
#ifndef INCLUDED_Pile
#include <Pile.h>
#endif
#ifndef INCLUDED_Point2D
#include <Point2D.h>
#endif
#ifndef INCLUDED_Resource
#include <Resource.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_Sys
#include <Sys.h>
#endif
#ifndef INCLUDED_Terrain
#include <Terrain.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED_Type
#include <Type.h>
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif
#ifndef INCLUDED__Building_Building_Fields_
#include <_Building/Building_Fields_.h>
#endif
#ifndef INCLUDED__Island_Island_Fields_
#include <_Island/Island_Fields_.h>
#endif
#ifndef INCLUDED__TextScreen_ASCIIChar_Impl_
#include <_TextScreen/ASCIIChar_Impl_.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_a227ab1282d9c004_42_new,"Island","new",0x28a7d267,"Island.new","Island.hx",42,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_80_randomTerrain,"Island","randomTerrain",0xd9b8b8b9,"Island.randomTerrain","Island.hx",80,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_95_makeCell,"Island","makeCell",0xe2bf5b49,"Island.makeCell","Island.hx",95,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_104_generateEmpty,"Island","generateEmpty",0xb2967bdf,"Island.generateEmpty","Island.hx",104,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_107_generateOneCell,"Island","generateOneCell",0xf26bccfa,"Island.generateOneCell","Island.hx",107,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_112_generateFilled,"Island","generateFilled",0xa72bf410,"Island.generateFilled","Island.hx",112,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_146_growIsland,"Island","growIsland",0x5d111c21,"Island.growIsland","Island.hx",146,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_150_generateRandom,"Island","generateRandom",0xd98c0871,"Island.generateRandom","Island.hx",150,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_201_write,"Island","write",0xb7373ea6,"Island.write","Island.hx",201,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_205_getCell,"Island","getCell",0xcb8ae2df,"Island.getCell","Island.hx",205,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_209_getActiveCell,"Island","getActiveCell",0xe399b785,"Island.getActiveCell","Island.hx",209,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_215_getActiveCellKey,"Island","getActiveCellKey",0xf0354b1a,"Island.getActiveCellKey","Island.hx",215,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_221_countBuildings,"Island","countBuildings",0xcd7f8a09,"Island.countBuildings","Island.hx",221,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_234_countTerrain,"Island","countTerrain",0xb8a55bbf,"Island.countTerrain","Island.hx",234,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_256_countJobs,"Island","countJobs",0xc5dd738c,"Island.countJobs","Island.hx",256,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_264_costToUpgrade,"Island","costToUpgrade",0x51f1cd1b,"Island.costToUpgrade","Island.hx",264,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_268_costToBuild,"Island","costToBuild",0x7c1b85ed,"Island.costToBuild","Island.hx",268,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_271_isValidLocation,"Island","isValidLocation",0x087bb58e,"Island.isValidLocation","Island.hx",271,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_286_isCoastCellKey,"Island","isCoastCellKey",0xa3eec80a,"Island.isCoastCellKey","Island.hx",286,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_294_display,"Island","display",0x72953bc9,"Island.display","Island.hx",294,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_381_inputLoop,"Island","inputLoop",0x7c3a24d5,"Island.inputLoop","Island.hx",381,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_438_commandMove,"Island","commandMove",0x29816303,"Island.commandMove","Island.hx",438,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_449_commandBuild,"Island","commandBuild",0xd63a4efc,"Island.commandBuild","Island.hx",449,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_465_commandUpgrade,"Island","commandUpgrade",0x882037ea,"Island.commandUpgrade","Island.hx",465,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_477_commandNextTurn,"Island","commandNextTurn",0x2496f302,"Island.commandNextTurn","Island.hx",477,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_497_growPopulation,"Island","growPopulation",0xd2d54ad9,"Island.growPopulation","Island.hx",497,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_502_shrinkPopulation,"Island","shrinkPopulation",0x367f294f,"Island.shrinkPopulation","Island.hx",502,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_508_calculateIncome,"Island","calculateIncome",0x080df5f6,"Island.calculateIncome","Island.hx",508,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_511_calculateCellProduction,"Island","calculateCellProduction",0xf24f29c8,"Island.calculateCellProduction","Island.hx",511,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_575_calculatePrimaryProduction,"Island","calculatePrimaryProduction",0xb72ae6ee,"Island.calculatePrimaryProduction","Island.hx",575,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_595_calculateSecondaryProduction,"Island","calculateSecondaryProduction",0x4c3953e0,"Island.calculateSecondaryProduction","Island.hx",595,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_619_calculateConsumption,"Island","calculateConsumption",0x6da64d6e,"Island.calculateConsumption","Island.hx",619,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_655_calculateHappinessFromEmployment,"Island","calculateHappinessFromEmployment",0x374ddc10,"Island.calculateHappinessFromEmployment","Island.hx",655,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_658_calculateHappinessFromFood,"Island","calculateHappinessFromFood",0x4d9b2c82,"Island.calculateHappinessFromFood","Island.hx",658,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_666_calculateHappinessFromGoods,"Island","calculateHappinessFromGoods",0x2d925a32,"Island.calculateHappinessFromGoods","Island.hx",666,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_670_calculateHappinessFromTemples,"Island","calculateHappinessFromTemples",0x78a4a5e2,"Island.calculateHappinessFromTemples","Island.hx",670,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_674_calculateHappiness,"Island","calculateHappiness",0xd30a793a,"Island.calculateHappiness","Island.hx",674,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_12_boot,"Island","boot",0x6249484b,"Island.boot","Island.hx",12,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_24_boot,"Island","boot",0x6249484b,"Island.boot","Island.hx",24,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_25_boot,"Island","boot",0x6249484b,"Island.boot","Island.hx",25,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_34_boot,"Island","boot",0x6249484b,"Island.boot","Island.hx",34,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_a227ab1282d9c004_35_boot,"Island","boot",0x6249484b,"Island.boot","Island.hx",35,0xc47cb6e9)

void Island_obj::__construct(int size, ::GenerationType type,::String name){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_42_new)
HXLINE(  44)		this->mainWindow =  ::TextScreen_obj::__alloc( HX_CTX ,24,null());
HXLINE(  46)		this->name = name;
HXLINE(  47)		this->size = size;
HXLINE(  49)		this->menuState = ::MenuState_obj::Upgrade_dyn();
HXLINE(  51)		this->turn = 1;
HXLINE(  53)		this->resources =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE(  54)		this->resources->add(::Resource_obj::Grain_dyn(),50)->add(::Resource_obj::Wood_dyn(),50)->add(::Resource_obj::Metal_dyn(),50);
HXLINE(  56)		switch((int)(type->_hx_getIndex())){
            			case (int)0: {
HXLINE(  58)				this->generateEmpty();
            			}
            			break;
            			case (int)1: {
HXLINE(  60)				this->generateOneCell();
            			}
            			break;
            			case (int)2: {
HXLINE(  62)				this->generateFilled();
            			}
            			break;
            			case (int)3: {
HXLINE(  64)				this->generateRandom();
            			}
            			break;
            		}
HXLINE(  67)		this->countBuildings();
HXLINE(  69)		this->population = 3;
HXLINE(  71)		this->mainWindow->addChild(this->grid->window,5,null(),null(),null(),null(),null(),null());
HXLINE(  73)		this->infoWindow =  ::TextWindow_obj::__alloc( HX_CTX ,2,null(),HX_("info",6e,38,bb,45));
HXLINE(  74)		this->mainWindow->addChild(this->infoWindow,5,35,null(),null(),null(),null(),null());
HXLINE(  76)		this->commandWindow =  ::TextWindow_obj::__alloc( HX_CTX ,20,null(),HX_("command",4b,71,6d,81));
HXLINE(  77)		this->mainWindow->addChild(this->commandWindow,8,35,null(),null(),null(),null(),null());
            	}

Dynamic Island_obj::__CreateEmpty() { return new Island_obj; }

void *Island_obj::_hx_vtable = 0;

Dynamic Island_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Island_obj > _hx_result = new Island_obj();
	_hx_result->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return _hx_result;
}

bool Island_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x1019d5b5;
}

 ::Terrain Island_obj::randomTerrain(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_80_randomTerrain)
HXLINE(  81)		Float roll = ::Math_obj::random();
HXLINE(  83)		if ((roll < ((Float)0.4))) {
HXLINE(  84)			return ::Terrain_obj::Grass_dyn();
            		}
            		else {
HXLINE(  86)			if ((roll < ((Float)0.7))) {
HXLINE(  87)				return ::Terrain_obj::Forest_dyn();
            			}
            			else {
HXLINE(  90)				return ::Terrain_obj::Hills_dyn();
            			}
            		}
HXLINE(  83)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,randomTerrain,return )

void Island_obj::makeCell(int x,int y, ::Terrain terrain){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_95_makeCell)
HXLINE(  96)		if (::hx::IsNull( terrain )) {
HXLINE(  96)			terrain = this->randomTerrain();
            		}
HXLINE(  98)		 ::HexGrid _this = this->grid;
HXDLIN(  98)		 ::IslandCell cell =  ::IslandCell_obj::__alloc( HX_CTX ,terrain,::Point2D_obj::coordsToString(x,y));
HXLINE(  99)		cell->render();
HXLINE( 100)		{
HXLINE( 100)			 ::HexGrid _this1 = this->grid;
HXDLIN( 100)			cell->name = ::Point2D_obj::coordsToString(x,y);
HXDLIN( 100)			_this1->addCellWithoutAdjacency(cell,cell->name);
HXDLIN( 100)			{
HXLINE( 100)				{
HXLINE( 100)					::String k = ::Point2D_obj::coordsToString(x,(y - 1));
HXDLIN( 100)					{
HXLINE( 100)						::String key1 = cell->name;
HXDLIN( 100)						bool _hx_tmp;
HXDLIN( 100)						if (_this1->cells->exists(key1)) {
HXLINE( 100)							_hx_tmp = _this1->cells->exists(k);
            						}
            						else {
HXLINE( 100)							_hx_tmp = false;
            						}
HXDLIN( 100)						if (_hx_tmp) {
HXLINE( 100)							if (!(( ( ::Cell)(_this1->cells->get(key1)) )->neighbors->contains(k))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(key1)) )->neighbors->push(k);
            							}
HXDLIN( 100)							if (!(( ( ::Cell)(_this1->cells->get(k)) )->neighbors->contains(key1))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(k)) )->neighbors->push(key1);
            							}
            						}
            					}
            				}
HXDLIN( 100)				{
HXLINE( 100)					::String k1 = ::Point2D_obj::coordsToString((x + 1),(y - 1));
HXDLIN( 100)					{
HXLINE( 100)						::String key11 = cell->name;
HXDLIN( 100)						bool _hx_tmp1;
HXDLIN( 100)						if (_this1->cells->exists(key11)) {
HXLINE( 100)							_hx_tmp1 = _this1->cells->exists(k1);
            						}
            						else {
HXLINE( 100)							_hx_tmp1 = false;
            						}
HXDLIN( 100)						if (_hx_tmp1) {
HXLINE( 100)							if (!(( ( ::Cell)(_this1->cells->get(key11)) )->neighbors->contains(k1))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(key11)) )->neighbors->push(k1);
            							}
HXDLIN( 100)							if (!(( ( ::Cell)(_this1->cells->get(k1)) )->neighbors->contains(key11))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(k1)) )->neighbors->push(key11);
            							}
            						}
            					}
            				}
HXDLIN( 100)				{
HXLINE( 100)					::String k2 = ::Point2D_obj::coordsToString((x - 1),y);
HXDLIN( 100)					{
HXLINE( 100)						::String key12 = cell->name;
HXDLIN( 100)						bool _hx_tmp2;
HXDLIN( 100)						if (_this1->cells->exists(key12)) {
HXLINE( 100)							_hx_tmp2 = _this1->cells->exists(k2);
            						}
            						else {
HXLINE( 100)							_hx_tmp2 = false;
            						}
HXDLIN( 100)						if (_hx_tmp2) {
HXLINE( 100)							if (!(( ( ::Cell)(_this1->cells->get(key12)) )->neighbors->contains(k2))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(key12)) )->neighbors->push(k2);
            							}
HXDLIN( 100)							if (!(( ( ::Cell)(_this1->cells->get(k2)) )->neighbors->contains(key12))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(k2)) )->neighbors->push(key12);
            							}
            						}
            					}
            				}
HXDLIN( 100)				{
HXLINE( 100)					::String k3 = ::Point2D_obj::coordsToString((x + 1),y);
HXDLIN( 100)					{
HXLINE( 100)						::String key13 = cell->name;
HXDLIN( 100)						bool _hx_tmp3;
HXDLIN( 100)						if (_this1->cells->exists(key13)) {
HXLINE( 100)							_hx_tmp3 = _this1->cells->exists(k3);
            						}
            						else {
HXLINE( 100)							_hx_tmp3 = false;
            						}
HXDLIN( 100)						if (_hx_tmp3) {
HXLINE( 100)							if (!(( ( ::Cell)(_this1->cells->get(key13)) )->neighbors->contains(k3))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(key13)) )->neighbors->push(k3);
            							}
HXDLIN( 100)							if (!(( ( ::Cell)(_this1->cells->get(k3)) )->neighbors->contains(key13))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(k3)) )->neighbors->push(key13);
            							}
            						}
            					}
            				}
HXDLIN( 100)				{
HXLINE( 100)					::String k4 = ::Point2D_obj::coordsToString((x - 1),(y + 1));
HXDLIN( 100)					{
HXLINE( 100)						::String key14 = cell->name;
HXDLIN( 100)						bool _hx_tmp4;
HXDLIN( 100)						if (_this1->cells->exists(key14)) {
HXLINE( 100)							_hx_tmp4 = _this1->cells->exists(k4);
            						}
            						else {
HXLINE( 100)							_hx_tmp4 = false;
            						}
HXDLIN( 100)						if (_hx_tmp4) {
HXLINE( 100)							if (!(( ( ::Cell)(_this1->cells->get(key14)) )->neighbors->contains(k4))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(key14)) )->neighbors->push(k4);
            							}
HXDLIN( 100)							if (!(( ( ::Cell)(_this1->cells->get(k4)) )->neighbors->contains(key14))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(k4)) )->neighbors->push(key14);
            							}
            						}
            					}
            				}
HXDLIN( 100)				{
HXLINE( 100)					::String k5 = ::Point2D_obj::coordsToString(x,(y + 1));
HXDLIN( 100)					{
HXLINE( 100)						::String key15 = cell->name;
HXDLIN( 100)						bool _hx_tmp5;
HXDLIN( 100)						if (_this1->cells->exists(key15)) {
HXLINE( 100)							_hx_tmp5 = _this1->cells->exists(k5);
            						}
            						else {
HXLINE( 100)							_hx_tmp5 = false;
            						}
HXDLIN( 100)						if (_hx_tmp5) {
HXLINE( 100)							if (!(( ( ::Cell)(_this1->cells->get(key15)) )->neighbors->contains(k5))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(key15)) )->neighbors->push(k5);
            							}
HXDLIN( 100)							if (!(( ( ::Cell)(_this1->cells->get(k5)) )->neighbors->contains(key15))) {
HXLINE( 100)								( ( ::Cell)(_this1->cells->get(k5)) )->neighbors->push(key15);
            							}
            						}
            					}
            				}
            			}
HXDLIN( 100)			 ::TextWindow _this2 = _this1->window;
HXDLIN( 100)			int _hx_tmp6 = _this1->getRowFromCoords(x,y);
HXDLIN( 100)			_this2->addChild(cell,_hx_tmp6,_this1->getColumnFromCoords(x,y),null(),null(),null(),null(),null());
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC3(Island_obj,makeCell,(void))

void Island_obj::generateEmpty(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_104_generateEmpty)
HXDLIN( 104)		this->grid =  ::HexGrid_obj::__alloc( HX_CTX ,this->size,this->size,::Island_obj::cellRows,::Island_obj::cellCols,this->name);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,generateEmpty,(void))

void Island_obj::generateOneCell(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_107_generateOneCell)
HXLINE( 108)		this->grid =  ::HexGrid_obj::__alloc( HX_CTX ,this->size,this->size,::Island_obj::cellRows,::Island_obj::cellCols,this->name);
HXLINE( 109)		int _hx_int = this->size;
HXDLIN( 109)		Float _hx_tmp;
HXDLIN( 109)		if ((_hx_int < 0)) {
HXLINE( 109)			_hx_tmp = (((Float)4294967296.0) + _hx_int);
            		}
            		else {
HXLINE( 109)			_hx_tmp = (_hx_int + ((Float)0.0));
            		}
HXDLIN( 109)		int int1 = 2;
HXDLIN( 109)		Float _hx_tmp1;
HXDLIN( 109)		if ((int1 < 0)) {
HXLINE( 109)			_hx_tmp1 = (((Float)4294967296.0) + int1);
            		}
            		else {
HXLINE( 109)			_hx_tmp1 = (int1 + ((Float)0.0));
            		}
HXDLIN( 109)		int int2 = this->size;
HXDLIN( 109)		Float _hx_tmp2;
HXDLIN( 109)		if ((int2 < 0)) {
HXLINE( 109)			_hx_tmp2 = (((Float)4294967296.0) + int2);
            		}
            		else {
HXLINE( 109)			_hx_tmp2 = (int2 + ((Float)0.0));
            		}
HXDLIN( 109)		int int3 = 2;
HXDLIN( 109)		Float _hx_tmp3;
HXDLIN( 109)		if ((int3 < 0)) {
HXLINE( 109)			_hx_tmp3 = (((Float)4294967296.0) + int3);
            		}
            		else {
HXLINE( 109)			_hx_tmp3 = (int3 + ((Float)0.0));
            		}
HXDLIN( 109)		this->makeCell(::Math_obj::floor((_hx_tmp / _hx_tmp1)),::Math_obj::floor((_hx_tmp2 / _hx_tmp3)),null());
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,generateOneCell,(void))

void Island_obj::generateFilled(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_112_generateFilled)
HXLINE( 115)		this->grid =  ::HexGrid_obj::__alloc( HX_CTX ,this->size,this->size,::Island_obj::cellRows,::Island_obj::cellCols,this->name);
HXLINE( 117)		{
HXLINE( 117)			int _g = 0;
HXDLIN( 117)			int _g1 = this->size;
HXDLIN( 117)			while((_g < _g1)){
HXLINE( 117)				_g = (_g + 1);
HXDLIN( 117)				int r = (_g - 1);
HXLINE( 118)				{
HXLINE( 118)					int _g1 = 0;
HXDLIN( 118)					int _g2 = this->size;
HXDLIN( 118)					while((_g1 < _g2)){
HXLINE( 118)						_g1 = (_g1 + 1);
HXDLIN( 118)						int c = (_g1 - 1);
HXLINE( 119)						 ::Terrain terrain = ::Terrain_obj::Grass_dyn();
HXLINE( 120)						switch((int)(::hx::Mod((r + c),3))){
            							case (int)0: {
HXLINE( 122)								terrain = ::Terrain_obj::Grass_dyn();
            							}
            							break;
            							case (int)1: {
HXLINE( 124)								terrain = ::Terrain_obj::Forest_dyn();
            							}
            							break;
            							case (int)2: {
HXLINE( 126)								terrain = ::Terrain_obj::Hills_dyn();
            							}
            							break;
            						}
HXLINE( 129)						 ::HexGrid _this = this->grid;
HXDLIN( 129)						 ::IslandCell cell =  ::IslandCell_obj::__alloc( HX_CTX ,terrain,::Point2D_obj::coordsToString(c,r));
HXLINE( 130)						{
HXLINE( 130)							 ::HexGrid _this1 = this->grid;
HXDLIN( 130)							cell->name = ::Point2D_obj::coordsToString(c,r);
HXDLIN( 130)							_this1->addCellWithoutAdjacency(cell,cell->name);
HXDLIN( 130)							{
HXLINE( 130)								{
HXLINE( 130)									::String k = ::Point2D_obj::coordsToString(c,(r - 1));
HXDLIN( 130)									{
HXLINE( 130)										::String key1 = cell->name;
HXDLIN( 130)										bool _hx_tmp;
HXDLIN( 130)										if (_this1->cells->exists(key1)) {
HXLINE( 130)											_hx_tmp = _this1->cells->exists(k);
            										}
            										else {
HXLINE( 130)											_hx_tmp = false;
            										}
HXDLIN( 130)										if (_hx_tmp) {
HXLINE( 130)											if (!(( ( ::Cell)(_this1->cells->get(key1)) )->neighbors->contains(k))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(key1)) )->neighbors->push(k);
            											}
HXDLIN( 130)											if (!(( ( ::Cell)(_this1->cells->get(k)) )->neighbors->contains(key1))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(k)) )->neighbors->push(key1);
            											}
            										}
            									}
            								}
HXDLIN( 130)								{
HXLINE( 130)									::String k1 = ::Point2D_obj::coordsToString((c + 1),(r - 1));
HXDLIN( 130)									{
HXLINE( 130)										::String key11 = cell->name;
HXDLIN( 130)										bool _hx_tmp1;
HXDLIN( 130)										if (_this1->cells->exists(key11)) {
HXLINE( 130)											_hx_tmp1 = _this1->cells->exists(k1);
            										}
            										else {
HXLINE( 130)											_hx_tmp1 = false;
            										}
HXDLIN( 130)										if (_hx_tmp1) {
HXLINE( 130)											if (!(( ( ::Cell)(_this1->cells->get(key11)) )->neighbors->contains(k1))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(key11)) )->neighbors->push(k1);
            											}
HXDLIN( 130)											if (!(( ( ::Cell)(_this1->cells->get(k1)) )->neighbors->contains(key11))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(k1)) )->neighbors->push(key11);
            											}
            										}
            									}
            								}
HXDLIN( 130)								{
HXLINE( 130)									::String k2 = ::Point2D_obj::coordsToString((c - 1),r);
HXDLIN( 130)									{
HXLINE( 130)										::String key12 = cell->name;
HXDLIN( 130)										bool _hx_tmp2;
HXDLIN( 130)										if (_this1->cells->exists(key12)) {
HXLINE( 130)											_hx_tmp2 = _this1->cells->exists(k2);
            										}
            										else {
HXLINE( 130)											_hx_tmp2 = false;
            										}
HXDLIN( 130)										if (_hx_tmp2) {
HXLINE( 130)											if (!(( ( ::Cell)(_this1->cells->get(key12)) )->neighbors->contains(k2))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(key12)) )->neighbors->push(k2);
            											}
HXDLIN( 130)											if (!(( ( ::Cell)(_this1->cells->get(k2)) )->neighbors->contains(key12))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(k2)) )->neighbors->push(key12);
            											}
            										}
            									}
            								}
HXDLIN( 130)								{
HXLINE( 130)									::String k3 = ::Point2D_obj::coordsToString((c + 1),r);
HXDLIN( 130)									{
HXLINE( 130)										::String key13 = cell->name;
HXDLIN( 130)										bool _hx_tmp3;
HXDLIN( 130)										if (_this1->cells->exists(key13)) {
HXLINE( 130)											_hx_tmp3 = _this1->cells->exists(k3);
            										}
            										else {
HXLINE( 130)											_hx_tmp3 = false;
            										}
HXDLIN( 130)										if (_hx_tmp3) {
HXLINE( 130)											if (!(( ( ::Cell)(_this1->cells->get(key13)) )->neighbors->contains(k3))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(key13)) )->neighbors->push(k3);
            											}
HXDLIN( 130)											if (!(( ( ::Cell)(_this1->cells->get(k3)) )->neighbors->contains(key13))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(k3)) )->neighbors->push(key13);
            											}
            										}
            									}
            								}
HXDLIN( 130)								{
HXLINE( 130)									::String k4 = ::Point2D_obj::coordsToString((c - 1),(r + 1));
HXDLIN( 130)									{
HXLINE( 130)										::String key14 = cell->name;
HXDLIN( 130)										bool _hx_tmp4;
HXDLIN( 130)										if (_this1->cells->exists(key14)) {
HXLINE( 130)											_hx_tmp4 = _this1->cells->exists(k4);
            										}
            										else {
HXLINE( 130)											_hx_tmp4 = false;
            										}
HXDLIN( 130)										if (_hx_tmp4) {
HXLINE( 130)											if (!(( ( ::Cell)(_this1->cells->get(key14)) )->neighbors->contains(k4))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(key14)) )->neighbors->push(k4);
            											}
HXDLIN( 130)											if (!(( ( ::Cell)(_this1->cells->get(k4)) )->neighbors->contains(key14))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(k4)) )->neighbors->push(key14);
            											}
            										}
            									}
            								}
HXDLIN( 130)								{
HXLINE( 130)									::String k5 = ::Point2D_obj::coordsToString(c,(r + 1));
HXDLIN( 130)									{
HXLINE( 130)										::String key15 = cell->name;
HXDLIN( 130)										bool _hx_tmp5;
HXDLIN( 130)										if (_this1->cells->exists(key15)) {
HXLINE( 130)											_hx_tmp5 = _this1->cells->exists(k5);
            										}
            										else {
HXLINE( 130)											_hx_tmp5 = false;
            										}
HXDLIN( 130)										if (_hx_tmp5) {
HXLINE( 130)											if (!(( ( ::Cell)(_this1->cells->get(key15)) )->neighbors->contains(k5))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(key15)) )->neighbors->push(k5);
            											}
HXDLIN( 130)											if (!(( ( ::Cell)(_this1->cells->get(k5)) )->neighbors->contains(key15))) {
HXLINE( 130)												( ( ::Cell)(_this1->cells->get(k5)) )->neighbors->push(key15);
            											}
            										}
            									}
            								}
            							}
HXDLIN( 130)							 ::TextWindow _this2 = _this1->window;
HXDLIN( 130)							int _hx_tmp6 = _this1->getRowFromCoords(c,r);
HXDLIN( 130)							_this2->addChild(cell,_hx_tmp6,_this1->getColumnFromCoords(c,r),null(),null(),null(),null(),null());
            						}
            					}
            				}
            			}
            		}
HXLINE( 135)		::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(HX_("1, 2",ad,f3,84,20))) ))->building = ::Building_obj::House_dyn();
HXLINE( 136)		::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(HX_("1, 2",ad,f3,84,20))) ))->buildingLevel = 2;
HXLINE( 137)		::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(HX_("2, 2",4c,2a,2e,21))) ))->building = ::Building_obj::Sawmill_dyn();
HXLINE( 138)		::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(HX_("2, 2",4c,2a,2e,21))) ))->buildingLevel = 1;
HXLINE( 139)		::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(HX_("2, 1",4b,2a,2e,21))) ))->building = ::Building_obj::Farm_dyn();
HXLINE( 140)		::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(HX_("2, 1",4b,2a,2e,21))) ))->buildingLevel = 2;
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,generateFilled,(void))

void Island_obj::growIsland(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_146_growIsland)
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,growIsland,(void))

void Island_obj::generateRandom(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_150_generateRandom)
HXLINE( 151)		int _hx_int = (2 * this->size);
HXDLIN( 151)		Float semiperimeter;
HXDLIN( 151)		if ((_hx_int < 0)) {
HXLINE( 151)			semiperimeter = (((Float)4294967296.0) + _hx_int);
            		}
            		else {
HXLINE( 151)			semiperimeter = (_hx_int + ((Float)0.0));
            		}
HXDLIN( 151)		int semiperimeter1 = ::Math_obj::ceil((( (Float)(2) ) * ::Math_obj::sqrt(semiperimeter)));
HXLINE( 152)		int gridRows = ::Math_obj::floor((( (Float)(semiperimeter1) ) / ( (Float)(2) )));
HXLINE( 153)		int gridCols = (semiperimeter1 - gridRows);
HXLINE( 155)		this->grid =  ::HexGrid_obj::__alloc( HX_CTX ,gridRows,gridCols,::Island_obj::cellRows,::Island_obj::cellCols,this->name);
HXLINE( 157)		int x = ::Math_obj::floor((( (Float)(gridCols) ) / ( (Float)(2) )));
HXDLIN( 157)		int y = ::Math_obj::floor((( (Float)(gridRows) ) / ( (Float)(2) )));
HXLINE( 158)		this->makeCell(x,y,null());
HXLINE( 159)		 ::HexGrid _hx_tmp = this->grid;
HXDLIN( 159)		 ::HexGrid _this = this->grid;
HXDLIN( 159)		_hx_tmp->set_activeCellKey(::Point2D_obj::coordsToString(x,y));
HXLINE( 160)		 ::IslandCell _hx_tmp1;
HXDLIN( 160)		if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 160)			_hx_tmp1 = null();
            		}
            		else {
HXLINE( 160)			::String key = this->grid->activeCellKey;
HXDLIN( 160)			if (this->grid->cells->exists(key)) {
HXLINE( 160)				_hx_tmp1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 160)				_hx_tmp1 = null();
            			}
            		}
HXDLIN( 160)		_hx_tmp1->building = ::Building_obj::House_dyn();
HXLINE( 161)		 ::IslandCell _hx_tmp2;
HXDLIN( 161)		if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 161)			_hx_tmp2 = null();
            		}
            		else {
HXLINE( 161)			::String key = this->grid->activeCellKey;
HXDLIN( 161)			if (this->grid->cells->exists(key)) {
HXLINE( 161)				_hx_tmp2 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 161)				_hx_tmp2 = null();
            			}
            		}
HXDLIN( 161)		_hx_tmp2->buildingLevel = 1;
HXLINE( 163)		{
HXLINE( 163)			int _g_min = 1;
HXDLIN( 163)			int _g_max = this->size;
HXDLIN( 163)			while((_g_min < _g_max)){
HXLINE( 163)				_g_min = (_g_min + 1);
HXDLIN( 163)				int i = (_g_min - 1);
HXLINE( 168)				::String borderKey = ::Utils_obj::randomElement(this->grid->cellKeysWithPotentialNeighbors());
HXLINE( 169)				::String key = ::Utils_obj::randomElement(this->grid->potentialNeighbors(borderKey));
HXLINE( 172)				if ((i == 1)) {
HXLINE( 173)					 ::HexGrid _this = this->grid;
HXDLIN( 173)					 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 173)					 ::HexGrid _this1 = this->grid;
HXDLIN( 173)					this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),::Terrain_obj::Grass_dyn());
HXLINE( 174)					::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ))->building = ::Building_obj::Farm_dyn();
HXLINE( 175)					::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ))->buildingLevel = 2;
            				}
            				else {
HXLINE( 177)					if ((i == 2)) {
HXLINE( 178)						 ::HexGrid _this = this->grid;
HXDLIN( 178)						 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 178)						 ::HexGrid _this1 = this->grid;
HXDLIN( 178)						this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),::Terrain_obj::Forest_dyn());
HXLINE( 179)						::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ))->building = ::Building_obj::Sawmill_dyn();
HXLINE( 180)						::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ))->buildingLevel = 1;
            					}
            					else {
HXLINE( 183)						int _hx_int = this->size;
HXDLIN( 183)						Float _hx_tmp;
HXDLIN( 183)						if ((_hx_int < 0)) {
HXLINE( 183)							_hx_tmp = (((Float)4294967296.0) + _hx_int);
            						}
            						else {
HXLINE( 183)							_hx_tmp = (_hx_int + ((Float)0.0));
            						}
HXDLIN( 183)						if ((i > (_hx_tmp * ((Float)0.75)))) {
HXLINE( 184)							int _hx_tmp = this->countTerrain(::Terrain_obj::Grass_dyn());
HXDLIN( 184)							int _hx_int = this->size;
HXDLIN( 184)							Float _hx_tmp1;
HXDLIN( 184)							if ((_hx_int < 0)) {
HXLINE( 184)								_hx_tmp1 = (((Float)4294967296.0) + _hx_int);
            							}
            							else {
HXLINE( 184)								_hx_tmp1 = (_hx_int + ((Float)0.0));
            							}
HXDLIN( 184)							if ((_hx_tmp < (_hx_tmp1 * ((Float)0.25)))) {
HXLINE( 185)								 ::HexGrid _this = this->grid;
HXDLIN( 185)								 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 185)								 ::HexGrid _this1 = this->grid;
HXDLIN( 185)								this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),::Terrain_obj::Grass_dyn());
            							}
            							else {
HXLINE( 187)								int _hx_tmp = this->countTerrain(::Terrain_obj::Forest_dyn());
HXDLIN( 187)								int _hx_int = this->size;
HXDLIN( 187)								Float _hx_tmp1;
HXDLIN( 187)								if ((_hx_int < 0)) {
HXLINE( 187)									_hx_tmp1 = (((Float)4294967296.0) + _hx_int);
            								}
            								else {
HXLINE( 187)									_hx_tmp1 = (_hx_int + ((Float)0.0));
            								}
HXDLIN( 187)								if ((_hx_tmp < (_hx_tmp1 * ((Float)0.25)))) {
HXLINE( 188)									 ::HexGrid _this = this->grid;
HXDLIN( 188)									 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 188)									 ::HexGrid _this1 = this->grid;
HXDLIN( 188)									this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),::Terrain_obj::Forest_dyn());
            								}
            								else {
HXLINE( 190)									int _hx_tmp = this->countTerrain(::Terrain_obj::Hills_dyn());
HXDLIN( 190)									int _hx_int = this->size;
HXDLIN( 190)									Float _hx_tmp1;
HXDLIN( 190)									if ((_hx_int < 0)) {
HXLINE( 190)										_hx_tmp1 = (((Float)4294967296.0) + _hx_int);
            									}
            									else {
HXLINE( 190)										_hx_tmp1 = (_hx_int + ((Float)0.0));
            									}
HXDLIN( 190)									if ((_hx_tmp < (_hx_tmp1 * ((Float)0.2)))) {
HXLINE( 191)										 ::HexGrid _this = this->grid;
HXDLIN( 191)										 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 191)										 ::HexGrid _this1 = this->grid;
HXDLIN( 191)										this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),::Terrain_obj::Hills_dyn());
            									}
            									else {
HXLINE( 193)										 ::HexGrid _this = this->grid;
HXDLIN( 193)										 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 193)										 ::HexGrid _this1 = this->grid;
HXDLIN( 193)										this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),null());
            									}
            								}
            							}
            						}
            						else {
HXLINE( 195)							 ::HexGrid _this = this->grid;
HXDLIN( 195)							 ::Dynamic _hx_tmp = ::Point2D_obj::xFromString(key);
HXDLIN( 195)							 ::HexGrid _this1 = this->grid;
HXDLIN( 195)							this->makeCell(( (int)(_hx_tmp) ),( (int)(::Point2D_obj::yFromString(key)) ),null());
            						}
            					}
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,generateRandom,(void))

void Island_obj::write(::String s, ::Dynamic __o_r, ::Dynamic __o_c){
            		 ::Dynamic r = __o_r;
            		if (::hx::IsNull(__o_r)) r = 0;
            		 ::Dynamic c = __o_c;
            		if (::hx::IsNull(__o_c)) c = 0;
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_201_write)
HXDLIN( 201)		this->mainWindow->write(s,null(),r,c);
            	}


HX_DEFINE_DYNAMIC_FUNC3(Island_obj,write,(void))

 ::IslandCell Island_obj::getCell(::String key){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_205_getCell)
HXDLIN( 205)		if (this->grid->cells->exists(key)) {
HXDLIN( 205)			return ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            		}
            		else {
HXLINE( 206)			return null();
            		}
HXLINE( 205)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,getCell,return )

 ::IslandCell Island_obj::getActiveCell(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_209_getActiveCell)
HXLINE( 210)		if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 210)			return null();
            		}
HXLINE( 211)		::String key = this->grid->activeCellKey;
HXDLIN( 211)		if (this->grid->cells->exists(key)) {
HXLINE( 211)			return ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            		}
            		else {
HXLINE( 211)			return null();
            		}
HXDLIN( 211)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,getActiveCell,return )

::String Island_obj::getActiveCellKey(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_215_getActiveCellKey)
HXDLIN( 215)		return this->grid->activeCellKey;
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,getActiveCellKey,return )

 ::haxe::ds::EnumValueMap Island_obj::countBuildings(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_221_countBuildings)
HXLINE( 222)		 ::haxe::ds::EnumValueMap _g =  ::haxe::ds::EnumValueMap_obj::__alloc( HX_CTX );
HXDLIN( 222)		{
HXLINE( 222)			int _g1 = 0;
HXDLIN( 222)			::Array< ::Dynamic> _g2 = ::Type_obj::allEnums(::hx::ClassOf< ::Building >());
HXDLIN( 222)			while((_g1 < _g2->length)){
HXLINE( 222)				 ::Building b = _g2->__get(_g1).StaticCast<  ::Building >();
HXDLIN( 222)				_g1 = (_g1 + 1);
HXDLIN( 222)				_g->set(b,0);
            			}
            		}
HXDLIN( 222)		 ::haxe::ds::EnumValueMap count = _g;
HXLINE( 224)		{
HXLINE( 224)			 ::Dynamic cell = this->grid->cells->iterator();
HXDLIN( 224)			while(( (bool)(cell->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 224)				 ::Cell cell1 = ( ( ::Cell)(cell->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXLINE( 225)				 ::Building b = ::hx::TCast<  ::IslandCell >::cast(cell1)->building;
HXLINE( 226)				if (::hx::IsNotNull( b )) {
HXLINE( 227)					 ::Building _g = b;
HXDLIN( 227)					 ::haxe::ds::EnumValueMap _g1 = count;
HXDLIN( 227)					{
HXLINE( 227)						int a = ( (int)(_g1->get(_g)) );
HXDLIN( 227)						int v = (a + ::hx::TCast<  ::IslandCell >::cast(cell1)->buildingLevel);
HXDLIN( 227)						_g1->set(_g,v);
            					}
            				}
            			}
            		}
HXLINE( 231)		return (this->buildings = count);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,countBuildings,return )

int Island_obj::countTerrain( ::Terrain terrain){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_234_countTerrain)
HXLINE( 235)		int count = 0;
HXLINE( 237)		{
HXLINE( 237)			 ::Dynamic cell = this->grid->cells->iterator();
HXDLIN( 237)			while(( (bool)(cell->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 237)				 ::Cell cell1 = ( ( ::Cell)(cell->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXLINE( 238)				if (::hx::IsPointerEq( ::hx::TCast<  ::IslandCell >::cast(cell1)->terrain,terrain )) {
HXLINE( 238)					count = (count + 1);
            				}
            			}
            		}
HXLINE( 241)		return count;
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,countTerrain,return )

int Island_obj::countJobs(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_256_countJobs)
HXLINE( 257)		int count = -(this->buildings->get(::Building_obj::House_dyn()));
HXLINE( 258)		{
HXLINE( 258)			 ::Dynamic b = this->buildings->iterator();
HXDLIN( 258)			while(( (bool)(b->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 258)				int b1 = ( (int)(b->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXDLIN( 258)				count = (count + b1);
            			}
            		}
HXLINE( 259)		return count;
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,countJobs,return )

 ::Pile Island_obj::costToUpgrade(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_264_costToUpgrade)
HXDLIN( 264)		 ::IslandCell _hx_tmp;
HXDLIN( 264)		if (::hx::IsNull( this->grid->activeCellKey )) {
HXDLIN( 264)			_hx_tmp = null();
            		}
            		else {
HXDLIN( 264)			::String key = this->grid->activeCellKey;
HXDLIN( 264)			if (this->grid->cells->exists(key)) {
HXDLIN( 264)				_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXDLIN( 264)				_hx_tmp = null();
            			}
            		}
HXDLIN( 264)		 ::Building _hx_tmp1 = _hx_tmp->building;
HXDLIN( 264)		 ::IslandCell _hx_tmp2;
HXDLIN( 264)		if (::hx::IsNull( this->grid->activeCellKey )) {
HXDLIN( 264)			_hx_tmp2 = null();
            		}
            		else {
HXDLIN( 264)			::String key = this->grid->activeCellKey;
HXDLIN( 264)			if (this->grid->cells->exists(key)) {
HXDLIN( 264)				_hx_tmp2 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXDLIN( 264)				_hx_tmp2 = null();
            			}
            		}
HXDLIN( 264)		return ::_Building::Building_Fields__obj::CostToBuild(_hx_tmp1,_hx_tmp2->buildingLevel);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,costToUpgrade,return )

 ::Pile Island_obj::costToBuild( ::Building b){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_268_costToBuild)
HXDLIN( 268)		return ::_Building::Building_Fields__obj::CostToBuild(b,0);
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,costToBuild,return )

bool Island_obj::isValidLocation( ::Building b,::String key){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_271_isValidLocation)
HXLINE( 272)		if (::hx::IsNull( key )) {
HXLINE( 272)			key = this->grid->activeCellKey;
            		}
HXLINE( 274)		bool _hx_tmp;
HXDLIN( 274)		if (::hx::IsPointerEq( b,::Building_obj::Farm_dyn() )) {
HXLINE( 274)			 ::IslandCell _hx_tmp1;
HXDLIN( 274)			if (this->grid->cells->exists(key)) {
HXLINE( 274)				_hx_tmp1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 274)				_hx_tmp1 = null();
            			}
HXDLIN( 274)			_hx_tmp = ::hx::IsPointerNotEq( _hx_tmp1->terrain,::Terrain_obj::Grass_dyn() );
            		}
            		else {
HXLINE( 274)			_hx_tmp = false;
            		}
HXDLIN( 274)		if (_hx_tmp) {
HXLINE( 274)			return false;
            		}
HXLINE( 275)		bool _hx_tmp1;
HXDLIN( 275)		if (::hx::IsPointerEq( b,::Building_obj::Sawmill_dyn() )) {
HXLINE( 275)			 ::IslandCell _hx_tmp;
HXDLIN( 275)			if (this->grid->cells->exists(key)) {
HXLINE( 275)				_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 275)				_hx_tmp = null();
            			}
HXDLIN( 275)			_hx_tmp1 = ::hx::IsPointerNotEq( _hx_tmp->terrain,::Terrain_obj::Forest_dyn() );
            		}
            		else {
HXLINE( 275)			_hx_tmp1 = false;
            		}
HXDLIN( 275)		if (_hx_tmp1) {
HXLINE( 275)			return false;
            		}
HXLINE( 276)		bool _hx_tmp2;
HXDLIN( 276)		if (::hx::IsPointerEq( b,::Building_obj::Mine_dyn() )) {
HXLINE( 276)			 ::IslandCell _hx_tmp;
HXDLIN( 276)			if (this->grid->cells->exists(key)) {
HXLINE( 276)				_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 276)				_hx_tmp = null();
            			}
HXDLIN( 276)			_hx_tmp2 = ::hx::IsPointerNotEq( _hx_tmp->terrain,::Terrain_obj::Hills_dyn() );
            		}
            		else {
HXLINE( 276)			_hx_tmp2 = false;
            		}
HXDLIN( 276)		if (_hx_tmp2) {
HXLINE( 276)			return false;
            		}
HXLINE( 278)		bool _hx_tmp3;
HXDLIN( 278)		if (::hx::IsPointerEq( b,::Building_obj::Port_dyn() )) {
HXLINE( 279)			 ::IslandCell _hx_tmp;
HXDLIN( 279)			if (this->grid->cells->exists(key)) {
HXLINE( 279)				_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 279)				_hx_tmp = null();
            			}
HXDLIN( 279)			if (::hx::IsPointerEq( _hx_tmp->terrain,::Terrain_obj::Grass_dyn() )) {
HXLINE( 278)				_hx_tmp3 = !(this->isCoastCellKey(key));
            			}
            			else {
HXLINE( 278)				_hx_tmp3 = true;
            			}
            		}
            		else {
HXLINE( 278)			_hx_tmp3 = false;
            		}
HXDLIN( 278)		if (_hx_tmp3) {
HXLINE( 279)			return false;
            		}
HXLINE( 281)		return true;
            	}


HX_DEFINE_DYNAMIC_FUNC2(Island_obj,isValidLocation,return )

bool Island_obj::isCoastCellKey(::String key){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_286_isCoastCellKey)
HXDLIN( 286)		bool _hx_tmp;
HXDLIN( 286)		bool _hx_tmp1;
HXDLIN( 286)		bool _hx_tmp2;
HXDLIN( 286)		bool _hx_tmp3;
HXDLIN( 286)		 ::HexGrid _this = this->grid;
HXDLIN( 286)		if (::hx::IsNotEq( ::Point2D_obj::xFromString(key),0 )) {
HXDLIN( 286)			 ::HexGrid _this = this->grid;
HXDLIN( 286)			int a = ( (int)(::Point2D_obj::xFromString(key)) );
HXDLIN( 286)			_hx_tmp3 = (a == (this->grid->gridCols - 1));
            		}
            		else {
HXDLIN( 286)			_hx_tmp3 = true;
            		}
HXDLIN( 286)		if (!(_hx_tmp3)) {
HXLINE( 287)			 ::HexGrid _this = this->grid;
HXLINE( 286)			_hx_tmp2 = ::hx::IsEq( ::Point2D_obj::yFromString(key),0 );
            		}
            		else {
HXDLIN( 286)			_hx_tmp2 = true;
            		}
HXDLIN( 286)		if (!(_hx_tmp2)) {
HXLINE( 287)			 ::HexGrid _this = this->grid;
HXDLIN( 287)			int a = ( (int)(::Point2D_obj::yFromString(key)) );
HXLINE( 286)			_hx_tmp1 = (a == (this->grid->gridRows - 1));
            		}
            		else {
HXDLIN( 286)			_hx_tmp1 = true;
            		}
HXDLIN( 286)		if (!(_hx_tmp1)) {
HXDLIN( 286)			_hx_tmp = this->grid->cellKeysWithPotentialNeighbors()->contains(key);
            		}
            		else {
HXDLIN( 286)			_hx_tmp = true;
            		}
HXDLIN( 286)		if (_hx_tmp) {
HXLINE( 289)			return true;
            		}
            		else {
HXLINE( 291)			return false;
            		}
HXLINE( 286)		return false;
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,isCoastCellKey,return )

void Island_obj::display(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_294_display)
HXLINE( 295)		{
HXLINE( 295)			 ::Dynamic r = 0;
HXDLIN( 295)			 ::Dynamic c = 4;
HXDLIN( 295)			if (::hx::IsNull( c )) {
HXLINE( 295)				c = 0;
            			}
HXDLIN( 295)			if (::hx::IsNull( r )) {
HXLINE( 295)				r = 0;
            			}
HXDLIN( 295)			this->mainWindow->write((HX_("Week ",8c,05,ec,5a) + this->turn),null(),r,c);
            		}
HXLINE( 297)		{
HXLINE( 297)			::String s = ((HX_("Islanders: ",77,74,e9,17) + this->population) + HX_(" / ",31,71,18,00));
HXDLIN( 297)			::String s1 = ((s + this->countJobs()) + HX_(" jobs",f6,bd,37,b3));
HXDLIN( 297)			 ::Dynamic r1 = 0;
HXDLIN( 297)			 ::Dynamic c1 = 20;
HXDLIN( 297)			if (::hx::IsNull( c1 )) {
HXLINE( 297)				c1 = 0;
            			}
HXDLIN( 297)			if (::hx::IsNull( r1 )) {
HXLINE( 297)				r1 = 0;
            			}
HXDLIN( 297)			this->mainWindow->write(s1,null(),r1,c1);
            		}
HXLINE( 298)		{
HXLINE( 298)			::String s2 = (HX_("Happiness: ",ed,6f,d8,e7) + this->calculateHappiness());
HXDLIN( 298)			 ::Dynamic r2 = 0;
HXDLIN( 298)			 ::Dynamic c2 = 50;
HXDLIN( 298)			if (::hx::IsNull( c2 )) {
HXLINE( 298)				c2 = 0;
            			}
HXDLIN( 298)			if (::hx::IsNull( r2 )) {
HXLINE( 298)				r2 = 0;
            			}
HXDLIN( 298)			this->mainWindow->write(s2,null(),r2,c2);
            		}
HXLINE( 300)		if ((this->calculateHappiness() >= 100)) {
HXLINE( 300)			 ::Dynamic r = 0;
HXDLIN( 300)			 ::Dynamic c = 70;
HXDLIN( 300)			if (::hx::IsNull( c )) {
HXLINE( 300)				c = 0;
            			}
HXDLIN( 300)			if (::hx::IsNull( r )) {
HXLINE( 300)				r = 0;
            			}
HXDLIN( 300)			this->mainWindow->write(HX_("You win!",86,62,e4,6d),null(),r,c);
            		}
HXLINE( 302)		{
HXLINE( 302)			::String s3 = (HX_("",00,00,00,00) + ::Std_obj::string(this->resources));
HXDLIN( 302)			 ::Dynamic r3 = 2;
HXDLIN( 302)			 ::Dynamic c3 = 8;
HXDLIN( 302)			if (::hx::IsNull( c3 )) {
HXLINE( 302)				c3 = 0;
            			}
HXDLIN( 302)			if (::hx::IsNull( r3 )) {
HXLINE( 302)				r3 = 0;
            			}
HXDLIN( 302)			this->mainWindow->write(s3,null(),r3,c3);
            		}
HXLINE( 303)		::String income = this->calculateIncome()->toResourceAlignedString(HX_("+",2b,00,00,00),false);
HXLINE( 304)		{
HXLINE( 304)			 ::Dynamic r4 = 3;
HXDLIN( 304)			 ::Dynamic c4 = 7;
HXDLIN( 304)			if (::hx::IsNull( c4 )) {
HXLINE( 304)				c4 = 0;
            			}
HXDLIN( 304)			if (::hx::IsNull( r4 )) {
HXLINE( 304)				r4 = 0;
            			}
HXDLIN( 304)			this->mainWindow->write((HX_("",00,00,00,00) + income),null(),r4,c4);
            		}
HXLINE( 307)		::String active = this->grid->activeCellKey;
HXLINE( 308)		this->infoWindow->clear(null());
HXLINE( 309)		if (::hx::IsNotNull( active )) {
HXLINE( 310)			 ::IslandCell cell = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(active)) ));
HXLINE( 312)			 ::TextWindow _hx_tmp = this->infoWindow;
HXDLIN( 312)			_hx_tmp->write(( (::String)(::_Island::Island_Fields__obj::terrainNames->get(cell->terrain)) ),null(),null(),null());
HXLINE( 314)			if (::hx::IsNotNull( cell->building )) {
HXLINE( 315)				 ::TextWindow _hx_tmp = this->infoWindow;
HXDLIN( 315)				int _hx_int = cell->buildingLevel;
HXDLIN( 315)				Float _hx_tmp1;
HXDLIN( 315)				if ((_hx_int < 0)) {
HXLINE( 315)					_hx_tmp1 = (((Float)4294967296.0) + _hx_int);
            				}
            				else {
HXLINE( 315)					_hx_tmp1 = (_hx_int + ((Float)0.0));
            				}
HXDLIN( 315)				::String _hx_tmp2 = ((HX_("Level ",3c,32,e4,d8) + ::Std_obj::string(_hx_tmp1)) + HX_(" ",20,00,00,00));
HXDLIN( 315)				_hx_tmp->write((_hx_tmp2 + ::_Building::Building_Fields__obj::names->get(cell->building)),null(),1,null());
HXLINE( 317)				if (::hx::IsNotNull( this->calculateCellProduction(cell) )) {
HXLINE( 318)					 ::TextWindow _hx_tmp = this->infoWindow;
HXDLIN( 318)					_hx_tmp->write((HX_("Produces ",4d,3b,05,07) + this->calculateCellProduction(cell)->toLeftAlignedString(null(),null())),null(),1,17);
            				}
            			}
            		}
HXLINE( 323)		this->commandWindow->clear(null());
HXLINE( 325)		switch((int)(this->menuState->_hx_getIndex())){
            			case (int)0: {
HXLINE( 327)				this->commandWindow->write(HX_("Build:",6c,61,29,07),null(),null(),null());
HXLINE( 329)				int row = 2;
HXLINE( 330)				{
HXLINE( 330)					int _g = 0;
HXDLIN( 330)					::Array< ::Dynamic> _g1 = ::Type_obj::allEnums(::hx::ClassOf< ::Building >());
HXDLIN( 330)					while((_g < _g1->length)){
HXLINE( 330)						 ::Building b = _g1->__get(_g).StaticCast<  ::Building >();
HXDLIN( 330)						_g = (_g + 1);
HXLINE( 331)						if (this->isValidLocation(b,null())) {
HXLINE( 332)							 ::TextWindow _hx_tmp = this->commandWindow;
HXDLIN( 332)							_hx_tmp->write(( (::String)(::_Building::Building_Fields__obj::names->get(b)) ),null(),row,2);
HXLINE( 333)							 ::TextWindow _hx_tmp1 = this->commandWindow;
HXDLIN( 333)							_hx_tmp1->write((( (::String)(::_Building::Building_Fields__obj::names->get(b)) ).charAt(0) + HX_(")",29,00,00,00)),null(),row,1);
HXLINE( 335)							 ::Pile cost = ::_Building::Building_Fields__obj::CostToBuild(b,0);
HXLINE( 337)							if (this->resources->hasPile(cost)) {
HXLINE( 337)								this->commandWindow->write(HX_("*",2a,00,00,00),null(),row,0);
            							}
HXLINE( 339)							 ::TextWindow _hx_tmp2 = this->commandWindow;
HXDLIN( 339)							_hx_tmp2->write(cost->toLeftAlignedString(null(),null()),null(),row,13);
            						}
HXLINE( 342)						row = (row + 1);
            					}
            				}
HXLINE( 345)				this->commandWindow->write(HX_("V)iew population",c5,b0,54,c4),null(),11,null());
            			}
            			break;
            			case (int)1: {
HXLINE( 348)				this->commandWindow->write(HX_(" U)pgrade",bb,77,bf,66),null(),null(),null());
HXLINE( 350)				 ::IslandCell cost;
HXDLIN( 350)				if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 350)					cost = null();
            				}
            				else {
HXLINE( 350)					::String key = this->grid->activeCellKey;
HXDLIN( 350)					if (this->grid->cells->exists(key)) {
HXLINE( 350)						cost = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            					}
            					else {
HXLINE( 350)						cost = null();
            					}
            				}
HXDLIN( 350)				 ::Building cost1 = cost->building;
HXDLIN( 350)				 ::IslandCell cost2;
HXDLIN( 350)				if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 350)					cost2 = null();
            				}
            				else {
HXLINE( 350)					::String key = this->grid->activeCellKey;
HXDLIN( 350)					if (this->grid->cells->exists(key)) {
HXLINE( 350)						cost2 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            					}
            					else {
HXLINE( 350)						cost2 = null();
            					}
            				}
HXDLIN( 350)				 ::Pile cost3 = ::_Building::Building_Fields__obj::CostToBuild(cost1,cost2->buildingLevel);
HXLINE( 352)				 ::Pile _hx_tmp = this->resources;
HXDLIN( 352)				 ::IslandCell _hx_tmp1;
HXDLIN( 352)				if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 352)					_hx_tmp1 = null();
            				}
            				else {
HXLINE( 352)					::String key = this->grid->activeCellKey;
HXDLIN( 352)					if (this->grid->cells->exists(key)) {
HXLINE( 352)						_hx_tmp1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            					}
            					else {
HXLINE( 352)						_hx_tmp1 = null();
            					}
            				}
HXDLIN( 352)				 ::Building _hx_tmp2 = _hx_tmp1->building;
HXDLIN( 352)				 ::IslandCell _hx_tmp3;
HXDLIN( 352)				if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 352)					_hx_tmp3 = null();
            				}
            				else {
HXLINE( 352)					::String key = this->grid->activeCellKey;
HXDLIN( 352)					if (this->grid->cells->exists(key)) {
HXLINE( 352)						_hx_tmp3 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            					}
            					else {
HXLINE( 352)						_hx_tmp3 = null();
            					}
            				}
HXDLIN( 352)				if (_hx_tmp->hasPile(::_Building::Building_Fields__obj::CostToBuild(_hx_tmp2,_hx_tmp3->buildingLevel))) {
HXLINE( 352)					this->commandWindow->write(HX_("*",2a,00,00,00),null(),null(),null());
            				}
HXLINE( 354)				 ::TextWindow _hx_tmp4 = this->commandWindow;
HXDLIN( 354)				_hx_tmp4->write(cost3->toLeftAlignedString(null(),null()),null(),0,12);
HXLINE( 356)				this->commandWindow->write(HX_("V)iew population",c5,b0,54,c4),null(),11,null());
            			}
            			break;
            			case (int)2: {
HXLINE( 359)				this->commandWindow->write(((((HX_("",00,00,00,00) + this->population) + HX_(" islanders consuming ",36,38,75,0b)) + (this->population * 4)) + HX_(" food",be,ee,92,b0)),null(),null(),null());
HXLINE( 360)				 ::Dynamic grainEaten = this->calculateConsumption()->resources->get(::Resource_obj::Grain_dyn());
HXLINE( 361)				 ::Dynamic fishEaten = this->calculateConsumption()->resources->get(::Resource_obj::Fish_dyn());
HXLINE( 363)				this->commandWindow->write(((((HX_("",00,00,00,00) + grainEaten) + HX_(" Grain + ",9a,77,38,46)) + fishEaten) + HX_(" Fish",d8,90,67,9b)),null(),1,22);
HXLINE( 365)				this->commandWindow->write(HX_("Happiness from",a3,3e,af,c0),null(),3,null());
HXLINE( 367)				 ::TextWindow _hx_tmp = this->commandWindow;
HXDLIN( 367)				::String _hx_tmp1 = (HX_("Employment :  ",e6,17,29,ff) + this->calculateHappinessFromEmployment());
HXDLIN( 367)				_hx_tmp->write((_hx_tmp1 + ((HX_(" (max ",04,05,c9,1b) + ::Island_obj::baseHappiness) + HX_(" at 50% employment)",ba,1e,74,0c))),null(),5,null());
HXLINE( 368)				 ::TextWindow _hx_tmp2 = this->commandWindow;
HXDLIN( 368)				::String _hx_tmp3 = (HX_("Food       :  ",d8,ea,c7,60) + this->calculateHappinessFromFood());
HXDLIN( 368)				_hx_tmp2->write((_hx_tmp3 + ((HX_(" (max ",04,05,c9,1b) + ::Island_obj::maxHappinessFromFood) + HX_(" at 50% fish eaten)",cd,a3,04,6d))),null(),6,null());
HXLINE( 369)				 ::TextWindow _hx_tmp4 = this->commandWindow;
HXDLIN( 369)				_hx_tmp4->write((HX_("Goods      :  ",84,1b,9a,7b) + this->calculateHappinessFromGoods()),null(),7,null());
HXLINE( 370)				 ::TextWindow _hx_tmp5 = this->commandWindow;
HXDLIN( 370)				int _hx_int = this->calculateHappinessFromTemples();
HXDLIN( 370)				Float _hx_tmp6;
HXDLIN( 370)				if ((_hx_int < 0)) {
HXLINE( 370)					_hx_tmp6 = (((Float)4294967296.0) + _hx_int);
            				}
            				else {
HXLINE( 370)					_hx_tmp6 = (_hx_int + ((Float)0.0));
            				}
HXDLIN( 370)				_hx_tmp5->write((HX_("Temples    :  ",54,a2,33,50) + ::Std_obj::string(_hx_tmp6)),null(),8,null());
HXLINE( 371)				 ::TextWindow _hx_tmp7 = this->commandWindow;
HXDLIN( 371)				_hx_tmp7->write((HX_("              ",00,c4,6b,6f) + this->calculateHappiness()),null(),9,null());
HXLINE( 373)				this->commandWindow->write(HX_("V)iew island",0d,1c,14,15),null(),11,null());
            			}
            			break;
            		}
HXLINE( 376)		this->mainWindow->write(HX_("N)ext week",ee,d2,7e,8b),null(),19,12);
HXLINE( 378)		this->mainWindow->display();
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,display,(void))

void Island_obj::inputLoop(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_381_inputLoop)
HXLINE( 382)		::String input = HX_("",00,00,00,00);
HXLINE( 384)		while((input == HX_("",00,00,00,00))){
HXLINE( 385)			input = ::_TextScreen::ASCIIChar_Impl__obj::fromInt(::Sys_obj::getChar(false));
HXLINE( 388)			::String _hx_switch_0 = input;
            			if (  (_hx_switch_0==HX_("2",32,00,00,00)) ){
HXLINE( 396)				this->commandMove(::Direction_obj::Down_dyn());
HXDLIN( 396)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("4",34,00,00,00)) ){
HXLINE( 390)				this->commandMove(::Direction_obj::Left_dyn());
HXDLIN( 390)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("6",36,00,00,00)) ){
HXLINE( 392)				this->commandMove(::Direction_obj::Right_dyn());
HXDLIN( 392)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("8",38,00,00,00)) ){
HXLINE( 394)				this->commandMove(::Direction_obj::Up_dyn());
HXDLIN( 394)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("F",46,00,00,00)) ||  (_hx_switch_0==HX_("f",66,00,00,00)) ){
HXLINE( 400)				this->commandBuild(::Building_obj::Farm_dyn());
HXDLIN( 400)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("H",48,00,00,00)) ||  (_hx_switch_0==HX_("h",68,00,00,00)) ){
HXLINE( 398)				this->commandBuild(::Building_obj::House_dyn());
HXDLIN( 398)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("M",4d,00,00,00)) ||  (_hx_switch_0==HX_("m",6d,00,00,00)) ){
HXLINE( 404)				this->commandBuild(::Building_obj::Mine_dyn());
HXDLIN( 404)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("P",50,00,00,00)) ||  (_hx_switch_0==HX_("p",70,00,00,00)) ){
HXLINE( 408)				this->commandBuild(::Building_obj::Port_dyn());
HXDLIN( 408)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("T",54,00,00,00)) ||  (_hx_switch_0==HX_("t",74,00,00,00)) ){
HXLINE( 410)				this->commandBuild(::Building_obj::Temple_dyn());
HXDLIN( 410)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("U",55,00,00,00)) ||  (_hx_switch_0==HX_("u",75,00,00,00)) ){
HXLINE( 414)				this->commandUpgrade();
HXDLIN( 414)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("B",42,00,00,00)) ||  (_hx_switch_0==HX_("b",62,00,00,00)) ){
HXLINE( 406)				this->commandBuild(::Building_obj::Blacksmith_dyn());
HXDLIN( 406)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_(" ",20,00,00,00)) ||  (_hx_switch_0==HX_("N",4e,00,00,00)) ||  (_hx_switch_0==HX_("n",6e,00,00,00)) ){
HXLINE( 412)				this->commandNextTurn();
HXDLIN( 412)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("S",53,00,00,00)) ||  (_hx_switch_0==HX_("s",73,00,00,00)) ){
HXLINE( 402)				this->commandBuild(::Building_obj::Sawmill_dyn());
HXDLIN( 402)				goto _hx_goto_29;
            			}
            			if (  (_hx_switch_0==HX_("V",56,00,00,00)) ||  (_hx_switch_0==HX_("v",76,00,00,00)) ){
HXLINE( 416)				switch((int)(this->menuState->_hx_getIndex())){
            					case (int)0: case (int)1: {
HXLINE( 418)						this->menuState = ::MenuState_obj::ViewPopulation_dyn();
            					}
            					break;
            					case (int)2: {
HXLINE( 420)						 ::IslandCell _hx_tmp;
HXDLIN( 420)						if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 420)							_hx_tmp = null();
            						}
            						else {
HXLINE( 420)							::String key = this->grid->activeCellKey;
HXDLIN( 420)							if (this->grid->cells->exists(key)) {
HXLINE( 420)								_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            							}
            							else {
HXLINE( 420)								_hx_tmp = null();
            							}
            						}
HXDLIN( 420)						if (::hx::IsNull( _hx_tmp->building )) {
HXLINE( 420)							this->menuState = ::MenuState_obj::Build_dyn();
            						}
            						else {
HXLINE( 421)							this->menuState = ::MenuState_obj::Upgrade_dyn();
            						}
            					}
            					break;
            				}
HXLINE( 416)				goto _hx_goto_29;
            			}
            			/* default */{
            			}
            			_hx_goto_29:;
HXLINE( 431)			this->grid->window->clear(null());
HXLINE( 433)			this->display();
HXLINE( 434)			input = HX_("",00,00,00,00);
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,inputLoop,(void))

void Island_obj::commandMove( ::Direction dir){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_438_commandMove)
HXLINE( 439)		 ::HexGrid _hx_tmp = this->grid;
HXDLIN( 439)		_hx_tmp->set_activeCellKey(this->grid->closestCellInDirection(this->grid->activeCellKey,dir));
HXLINE( 441)		 ::IslandCell _hx_tmp1;
HXDLIN( 441)		if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 441)			_hx_tmp1 = null();
            		}
            		else {
HXLINE( 441)			::String key = this->grid->activeCellKey;
HXDLIN( 441)			if (this->grid->cells->exists(key)) {
HXLINE( 441)				_hx_tmp1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            			}
            			else {
HXLINE( 441)				_hx_tmp1 = null();
            			}
            		}
HXDLIN( 441)		if (::hx::IsNull( _hx_tmp1->building )) {
HXLINE( 441)			this->menuState = ::MenuState_obj::Build_dyn();
            		}
            		else {
HXLINE( 442)			this->menuState = ::MenuState_obj::Upgrade_dyn();
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,commandMove,(void))

void Island_obj::commandBuild( ::Building b){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_449_commandBuild)
HXDLIN( 449)		bool _hx_tmp;
HXDLIN( 449)		bool _hx_tmp1;
HXDLIN( 449)		if (::hx::IsPointerEq( this->menuState,::MenuState_obj::Build_dyn() )) {
HXDLIN( 449)			_hx_tmp1 = this->isValidLocation(b,null());
            		}
            		else {
HXDLIN( 449)			_hx_tmp1 = false;
            		}
HXDLIN( 449)		if (_hx_tmp1) {
HXLINE( 451)			 ::Pile _hx_tmp1 = this->resources;
HXLINE( 449)			_hx_tmp = _hx_tmp1->hasPile(::_Building::Building_Fields__obj::CostToBuild(b,0));
            		}
            		else {
HXDLIN( 449)			_hx_tmp = false;
            		}
HXDLIN( 449)		if (_hx_tmp) {
HXLINE( 453)			this->commandNextTurn();
HXLINE( 455)			 ::Pile _hx_tmp = this->resources;
HXDLIN( 455)			_hx_tmp->subtractPile(::_Building::Building_Fields__obj::CostToBuild(b,0));
HXLINE( 456)			 ::IslandCell _hx_tmp1;
HXDLIN( 456)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 456)				_hx_tmp1 = null();
            			}
            			else {
HXLINE( 456)				::String key = this->grid->activeCellKey;
HXDLIN( 456)				if (this->grid->cells->exists(key)) {
HXLINE( 456)					_hx_tmp1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 456)					_hx_tmp1 = null();
            				}
            			}
HXDLIN( 456)			_hx_tmp1->building = b;
HXLINE( 457)			 ::IslandCell _hx_tmp2;
HXDLIN( 457)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 457)				_hx_tmp2 = null();
            			}
            			else {
HXLINE( 457)				::String key = this->grid->activeCellKey;
HXDLIN( 457)				if (this->grid->cells->exists(key)) {
HXLINE( 457)					_hx_tmp2 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 457)					_hx_tmp2 = null();
            				}
            			}
HXDLIN( 457)			_hx_tmp2->buildingLevel = 1;
HXLINE( 458)			{
HXLINE( 458)				 ::Building tmp = b;
HXDLIN( 458)				{
HXLINE( 458)					int v = ( (int)((this->buildings->get(tmp) + 1)) );
HXDLIN( 458)					this->buildings->set(tmp,v);
            				}
            			}
HXLINE( 460)			this->menuState = ::MenuState_obj::Upgrade_dyn();
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,commandBuild,(void))

void Island_obj::commandUpgrade(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_465_commandUpgrade)
HXDLIN( 465)		bool _hx_tmp;
HXDLIN( 465)		if (::hx::IsPointerEq( this->menuState,::MenuState_obj::Upgrade_dyn() )) {
HXLINE( 466)			 ::Pile _hx_tmp1 = this->resources;
HXDLIN( 466)			 ::IslandCell _hx_tmp2;
HXDLIN( 466)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 466)				_hx_tmp2 = null();
            			}
            			else {
HXLINE( 466)				::String key = this->grid->activeCellKey;
HXDLIN( 466)				if (this->grid->cells->exists(key)) {
HXLINE( 466)					_hx_tmp2 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 466)					_hx_tmp2 = null();
            				}
            			}
HXDLIN( 466)			 ::Building _hx_tmp3 = _hx_tmp2->building;
HXDLIN( 466)			 ::IslandCell _hx_tmp4;
HXDLIN( 466)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 466)				_hx_tmp4 = null();
            			}
            			else {
HXLINE( 466)				::String key = this->grid->activeCellKey;
HXDLIN( 466)				if (this->grid->cells->exists(key)) {
HXLINE( 466)					_hx_tmp4 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 466)					_hx_tmp4 = null();
            				}
            			}
HXLINE( 465)			_hx_tmp = _hx_tmp1->hasPile(::_Building::Building_Fields__obj::CostToBuild(_hx_tmp3,_hx_tmp4->buildingLevel));
            		}
            		else {
HXDLIN( 465)			_hx_tmp = false;
            		}
HXDLIN( 465)		if (_hx_tmp) {
HXLINE( 468)			this->commandNextTurn();
HXLINE( 470)			 ::Pile _hx_tmp = this->resources;
HXDLIN( 470)			 ::IslandCell _hx_tmp1;
HXDLIN( 470)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 470)				_hx_tmp1 = null();
            			}
            			else {
HXLINE( 470)				::String key = this->grid->activeCellKey;
HXDLIN( 470)				if (this->grid->cells->exists(key)) {
HXLINE( 470)					_hx_tmp1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 470)					_hx_tmp1 = null();
            				}
            			}
HXDLIN( 470)			 ::Building _hx_tmp2 = _hx_tmp1->building;
HXDLIN( 470)			 ::IslandCell _hx_tmp3;
HXDLIN( 470)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 470)				_hx_tmp3 = null();
            			}
            			else {
HXLINE( 470)				::String key = this->grid->activeCellKey;
HXDLIN( 470)				if (this->grid->cells->exists(key)) {
HXLINE( 470)					_hx_tmp3 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 470)					_hx_tmp3 = null();
            				}
            			}
HXDLIN( 470)			_hx_tmp->subtractPile(::_Building::Building_Fields__obj::CostToBuild(_hx_tmp2,_hx_tmp3->buildingLevel));
HXLINE( 471)			 ::IslandCell fh;
HXDLIN( 471)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 471)				fh = null();
            			}
            			else {
HXLINE( 471)				::String key = this->grid->activeCellKey;
HXDLIN( 471)				if (this->grid->cells->exists(key)) {
HXLINE( 471)					fh = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 471)					fh = null();
            				}
            			}
HXDLIN( 471)			fh->buildingLevel++;
HXLINE( 472)			{
HXLINE( 472)				 ::IslandCell tmp;
HXDLIN( 472)				if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 472)					tmp = null();
            				}
            				else {
HXLINE( 472)					::String key = this->grid->activeCellKey;
HXDLIN( 472)					if (this->grid->cells->exists(key)) {
HXLINE( 472)						tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            					}
            					else {
HXLINE( 472)						tmp = null();
            					}
            				}
HXDLIN( 472)				 ::Building tmp1 = tmp->building;
HXDLIN( 472)				{
HXLINE( 472)					int v = ( (int)((this->buildings->get(tmp1) + 1)) );
HXDLIN( 472)					this->buildings->set(tmp1,v);
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,commandUpgrade,(void))

void Island_obj::commandNextTurn(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_477_commandNextTurn)
HXLINE( 478)		 ::Pile income = this->calculateIncome();
HXLINE( 480)		int foodDeficit = -(income->resources->get(::Resource_obj::Grain_dyn()));
HXDLIN( 480)		int foodDeficit1 = (foodDeficit - ( (int)(this->resources->resources->get(::Resource_obj::Grain_dyn())) ));
HXLINE( 481)		if ((foodDeficit1 > 0)) {
HXLINE( 482)			this->shrinkPopulation(foodDeficit1);
            		}
HXLINE( 487)		this->resources->cutoffAddPile(income);
HXLINE( 488)		if (::hx::IsGreater( this->resources->resources->get(::Resource_obj::Grain_dyn()),0 )) {
HXLINE( 488)			this->growPopulation();
            		}
HXLINE( 489)		this->turn++;
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,commandNextTurn,(void))

void Island_obj::growPopulation(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_497_growPopulation)
HXDLIN( 497)		int a = this->population;
HXDLIN( 497)		int b = (( (int)(this->buildings->get(::Building_obj::House_dyn())) ) * 3);
HXDLIN( 497)		bool aNeg = (b < 0);
HXDLIN( 497)		bool bNeg = (a < 0);
HXDLIN( 497)		bool _hx_tmp;
HXDLIN( 497)		if ((aNeg != bNeg)) {
HXDLIN( 497)			_hx_tmp = aNeg;
            		}
            		else {
HXDLIN( 497)			_hx_tmp = (b > a);
            		}
HXDLIN( 497)		if (_hx_tmp) {
HXDLIN( 497)			this->population++;
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,growPopulation,(void))

void Island_obj::shrinkPopulation(int deficit){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_502_shrinkPopulation)
HXDLIN( 502)		if ((this->population > 0)) {
HXDLIN( 502)			this->population--;
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,shrinkPopulation,(void))

 ::Pile Island_obj::calculateIncome(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_508_calculateIncome)
HXDLIN( 508)		 ::Pile _hx_tmp = this->calculatePrimaryProduction();
HXDLIN( 508)		 ::Pile _hx_tmp1 = _hx_tmp->addPile(this->calculateSecondaryProduction());
HXDLIN( 508)		return _hx_tmp1->subtractPile(this->calculateConsumption());
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateIncome,return )

 ::Pile Island_obj::calculateCellProduction( ::IslandCell cell){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_511_calculateCellProduction)
HXLINE( 513)		if (::hx::IsNull( cell )) {
HXLINE( 513)			 ::IslandCell cell1;
HXDLIN( 513)			if (::hx::IsNull( this->grid->activeCellKey )) {
HXLINE( 513)				cell1 = null();
            			}
            			else {
HXLINE( 513)				::String key = this->grid->activeCellKey;
HXDLIN( 513)				if (this->grid->cells->exists(key)) {
HXLINE( 513)					cell1 = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            				}
            				else {
HXLINE( 513)					cell1 = null();
            				}
            			}
HXDLIN( 513)			cell = cell1;
            		}
HXLINE( 515)		 ::Pile income =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE( 517)		if (::hx::IsNull( cell->building )) {
HXLINE( 517)			return null();
            		}
HXLINE( 519)		switch((int)(cell->building->_hx_getIndex())){
            			case (int)1: {
HXLINE( 522)				int base = 10;
HXLINE( 523)				{
HXLINE( 523)					int _g = 0;
HXDLIN( 523)					::Array< ::String > _g1 = cell->neighbors;
HXDLIN( 523)					while((_g < _g1->length)){
HXLINE( 523)						::String key = _g1->__get(_g);
HXDLIN( 523)						_g = (_g + 1);
HXLINE( 524)						 ::IslandCell _hx_tmp;
HXDLIN( 524)						if (this->grid->cells->exists(key)) {
HXLINE( 524)							_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            						}
            						else {
HXLINE( 524)							_hx_tmp = null();
            						}
HXDLIN( 524)						if (::hx::IsPointerEq( _hx_tmp->building,::Building_obj::Farm_dyn() )) {
HXLINE( 525)							base = (base + 1);
            						}
            					}
            				}
HXLINE( 529)				return income->add(::Resource_obj::Grain_dyn(),(base * cell->buildingLevel));
            			}
            			break;
            			case (int)2: {
HXLINE( 532)				int base = 10;
HXLINE( 533)				{
HXLINE( 533)					int _g = 0;
HXDLIN( 533)					::Array< ::String > _g1 = cell->neighbors;
HXDLIN( 533)					while((_g < _g1->length)){
HXLINE( 533)						::String key = _g1->__get(_g);
HXDLIN( 533)						_g = (_g + 1);
HXLINE( 534)						 ::IslandCell _hx_tmp;
HXDLIN( 534)						if (this->grid->cells->exists(key)) {
HXLINE( 534)							_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            						}
            						else {
HXLINE( 534)							_hx_tmp = null();
            						}
HXDLIN( 534)						if (::hx::IsPointerEq( _hx_tmp->building,::Building_obj::Farm_dyn() )) {
HXLINE( 535)							base = (base + 1);
            						}
            					}
            				}
HXLINE( 539)				return income->add(::Resource_obj::Wood_dyn(),(base * cell->buildingLevel));
            			}
            			break;
            			case (int)3: {
HXLINE( 542)				int base = 10;
HXLINE( 543)				{
HXLINE( 543)					int _g = 0;
HXDLIN( 543)					::Array< ::String > _g1 = cell->neighbors;
HXDLIN( 543)					while((_g < _g1->length)){
HXLINE( 543)						::String key = _g1->__get(_g);
HXDLIN( 543)						_g = (_g + 1);
HXLINE( 544)						 ::IslandCell _hx_tmp;
HXDLIN( 544)						if (this->grid->cells->exists(key)) {
HXLINE( 544)							_hx_tmp = ::hx::TCast<  ::IslandCell >::cast(( ( ::Cell)(this->grid->cells->get(key)) ));
            						}
            						else {
HXLINE( 544)							_hx_tmp = null();
            						}
HXDLIN( 544)						if (::hx::IsPointerEq( _hx_tmp->building,::Building_obj::Mine_dyn() )) {
HXLINE( 545)							base = (base + 1);
            						}
            					}
            				}
HXLINE( 549)				return income->add(::Resource_obj::Metal_dyn(),(base * cell->buildingLevel));
            			}
            			break;
            			case (int)4: {
HXLINE( 553)				return income->add(::Resource_obj::Tools_dyn(),(5 * cell->buildingLevel));
            			}
            			break;
            			case (int)5: {
HXLINE( 557)				income->add(::Resource_obj::Fish_dyn(),(8 * cell->buildingLevel));
HXLINE( 558)				return income->add(::Resource_obj::Goods_dyn(),(4 * cell->buildingLevel));
            			}
            			break;
            			default:{
HXLINE( 562)				return null();
            			}
            		}
HXLINE( 519)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC1(Island_obj,calculateCellProduction,return )

 ::Pile Island_obj::calculatePrimaryProduction(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_575_calculatePrimaryProduction)
HXLINE( 576)		 ::Pile prod =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE( 578)		{
HXLINE( 578)			 ::Dynamic cell = this->grid->cells->iterator();
HXDLIN( 578)			while(( (bool)(cell->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 578)				 ::Cell cell1 = ( ( ::Cell)(cell->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)()) );
HXLINE( 579)				 ::IslandCell iCell = ::hx::TCast<  ::IslandCell >::cast(cell1);
HXLINE( 580)				bool _hx_tmp;
HXDLIN( 580)				bool _hx_tmp1;
HXDLIN( 580)				bool _hx_tmp2;
HXDLIN( 580)				if (::hx::IsPointerNotEq( iCell->building,::Building_obj::Farm_dyn() )) {
HXLINE( 580)					_hx_tmp2 = ::hx::IsPointerEq( iCell->building,::Building_obj::Sawmill_dyn() );
            				}
            				else {
HXLINE( 580)					_hx_tmp2 = true;
            				}
HXDLIN( 580)				if (!(_hx_tmp2)) {
HXLINE( 580)					_hx_tmp1 = ::hx::IsPointerEq( iCell->building,::Building_obj::Mine_dyn() );
            				}
            				else {
HXLINE( 580)					_hx_tmp1 = true;
            				}
HXDLIN( 580)				if (!(_hx_tmp1)) {
HXLINE( 580)					_hx_tmp = ::hx::IsPointerEq( iCell->building,::Building_obj::Port_dyn() );
            				}
            				else {
HXLINE( 580)					_hx_tmp = true;
            				}
HXDLIN( 580)				if (_hx_tmp) {
HXLINE( 585)					prod->addPile(this->calculateCellProduction(iCell));
            				}
            			}
            		}
HXLINE( 589)		int _hx_tmp = this->countJobs();
HXDLIN( 589)		if ((_hx_tmp > this->population)) {
HXLINE( 590)			int _hx_tmp = this->population;
HXDLIN( 590)			return prod->multiplyAndRound((( (Float)(_hx_tmp) ) / ( (Float)(this->countJobs()) )));
            		}
            		else {
HXLINE( 592)			return prod;
            		}
HXLINE( 589)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculatePrimaryProduction,return )

 ::Pile Island_obj::calculateSecondaryProduction(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_595_calculateSecondaryProduction)
HXLINE( 596)		 ::Pile prod =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE( 598)		int a = ( (int)(this->buildings->get(::Building_obj::Blacksmith_dyn())) );
HXDLIN( 598)		bool aNeg = (a < 0);
HXDLIN( 598)		bool bNeg = (0 < 0);
HXDLIN( 598)		bool _hx_tmp;
HXDLIN( 598)		if ((aNeg != bNeg)) {
HXLINE( 598)			_hx_tmp = aNeg;
            		}
            		else {
HXLINE( 598)			_hx_tmp = (a > 0);
            		}
HXDLIN( 598)		if (_hx_tmp) {
HXLINE( 599)			 ::Pile primaryProd = this->calculatePrimaryProduction();
HXLINE( 600)			 ::Dynamic woodMade = primaryProd->resources->get(::Resource_obj::Wood_dyn());
HXLINE( 601)			int metalMade = 0;
HXLINE( 602)			if (primaryProd->resources->exists(::Resource_obj::Metal_dyn())) {
HXLINE( 603)				metalMade = ( (int)(primaryProd->resources->get(::Resource_obj::Metal_dyn())) );
            			}
HXLINE( 606)			int toolsMade = (this->resources->resources->get(::Resource_obj::Wood_dyn()) + woodMade);
HXLINE( 607)			int toolsMade1 = (this->resources->resources->get(::Resource_obj::Metal_dyn()) + metalMade);
HXLINE( 606)			int toolsMade2 = ::Utils_obj::minInt(toolsMade,toolsMade1,(5 * ( (int)(this->buildings->get(::Building_obj::Blacksmith_dyn())) )));
HXLINE( 610)			prod->add(::Resource_obj::Tools_dyn(),toolsMade2);
            		}
HXLINE( 613)		int _hx_tmp1 = this->countJobs();
HXDLIN( 613)		if ((_hx_tmp1 > this->population)) {
HXLINE( 614)			int _hx_tmp = this->population;
HXDLIN( 614)			return prod->multiplyAndRound((( (Float)(_hx_tmp) ) / ( (Float)(this->countJobs()) )));
            		}
            		else {
HXLINE( 616)			return prod;
            		}
HXLINE( 613)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateSecondaryProduction,return )

 ::Pile Island_obj::calculateConsumption(){
            	HX_GC_STACKFRAME(&_hx_pos_a227ab1282d9c004_619_calculateConsumption)
HXLINE( 620)		 ::Pile consumption =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE( 622)		 ::Dynamic totalGrain = this->resources->resources->get(::Resource_obj::Grain_dyn());
HXDLIN( 622)		int totalGrain1 = (totalGrain + this->calculatePrimaryProduction()->resources->get(::Resource_obj::Grain_dyn()));
HXLINE( 623)		 ::Dynamic totalFish = this->resources->resources->get(::Resource_obj::Fish_dyn());
HXDLIN( 623)		int totalFish1 = (totalFish + this->calculatePrimaryProduction()->resources->get(::Resource_obj::Fish_dyn()));
HXLINE( 625)		int toEat = (4 * this->population);
HXLINE( 627)		if ((toEat > (totalGrain1 + totalFish1))) {
HXLINE( 628)			consumption->add(::Resource_obj::Grain_dyn(),(toEat - totalFish1));
HXLINE( 629)			if ((totalFish1 > 0)) {
HXLINE( 629)				consumption->add(::Resource_obj::Fish_dyn(),totalFish1);
            			}
            		}
            		else {
HXLINE( 632)			int grainEaten = ::Math_obj::ceil((( (Float)((toEat * totalGrain1)) ) / ( (Float)((totalGrain1 + totalFish1)) )));
HXLINE( 633)			consumption->add(::Resource_obj::Grain_dyn(),grainEaten);
HXLINE( 634)			if (((toEat - grainEaten) > 0)) {
HXLINE( 634)				consumption->add(::Resource_obj::Fish_dyn(),(toEat - grainEaten));
            			}
            		}
HXLINE( 637)		if (::hx::IsGreater( this->resources->resources->get(::Resource_obj::Goods_dyn()),0 )) {
HXLINE( 638)			int goodsUsed = this->population;
HXDLIN( 638)			int goodsUsed1 = ::Utils_obj::minInt(goodsUsed,::Math_obj::ceil((( (Float)(this->resources->resources->get(::Resource_obj::Goods_dyn())) ) / ( (Float)(2) ))),null());
HXLINE( 639)			consumption->add(::Resource_obj::Goods_dyn(),goodsUsed1);
            		}
HXLINE( 643)		int a = ( (int)(this->buildings->get(::Building_obj::Blacksmith_dyn())) );
HXDLIN( 643)		bool aNeg = (a < 0);
HXDLIN( 643)		bool bNeg = (0 < 0);
HXDLIN( 643)		bool _hx_tmp;
HXDLIN( 643)		if ((aNeg != bNeg)) {
HXLINE( 643)			_hx_tmp = aNeg;
            		}
            		else {
HXLINE( 643)			_hx_tmp = (a > 0);
            		}
HXDLIN( 643)		if (_hx_tmp) {
HXLINE( 644)			 ::Dynamic toolsMade = this->calculateSecondaryProduction()->resources->get(::Resource_obj::Tools_dyn());
HXLINE( 646)			consumption->add(::Resource_obj::Wood_dyn(),( (int)(toolsMade) ));
HXLINE( 647)			consumption->add(::Resource_obj::Metal_dyn(),( (int)(toolsMade) ));
            		}
HXLINE( 650)		return consumption;
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateConsumption,return )

Float Island_obj::calculateHappinessFromEmployment(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_655_calculateHappinessFromEmployment)
HXDLIN( 655)		int _hx_tmp = ::Island_obj::baseHappiness;
HXDLIN( 655)		int _hx_tmp1 = this->population;
HXDLIN( 655)		return ::Utils_obj::round((( (Float)(_hx_tmp) ) * ::Math_obj::min(( (Float)(1) ),(( (Float)(_hx_tmp1) ) / ( (Float)((2 * this->countJobs())) )))),1);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateHappinessFromEmployment,return )

Float Island_obj::calculateHappinessFromFood(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_658_calculateHappinessFromFood)
HXLINE( 659)		 ::Dynamic fishEaten = this->calculateConsumption()->resources->get(::Resource_obj::Fish_dyn());
HXLINE( 660)		 ::Dynamic grainEaten = this->calculateConsumption()->resources->get(::Resource_obj::Grain_dyn());
HXLINE( 662)		return ::Utils_obj::round((( (Float)(::Island_obj::maxHappinessFromFood) ) * ::Math_obj::min((( (Float)(fishEaten) ) / ( (Float)(grainEaten) )),( (Float)(1) ))),1);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateHappinessFromFood,return )

Float Island_obj::calculateHappinessFromGoods(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_666_calculateHappinessFromGoods)
HXDLIN( 666)		return (( (Float)(this->calculateConsumption()->resources->get(::Resource_obj::Goods_dyn())) ) * ((Float)0.3));
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateHappinessFromGoods,return )

int Island_obj::calculateHappinessFromTemples(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_670_calculateHappinessFromTemples)
HXDLIN( 670)		return (3 * ( (int)(this->buildings->get(::Building_obj::Temple_dyn())) ));
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateHappinessFromTemples,return )

Float Island_obj::calculateHappiness(){
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_674_calculateHappiness)
HXDLIN( 674)		Float lhs = this->calculateHappinessFromEmployment();
HXDLIN( 674)		Float lhs1 = (lhs + this->calculateHappinessFromFood());
HXDLIN( 674)		Float lhs2 = (lhs1 + this->calculateHappinessFromGoods());
HXDLIN( 674)		int _hx_int = this->calculateHappinessFromTemples();
HXDLIN( 674)		Float _hx_tmp;
HXDLIN( 674)		if ((_hx_int < 0)) {
HXDLIN( 674)			_hx_tmp = (((Float)4294967296.0) + _hx_int);
            		}
            		else {
HXDLIN( 674)			_hx_tmp = (_hx_int + ((Float)0.0));
            		}
HXDLIN( 674)		return (_hx_tmp + lhs2);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Island_obj,calculateHappiness,return )

int Island_obj::cellRows;

int Island_obj::cellCols;

int Island_obj::baseHappiness;

int Island_obj::maxHappinessFromFood;


::hx::ObjectPtr< Island_obj > Island_obj::__new(int size, ::GenerationType type,::String name) {
	::hx::ObjectPtr< Island_obj > __this = new Island_obj();
	__this->__construct(size,type,name);
	return __this;
}

::hx::ObjectPtr< Island_obj > Island_obj::__alloc(::hx::Ctx *_hx_ctx,int size, ::GenerationType type,::String name) {
	Island_obj *__this = (Island_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Island_obj), true, "Island"));
	*(void **)__this = Island_obj::_hx_vtable;
	__this->__construct(size,type,name);
	return __this;
}

Island_obj::Island_obj()
{
}

void Island_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Island);
	HX_MARK_MEMBER_NAME(name,"name");
	HX_MARK_MEMBER_NAME(mainWindow,"mainWindow");
	HX_MARK_MEMBER_NAME(grid,"grid");
	HX_MARK_MEMBER_NAME(infoWindow,"infoWindow");
	HX_MARK_MEMBER_NAME(commandWindow,"commandWindow");
	HX_MARK_MEMBER_NAME(menuState,"menuState");
	HX_MARK_MEMBER_NAME(size,"size");
	HX_MARK_MEMBER_NAME(turn,"turn");
	HX_MARK_MEMBER_NAME(population,"population");
	HX_MARK_MEMBER_NAME(resources,"resources");
	HX_MARK_MEMBER_NAME(buildings,"buildings");
	HX_MARK_END_CLASS();
}

void Island_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(name,"name");
	HX_VISIT_MEMBER_NAME(mainWindow,"mainWindow");
	HX_VISIT_MEMBER_NAME(grid,"grid");
	HX_VISIT_MEMBER_NAME(infoWindow,"infoWindow");
	HX_VISIT_MEMBER_NAME(commandWindow,"commandWindow");
	HX_VISIT_MEMBER_NAME(menuState,"menuState");
	HX_VISIT_MEMBER_NAME(size,"size");
	HX_VISIT_MEMBER_NAME(turn,"turn");
	HX_VISIT_MEMBER_NAME(population,"population");
	HX_VISIT_MEMBER_NAME(resources,"resources");
	HX_VISIT_MEMBER_NAME(buildings,"buildings");
}

::hx::Val Island_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { return ::hx::Val( name ); }
		if (HX_FIELD_EQ(inName,"grid") ) { return ::hx::Val( grid ); }
		if (HX_FIELD_EQ(inName,"size") ) { return ::hx::Val( size ); }
		if (HX_FIELD_EQ(inName,"turn") ) { return ::hx::Val( turn ); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"write") ) { return ::hx::Val( write_dyn() ); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"getCell") ) { return ::hx::Val( getCell_dyn() ); }
		if (HX_FIELD_EQ(inName,"display") ) { return ::hx::Val( display_dyn() ); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"makeCell") ) { return ::hx::Val( makeCell_dyn() ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"menuState") ) { return ::hx::Val( menuState ); }
		if (HX_FIELD_EQ(inName,"resources") ) { return ::hx::Val( resources ); }
		if (HX_FIELD_EQ(inName,"buildings") ) { return ::hx::Val( buildings ); }
		if (HX_FIELD_EQ(inName,"countJobs") ) { return ::hx::Val( countJobs_dyn() ); }
		if (HX_FIELD_EQ(inName,"inputLoop") ) { return ::hx::Val( inputLoop_dyn() ); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"mainWindow") ) { return ::hx::Val( mainWindow ); }
		if (HX_FIELD_EQ(inName,"infoWindow") ) { return ::hx::Val( infoWindow ); }
		if (HX_FIELD_EQ(inName,"population") ) { return ::hx::Val( population ); }
		if (HX_FIELD_EQ(inName,"growIsland") ) { return ::hx::Val( growIsland_dyn() ); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"costToBuild") ) { return ::hx::Val( costToBuild_dyn() ); }
		if (HX_FIELD_EQ(inName,"commandMove") ) { return ::hx::Val( commandMove_dyn() ); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"countTerrain") ) { return ::hx::Val( countTerrain_dyn() ); }
		if (HX_FIELD_EQ(inName,"commandBuild") ) { return ::hx::Val( commandBuild_dyn() ); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"commandWindow") ) { return ::hx::Val( commandWindow ); }
		if (HX_FIELD_EQ(inName,"randomTerrain") ) { return ::hx::Val( randomTerrain_dyn() ); }
		if (HX_FIELD_EQ(inName,"generateEmpty") ) { return ::hx::Val( generateEmpty_dyn() ); }
		if (HX_FIELD_EQ(inName,"getActiveCell") ) { return ::hx::Val( getActiveCell_dyn() ); }
		if (HX_FIELD_EQ(inName,"costToUpgrade") ) { return ::hx::Val( costToUpgrade_dyn() ); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"generateFilled") ) { return ::hx::Val( generateFilled_dyn() ); }
		if (HX_FIELD_EQ(inName,"generateRandom") ) { return ::hx::Val( generateRandom_dyn() ); }
		if (HX_FIELD_EQ(inName,"countBuildings") ) { return ::hx::Val( countBuildings_dyn() ); }
		if (HX_FIELD_EQ(inName,"isCoastCellKey") ) { return ::hx::Val( isCoastCellKey_dyn() ); }
		if (HX_FIELD_EQ(inName,"commandUpgrade") ) { return ::hx::Val( commandUpgrade_dyn() ); }
		if (HX_FIELD_EQ(inName,"growPopulation") ) { return ::hx::Val( growPopulation_dyn() ); }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"generateOneCell") ) { return ::hx::Val( generateOneCell_dyn() ); }
		if (HX_FIELD_EQ(inName,"isValidLocation") ) { return ::hx::Val( isValidLocation_dyn() ); }
		if (HX_FIELD_EQ(inName,"commandNextTurn") ) { return ::hx::Val( commandNextTurn_dyn() ); }
		if (HX_FIELD_EQ(inName,"calculateIncome") ) { return ::hx::Val( calculateIncome_dyn() ); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"getActiveCellKey") ) { return ::hx::Val( getActiveCellKey_dyn() ); }
		if (HX_FIELD_EQ(inName,"shrinkPopulation") ) { return ::hx::Val( shrinkPopulation_dyn() ); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"calculateHappiness") ) { return ::hx::Val( calculateHappiness_dyn() ); }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"calculateConsumption") ) { return ::hx::Val( calculateConsumption_dyn() ); }
		break;
	case 23:
		if (HX_FIELD_EQ(inName,"calculateCellProduction") ) { return ::hx::Val( calculateCellProduction_dyn() ); }
		break;
	case 26:
		if (HX_FIELD_EQ(inName,"calculatePrimaryProduction") ) { return ::hx::Val( calculatePrimaryProduction_dyn() ); }
		if (HX_FIELD_EQ(inName,"calculateHappinessFromFood") ) { return ::hx::Val( calculateHappinessFromFood_dyn() ); }
		break;
	case 27:
		if (HX_FIELD_EQ(inName,"calculateHappinessFromGoods") ) { return ::hx::Val( calculateHappinessFromGoods_dyn() ); }
		break;
	case 28:
		if (HX_FIELD_EQ(inName,"calculateSecondaryProduction") ) { return ::hx::Val( calculateSecondaryProduction_dyn() ); }
		break;
	case 29:
		if (HX_FIELD_EQ(inName,"calculateHappinessFromTemples") ) { return ::hx::Val( calculateHappinessFromTemples_dyn() ); }
		break;
	case 32:
		if (HX_FIELD_EQ(inName,"calculateHappinessFromEmployment") ) { return ::hx::Val( calculateHappinessFromEmployment_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

bool Island_obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 8:
		if (HX_FIELD_EQ(inName,"cellRows") ) { outValue = ( cellRows ); return true; }
		if (HX_FIELD_EQ(inName,"cellCols") ) { outValue = ( cellCols ); return true; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"baseHappiness") ) { outValue = ( baseHappiness ); return true; }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"maxHappinessFromFood") ) { outValue = ( maxHappinessFromFood ); return true; }
	}
	return false;
}

::hx::Val Island_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { name=inValue.Cast< ::String >(); return inValue; }
		if (HX_FIELD_EQ(inName,"grid") ) { grid=inValue.Cast<  ::HexGrid >(); return inValue; }
		if (HX_FIELD_EQ(inName,"size") ) { size=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"turn") ) { turn=inValue.Cast< int >(); return inValue; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"menuState") ) { menuState=inValue.Cast<  ::MenuState >(); return inValue; }
		if (HX_FIELD_EQ(inName,"resources") ) { resources=inValue.Cast<  ::Pile >(); return inValue; }
		if (HX_FIELD_EQ(inName,"buildings") ) { buildings=inValue.Cast<  ::haxe::ds::EnumValueMap >(); return inValue; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"mainWindow") ) { mainWindow=inValue.Cast<  ::TextScreen >(); return inValue; }
		if (HX_FIELD_EQ(inName,"infoWindow") ) { infoWindow=inValue.Cast<  ::TextWindow >(); return inValue; }
		if (HX_FIELD_EQ(inName,"population") ) { population=inValue.Cast< int >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"commandWindow") ) { commandWindow=inValue.Cast<  ::TextWindow >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

bool Island_obj::__SetStatic(const ::String &inName,Dynamic &ioValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 8:
		if (HX_FIELD_EQ(inName,"cellRows") ) { cellRows=ioValue.Cast< int >(); return true; }
		if (HX_FIELD_EQ(inName,"cellCols") ) { cellCols=ioValue.Cast< int >(); return true; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"baseHappiness") ) { baseHappiness=ioValue.Cast< int >(); return true; }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"maxHappinessFromFood") ) { maxHappinessFromFood=ioValue.Cast< int >(); return true; }
	}
	return false;
}

void Island_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("name",4b,72,ff,48));
	outFields->push(HX_("mainWindow",09,b1,38,a8));
	outFields->push(HX_("grid",c6,d6,6b,44));
	outFields->push(HX_("infoWindow",fe,46,4f,db));
	outFields->push(HX_("commandWindow",9b,03,83,80));
	outFields->push(HX_("menuState",f2,df,e3,1e));
	outFields->push(HX_("size",c1,a0,53,4c));
	outFields->push(HX_("turn",7d,eb,05,4d));
	outFields->push(HX_("population",8d,37,08,f4));
	outFields->push(HX_("resources",e5,d7,b0,39));
	outFields->push(HX_("buildings",7f,43,1e,fb));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo Island_obj_sMemberStorageInfo[] = {
	{::hx::fsString,(int)offsetof(Island_obj,name),HX_("name",4b,72,ff,48)},
	{::hx::fsObject /*  ::TextScreen */ ,(int)offsetof(Island_obj,mainWindow),HX_("mainWindow",09,b1,38,a8)},
	{::hx::fsObject /*  ::HexGrid */ ,(int)offsetof(Island_obj,grid),HX_("grid",c6,d6,6b,44)},
	{::hx::fsObject /*  ::TextWindow */ ,(int)offsetof(Island_obj,infoWindow),HX_("infoWindow",fe,46,4f,db)},
	{::hx::fsObject /*  ::TextWindow */ ,(int)offsetof(Island_obj,commandWindow),HX_("commandWindow",9b,03,83,80)},
	{::hx::fsObject /*  ::MenuState */ ,(int)offsetof(Island_obj,menuState),HX_("menuState",f2,df,e3,1e)},
	{::hx::fsInt,(int)offsetof(Island_obj,size),HX_("size",c1,a0,53,4c)},
	{::hx::fsInt,(int)offsetof(Island_obj,turn),HX_("turn",7d,eb,05,4d)},
	{::hx::fsInt,(int)offsetof(Island_obj,population),HX_("population",8d,37,08,f4)},
	{::hx::fsObject /*  ::Pile */ ,(int)offsetof(Island_obj,resources),HX_("resources",e5,d7,b0,39)},
	{::hx::fsObject /*  ::haxe::ds::EnumValueMap */ ,(int)offsetof(Island_obj,buildings),HX_("buildings",7f,43,1e,fb)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo Island_obj_sStaticStorageInfo[] = {
	{::hx::fsInt,(void *) &Island_obj::cellRows,HX_("cellRows",db,bb,d3,1a)},
	{::hx::fsInt,(void *) &Island_obj::cellCols,HX_("cellCols",f5,7e,e9,10)},
	{::hx::fsInt,(void *) &Island_obj::baseHappiness,HX_("baseHappiness",56,9b,f8,15)},
	{::hx::fsInt,(void *) &Island_obj::maxHappinessFromFood,HX_("maxHappinessFromFood",ab,92,7c,1c)},
	{ ::hx::fsUnknown, 0, null()}
};
#endif

static ::String Island_obj_sMemberFields[] = {
	HX_("name",4b,72,ff,48),
	HX_("mainWindow",09,b1,38,a8),
	HX_("grid",c6,d6,6b,44),
	HX_("infoWindow",fe,46,4f,db),
	HX_("commandWindow",9b,03,83,80),
	HX_("menuState",f2,df,e3,1e),
	HX_("size",c1,a0,53,4c),
	HX_("turn",7d,eb,05,4d),
	HX_("population",8d,37,08,f4),
	HX_("resources",e5,d7,b0,39),
	HX_("buildings",7f,43,1e,fb),
	HX_("randomTerrain",f2,47,79,3d),
	HX_("makeCell",b0,16,5b,38),
	HX_("generateEmpty",18,0b,57,16),
	HX_("generateOneCell",73,5c,d9,32),
	HX_("generateFilled",b7,b6,e8,8b),
	HX_("growIsland",48,bf,9f,1d),
	HX_("generateRandom",18,cb,48,be),
	HX_("write",df,6c,59,d0),
	HX_("getCell",58,d1,3f,14),
	HX_("getActiveCell",be,46,5a,47),
	HX_("getActiveCellKey",81,45,a5,0f),
	HX_("countBuildings",b0,4c,3c,b2),
	HX_("countTerrain",a6,56,80,b4),
	HX_("countJobs",45,b2,85,58),
	HX_("costToUpgrade",54,5c,b2,b5),
	HX_("costToBuild",e6,a4,5b,38),
	HX_("isValidLocation",07,45,e9,48),
	HX_("isCoastCellKey",b1,8a,ab,88),
	HX_("display",42,2a,4a,bb),
	HX_("inputLoop",8e,63,e2,0e),
	HX_("commandMove",fc,81,c1,e5),
	HX_("commandBuild",e3,49,15,d2),
	HX_("commandUpgrade",91,fa,dc,6c),
	HX_("commandNextTurn",7b,82,04,65),
	HX_("growPopulation",80,0d,92,b7),
	HX_("shrinkPopulation",b6,23,ef,55),
	HX_("calculateIncome",6f,85,7b,48),
	HX_("calculateCellProduction",41,5a,7e,75),
	HX_("calculatePrimaryProduction",15,88,94,25),
	HX_("calculateSecondaryProduction",c7,cc,2a,61),
	HX_("calculateConsumption",55,07,e1,eb),
	HX_("calculateHappinessFromEmployment",77,54,eb,2f),
	HX_("calculateHappinessFromFood",a9,cd,04,bc),
	HX_("calculateHappinessFromGoods",2b,bb,95,5b),
	HX_("calculateHappinessFromTemples",1b,f7,fc,b6),
	HX_("calculateHappiness",61,1b,3b,aa),
	::String(null()) };

static void Island_obj_sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Island_obj::cellRows,"cellRows");
	HX_MARK_MEMBER_NAME(Island_obj::cellCols,"cellCols");
	HX_MARK_MEMBER_NAME(Island_obj::baseHappiness,"baseHappiness");
	HX_MARK_MEMBER_NAME(Island_obj::maxHappinessFromFood,"maxHappinessFromFood");
};

#ifdef HXCPP_VISIT_ALLOCS
static void Island_obj_sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Island_obj::cellRows,"cellRows");
	HX_VISIT_MEMBER_NAME(Island_obj::cellCols,"cellCols");
	HX_VISIT_MEMBER_NAME(Island_obj::baseHappiness,"baseHappiness");
	HX_VISIT_MEMBER_NAME(Island_obj::maxHappinessFromFood,"maxHappinessFromFood");
};

#endif

::hx::Class Island_obj::__mClass;

static ::String Island_obj_sStaticFields[] = {
	HX_("cellRows",db,bb,d3,1a),
	HX_("cellCols",f5,7e,e9,10),
	HX_("baseHappiness",56,9b,f8,15),
	HX_("maxHappinessFromFood",ab,92,7c,1c),
	::String(null())
};

void Island_obj::__register()
{
	Island_obj _hx_dummy;
	Island_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Island",f5,12,cf,ae);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Island_obj::__GetStatic;
	__mClass->mSetStaticField = &Island_obj::__SetStatic;
	__mClass->mMarkFunc = Island_obj_sMarkStatics;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Island_obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(Island_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< Island_obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = Island_obj_sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Island_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Island_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

void Island_obj::__boot()
{
{
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_12_boot)
HXDLIN(  12)		__mClass->__meta__ =  ::Dynamic(::hx::Anon_obj::Create(1)
            			->setFixed(0,HX_("fields",79,8e,8e,80), ::Dynamic(::hx::Anon_obj::Create(2)
            				->setFixed(0,HX_("growPopulation",80,0d,92,b7), ::Dynamic(::hx::Anon_obj::Create(1)
            					->setFixed(0,HX_("IMPROVE",18,ca,97,eb),null())))
            				->setFixed(1,HX_("shrinkPopulation",b6,23,ef,55), ::Dynamic(::hx::Anon_obj::Create(1)
            					->setFixed(0,HX_("IMPROVE",18,ca,97,eb),null()))))));
            	}
{
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_24_boot)
HXDLIN(  24)		cellRows = 2;
            	}
{
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_25_boot)
HXDLIN(  25)		cellCols = 3;
            	}
{
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_34_boot)
HXDLIN(  34)		baseHappiness = 50;
            	}
{
            	HX_STACKFRAME(&_hx_pos_a227ab1282d9c004_35_boot)
HXDLIN(  35)		maxHappinessFromFood = 20;
            	}
}

