#include <hxcpp.h>

#ifndef INCLUDED_Building
#include <Building.h>
#endif
#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
#ifndef INCLUDED_Island
#include <Island.h>
#endif
#ifndef INCLUDED_IslandCell
#include <IslandCell.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_Terrain
#include <Terrain.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED__Building_Building_Fields_
#include <_Building/Building_Fields_.h>
#endif
#ifndef INCLUDED__Island_Island_Fields_
#include <_Island/Island_Fields_.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_454c61ca6df760c4_703_new,"IslandCell","new",0x4cf387a9,"IslandCell.new","Island.hx",703,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_454c61ca6df760c4_715_render,"IslandCell","render",0x4c36a7ad,"IslandCell.render","Island.hx",715,0xc47cb6e9)

void IslandCell_obj::__construct( ::Terrain __o_terrain,::String name){
            		 ::Terrain terrain = __o_terrain;
            		if (::hx::IsNull(__o_terrain)) terrain = ::Terrain_obj::Forest_dyn();
            	HX_STACKFRAME(&_hx_pos_454c61ca6df760c4_703_new)
HXLINE( 705)		super::__construct(::Island_obj::cellRows,::Island_obj::cellCols,name);
HXLINE( 707)		this->terrain = terrain;
HXLINE( 709)		this->defaultChar = ( (::String)(::_Island::Island_Fields__obj::terrainChars->get(terrain)) );
HXLINE( 711)		this->render();
            	}

Dynamic IslandCell_obj::__CreateEmpty() { return new IslandCell_obj; }

void *IslandCell_obj::_hx_vtable = 0;

Dynamic IslandCell_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< IslandCell_obj > _hx_result = new IslandCell_obj();
	_hx_result->__construct(inArgs[0],inArgs[1]);
	return _hx_result;
}

bool IslandCell_obj::_hx_isInstanceOf(int inClassId) {
	if (inClassId<=(int)0x0b23efa1) {
		if (inClassId<=(int)0x00e943e6) {
			return inClassId==(int)0x00000001 || inClassId==(int)0x00e943e6;
		} else {
			return inClassId==(int)0x0b23efa1;
		}
	} else {
		return inClassId==(int)0x16534825 || inClassId==(int)0x4e45a1f7;
	}
}

void IslandCell_obj::render(){
            	HX_STACKFRAME(&_hx_pos_454c61ca6df760c4_715_render)
HXLINE( 717)		this->clear(null());
HXLINE( 719)		if (::hx::IsNotNull( this->building )) {
HXLINE( 720)			this->write(( (::String)(::_Building::Building_Fields__obj::names->get(this->building)) ).charAt(0),null(),0,1);
HXLINE( 721)			int _hx_int = this->buildingLevel;
HXDLIN( 721)			Float _hx_tmp;
HXDLIN( 721)			if ((_hx_int < 0)) {
HXLINE( 721)				_hx_tmp = (((Float)4294967296.0) + _hx_int);
            			}
            			else {
HXLINE( 721)				_hx_tmp = (_hx_int + ((Float)0.0));
            			}
HXDLIN( 721)			::String _hx_tmp1 = (HX_("",00,00,00,00) + ::Std_obj::string(_hx_tmp));
HXDLIN( 721)			this->writeLeft(_hx_tmp1,null(),1,(this->columns - 2));
            		}
HXLINE( 727)		this->copyDataBuffer();
            	}



::hx::ObjectPtr< IslandCell_obj > IslandCell_obj::__new( ::Terrain __o_terrain,::String name) {
	::hx::ObjectPtr< IslandCell_obj > __this = new IslandCell_obj();
	__this->__construct(__o_terrain,name);
	return __this;
}

::hx::ObjectPtr< IslandCell_obj > IslandCell_obj::__alloc(::hx::Ctx *_hx_ctx, ::Terrain __o_terrain,::String name) {
	IslandCell_obj *__this = (IslandCell_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(IslandCell_obj), true, "IslandCell"));
	*(void **)__this = IslandCell_obj::_hx_vtable;
	__this->__construct(__o_terrain,name);
	return __this;
}

IslandCell_obj::IslandCell_obj()
{
}

void IslandCell_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(IslandCell);
	HX_MARK_MEMBER_NAME(terrain,"terrain");
	HX_MARK_MEMBER_NAME(building,"building");
	HX_MARK_MEMBER_NAME(buildingLevel,"buildingLevel");
	 ::Cell_obj::__Mark(HX_MARK_ARG);
	HX_MARK_END_CLASS();
}

void IslandCell_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(terrain,"terrain");
	HX_VISIT_MEMBER_NAME(building,"building");
	HX_VISIT_MEMBER_NAME(buildingLevel,"buildingLevel");
	 ::Cell_obj::__Visit(HX_VISIT_ARG);
}

::hx::Val IslandCell_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"render") ) { return ::hx::Val( render_dyn() ); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"terrain") ) { return ::hx::Val( terrain ); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"building") ) { return ::hx::Val( building ); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"buildingLevel") ) { return ::hx::Val( buildingLevel ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val IslandCell_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 7:
		if (HX_FIELD_EQ(inName,"terrain") ) { terrain=inValue.Cast<  ::Terrain >(); return inValue; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"building") ) { building=inValue.Cast<  ::Building >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"buildingLevel") ) { buildingLevel=inValue.Cast< int >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void IslandCell_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("terrain",b5,ab,17,29));
	outFields->push(HX_("building",74,e2,c7,53));
	outFields->push(HX_("buildingLevel",70,3e,5b,a9));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo IslandCell_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::Terrain */ ,(int)offsetof(IslandCell_obj,terrain),HX_("terrain",b5,ab,17,29)},
	{::hx::fsObject /*  ::Building */ ,(int)offsetof(IslandCell_obj,building),HX_("building",74,e2,c7,53)},
	{::hx::fsInt,(int)offsetof(IslandCell_obj,buildingLevel),HX_("buildingLevel",70,3e,5b,a9)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *IslandCell_obj_sStaticStorageInfo = 0;
#endif

static ::String IslandCell_obj_sMemberFields[] = {
	HX_("terrain",b5,ab,17,29),
	HX_("building",74,e2,c7,53),
	HX_("buildingLevel",70,3e,5b,a9),
	HX_("render",56,6b,29,05),
	::String(null()) };

::hx::Class IslandCell_obj::__mClass;

void IslandCell_obj::__register()
{
	IslandCell_obj _hx_dummy;
	IslandCell_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("IslandCell",37,7f,82,36);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(IslandCell_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< IslandCell_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = IslandCell_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = IslandCell_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

