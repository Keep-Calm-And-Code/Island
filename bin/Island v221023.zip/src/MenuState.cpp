#include <hxcpp.h>

#ifndef INCLUDED_MenuState
#include <MenuState.h>
#endif

::MenuState MenuState_obj::Build;

::MenuState MenuState_obj::Upgrade;

::MenuState MenuState_obj::ViewPopulation;

bool MenuState_obj::__GetStatic(const ::String &inName, ::Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Build",0e,4b,18,4e)) { outValue = MenuState_obj::Build; return true; }
	if (inName==HX_("Upgrade",7c,dc,82,30)) { outValue = MenuState_obj::Upgrade; return true; }
	if (inName==HX_("ViewPopulation",72,d2,d0,c4)) { outValue = MenuState_obj::ViewPopulation; return true; }
	return super::__GetStatic(inName, outValue, inCallProp);
}

HX_DEFINE_CREATE_ENUM(MenuState_obj)

int MenuState_obj::__FindIndex(::String inName)
{
	if (inName==HX_("Build",0e,4b,18,4e)) return 0;
	if (inName==HX_("Upgrade",7c,dc,82,30)) return 1;
	if (inName==HX_("ViewPopulation",72,d2,d0,c4)) return 2;
	return super::__FindIndex(inName);
}

int MenuState_obj::__FindArgCount(::String inName)
{
	if (inName==HX_("Build",0e,4b,18,4e)) return 0;
	if (inName==HX_("Upgrade",7c,dc,82,30)) return 0;
	if (inName==HX_("ViewPopulation",72,d2,d0,c4)) return 0;
	return super::__FindArgCount(inName);
}

::hx::Val MenuState_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Build",0e,4b,18,4e)) return Build;
	if (inName==HX_("Upgrade",7c,dc,82,30)) return Upgrade;
	if (inName==HX_("ViewPopulation",72,d2,d0,c4)) return ViewPopulation;
	return super::__Field(inName,inCallProp);
}

static ::String MenuState_obj_sStaticFields[] = {
	HX_("Build",0e,4b,18,4e),
	HX_("Upgrade",7c,dc,82,30),
	HX_("ViewPopulation",72,d2,d0,c4),
	::String(null())
};

::hx::Class MenuState_obj::__mClass;

Dynamic __Create_MenuState_obj() { return new MenuState_obj; }

void MenuState_obj::__register()
{

::hx::Static(__mClass) = ::hx::_hx_RegisterClass(HX_("MenuState",d2,bf,b6,c0), ::hx::TCanCast< MenuState_obj >,MenuState_obj_sStaticFields,0,
	&__Create_MenuState_obj, &__Create,
	&super::__SGetClass(), &CreateMenuState_obj, 0
#ifdef HXCPP_VISIT_ALLOCS
    , 0
#endif
#ifdef HXCPP_SCRIPTABLE
    , 0
#endif
);
	__mClass->mGetStaticField = &MenuState_obj::__GetStatic;
}

void MenuState_obj::__boot()
{
Build = ::hx::CreateConstEnum< MenuState_obj >(HX_("Build",0e,4b,18,4e),0);
Upgrade = ::hx::CreateConstEnum< MenuState_obj >(HX_("Upgrade",7c,dc,82,30),1);
ViewPopulation = ::hx::CreateConstEnum< MenuState_obj >(HX_("ViewPopulation",72,d2,d0,c4),2);
}


