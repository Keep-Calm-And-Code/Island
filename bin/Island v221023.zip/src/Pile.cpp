#include <hxcpp.h>

#ifndef INCLUDED_95f339a1d026d52c
#define INCLUDED_95f339a1d026d52c
#include "hxMath.h"
#endif
#ifndef INCLUDED_Pile
#include <Pile.h>
#endif
#ifndef INCLUDED_Resource
#include <Resource.h>
#endif
#ifndef INCLUDED_Type
#include <Type.h>
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif
#ifndef INCLUDED__Resource_Resource_Fields_
#include <_Resource/Resource_Fields_.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_7948705dd54df91b_44_new,"Pile","new",0x62d08ec4,"Pile.new","Resource.hx",44,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_53_toString,"Pile","toString",0x1eb167c8,"Pile.toString","Resource.hx",53,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_56_toLeftAlignedString,"Pile","toLeftAlignedString",0xe8a20037,"Pile.toLeftAlignedString","Resource.hx",56,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_75_toResourceAlignedString,"Pile","toResourceAlignedString",0x4476e390,"Pile.toResourceAlignedString","Resource.hx",75,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_99_get,"Pile","get",0x62cb3efa,"Pile.get","Resource.hx",99,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_106_hasPile,"Pile","hasPile",0x2061d190,"Pile.hasPile","Resource.hx",106,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_116_add,"Pile","add",0x62c6b085,"Pile.add","Resource.hx",116,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_123_cutoffAdd,"Pile","cutoffAdd",0x833eda58,"Pile.cutoffAdd","Resource.hx",123,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_130_subtract,"Pile","subtract",0xde540c30,"Pile.subtract","Resource.hx",130,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_135_cutoffSubtract,"Pile","cutoffSubtract",0x09f4657d,"Pile.cutoffSubtract","Resource.hx",135,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_138_addPile,"Pile","addPile",0x8d5af3d7,"Pile.addPile","Resource.hx",138,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_145_cutoffAddPile,"Pile","cutoffAddPile",0x3528032a,"Pile.cutoffAddPile","Resource.hx",145,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_152_subtractPile,"Pile","subtractPile",0x3fb70102,"Pile.subtractPile","Resource.hx",152,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_159_cutoffSubtractPile,"Pile","cutoffSubtractPile",0xbad284cf,"Pile.cutoffSubtractPile","Resource.hx",159,0x8d80f290)
HX_LOCAL_STACK_FRAME(_hx_pos_7948705dd54df91b_176_multiplyAndRound,"Pile","multiplyAndRound",0x1f163757,"Pile.multiplyAndRound","Resource.hx",176,0x8d80f290)

void Pile_obj::__construct( ::haxe::ds::EnumValueMap resources){
            	HX_GC_STACKFRAME(&_hx_pos_7948705dd54df91b_44_new)
HXDLIN(  44)		if (::hx::IsNull( resources )) {
HXLINE(  45)			this->resources =  ::haxe::ds::EnumValueMap_obj::__alloc( HX_CTX );
            		}
            		else {
HXLINE(  48)			this->resources = resources;
            		}
            	}

Dynamic Pile_obj::__CreateEmpty() { return new Pile_obj; }

void *Pile_obj::_hx_vtable = 0;

Dynamic Pile_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Pile_obj > _hx_result = new Pile_obj();
	_hx_result->__construct(inArgs[0]);
	return _hx_result;
}

bool Pile_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x098412f6;
}

::String Pile_obj::toString(){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_53_toString)
HXDLIN(  53)		return this->toResourceAlignedString(HX_("",00,00,00,00),null());
            	}


HX_DEFINE_DYNAMIC_FUNC0(Pile_obj,toString,return )

::String Pile_obj::toLeftAlignedString(::String __o_prefix, ::Dynamic __o_isResourceNameVisible){
            		::String prefix = __o_prefix;
            		if (::hx::IsNull(__o_prefix)) prefix = HX_("",00,00,00,00);
            		 ::Dynamic isResourceNameVisible = __o_isResourceNameVisible;
            		if (::hx::IsNull(__o_isResourceNameVisible)) isResourceNameVisible = true;
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_56_toLeftAlignedString)
HXLINE(  57)		::String all = HX_("",00,00,00,00);
HXLINE(  59)		{
HXLINE(  59)			 ::Dynamic r = this->resources->keys();
HXDLIN(  59)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE(  59)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE(  61)				::String s = ((prefix + this->resources->get(r1)) + HX_(" ",20,00,00,00));
HXLINE(  62)				if (( (bool)(isResourceNameVisible) )) {
HXLINE(  62)					s = (s + ::_Resource::Resource_Fields__obj::names->get(r1));
            				}
HXLINE(  64)				int padLength = ::Utils_obj::maxInt((10 - s.length),0);
HXLINE(  65)				{
HXLINE(  65)					int _g = 0;
HXDLIN(  65)					int _g1 = padLength;
HXDLIN(  65)					while((_g < _g1)){
HXLINE(  65)						_g = (_g + 1);
HXDLIN(  65)						int i = (_g - 1);
HXLINE(  66)						s = (s + HX_(" ",20,00,00,00));
            					}
            				}
HXLINE(  69)				all = (all + s);
            			}
            		}
HXLINE(  72)		return all;
            	}


HX_DEFINE_DYNAMIC_FUNC2(Pile_obj,toLeftAlignedString,return )

::String Pile_obj::toResourceAlignedString(::String __o_prefix, ::Dynamic __o_isResourceNameVisible){
            		::String prefix = __o_prefix;
            		if (::hx::IsNull(__o_prefix)) prefix = HX_("",00,00,00,00);
            		 ::Dynamic isResourceNameVisible = __o_isResourceNameVisible;
            		if (::hx::IsNull(__o_isResourceNameVisible)) isResourceNameVisible = true;
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_75_toResourceAlignedString)
HXLINE(  76)		::String all = HX_("",00,00,00,00);
HXLINE(  78)		{
HXLINE(  78)			int _g = 0;
HXDLIN(  78)			::Array< ::Dynamic> _g1 = ::Type_obj::allEnums(::hx::ClassOf< ::Resource >());
HXDLIN(  78)			while((_g < _g1->length)){
HXLINE(  78)				 ::Resource r = _g1->__get(_g).StaticCast<  ::Resource >();
HXDLIN(  78)				_g = (_g + 1);
HXLINE(  80)				::String s = HX_("",00,00,00,00);
HXLINE(  81)				if (this->resources->exists(r)) {
HXLINE(  82)					s = ((prefix + this->resources->get(r)) + HX_(" ",20,00,00,00));
HXLINE(  83)					if (( (bool)(isResourceNameVisible) )) {
HXLINE(  83)						s = (s + ::_Resource::Resource_Fields__obj::names->get(r));
            					}
            				}
HXLINE(  86)				int padLength = ::Utils_obj::maxInt((10 - s.length),0);
HXLINE(  87)				{
HXLINE(  87)					int _g2 = 0;
HXDLIN(  87)					int _g3 = padLength;
HXDLIN(  87)					while((_g2 < _g3)){
HXLINE(  87)						_g2 = (_g2 + 1);
HXDLIN(  87)						int i = (_g2 - 1);
HXLINE(  88)						s = (s + HX_(" ",20,00,00,00));
            					}
            				}
HXLINE(  91)				all = (all + s);
            			}
            		}
HXLINE(  94)		return all;
            	}


HX_DEFINE_DYNAMIC_FUNC2(Pile_obj,toResourceAlignedString,return )

 ::Dynamic Pile_obj::get( ::Resource r){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_99_get)
HXDLIN(  99)		if (this->resources->exists(r)) {
HXLINE( 100)			return this->resources->get(r);
            		}
            		else {
HXLINE( 102)			return null();
            		}
HXLINE(  99)		return 0;
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,get,return )

bool Pile_obj::hasPile( ::Pile p){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_106_hasPile)
HXLINE( 107)		{
HXLINE( 107)			 ::Dynamic r = p->resources->keys();
HXDLIN( 107)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 107)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE( 108)				bool _hx_tmp;
HXDLIN( 108)				if (this->resources->exists(r1)) {
HXLINE( 108)					 ::Dynamic _hx_tmp1 = this->resources->get(r1);
HXDLIN( 108)					_hx_tmp = ::hx::IsLess( _hx_tmp1,p->resources->get(r1) );
            				}
            				else {
HXLINE( 108)					_hx_tmp = true;
            				}
HXDLIN( 108)				if (_hx_tmp) {
HXLINE( 109)					return false;
            				}
            			}
            		}
HXLINE( 112)		return true;
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,hasPile,return )

 ::Pile Pile_obj::add( ::Resource r,int n){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_116_add)
HXLINE( 117)		if (this->resources->exists(r)) {
HXLINE( 117)			 ::Resource _g = r;
HXDLIN( 117)			 ::haxe::ds::EnumValueMap _g1 = this->resources;
HXDLIN( 117)			{
HXLINE( 117)				int v = (_g1->get(_g) + n);
HXDLIN( 117)				_g1->set(_g,v);
            			}
            		}
            		else {
HXLINE( 118)			this->resources->set(r,n);
            		}
HXLINE( 119)		return ::hx::ObjectPtr<OBJ_>(this);
            	}


HX_DEFINE_DYNAMIC_FUNC2(Pile_obj,add,return )

 ::Pile Pile_obj::cutoffAdd( ::Resource r,int n){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_123_cutoffAdd)
HXLINE( 124)		if (this->resources->exists(r)) {
HXLINE( 124)			::Dynamic this1 = this->resources;
HXDLIN( 124)			int v = ::Utils_obj::maxInt((this->resources->get(r) + n),0);
HXDLIN( 124)			( ( ::haxe::ds::EnumValueMap)(this1) )->set(r,v);
            		}
            		else {
HXLINE( 125)			::Dynamic this1 = this->resources;
HXDLIN( 125)			int v = ::Utils_obj::maxInt(n,0);
HXDLIN( 125)			( ( ::haxe::ds::EnumValueMap)(this1) )->set(r,v);
            		}
HXLINE( 126)		return ::hx::ObjectPtr<OBJ_>(this);
            	}


HX_DEFINE_DYNAMIC_FUNC2(Pile_obj,cutoffAdd,return )

void Pile_obj::subtract( ::Resource r,int n){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_130_subtract)
HXDLIN( 130)		this->add(r,-(n));
            	}


HX_DEFINE_DYNAMIC_FUNC2(Pile_obj,subtract,(void))

void Pile_obj::cutoffSubtract( ::Resource r,int n){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_135_cutoffSubtract)
HXDLIN( 135)		this->cutoffAdd(r,-(n));
            	}


HX_DEFINE_DYNAMIC_FUNC2(Pile_obj,cutoffSubtract,(void))

 ::Pile Pile_obj::addPile( ::Pile p){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_138_addPile)
HXLINE( 139)		{
HXLINE( 139)			 ::Dynamic r = p->resources->keys();
HXDLIN( 139)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 139)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE( 140)				this->add(r1,( (int)(p->resources->get(r1)) ));
            			}
            		}
HXLINE( 142)		return ::hx::ObjectPtr<OBJ_>(this);
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,addPile,return )

 ::Pile Pile_obj::cutoffAddPile( ::Pile p){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_145_cutoffAddPile)
HXLINE( 146)		{
HXLINE( 146)			 ::Dynamic r = p->resources->keys();
HXDLIN( 146)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 146)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE( 147)				this->cutoffAdd(r1,( (int)(p->resources->get(r1)) ));
            			}
            		}
HXLINE( 149)		return ::hx::ObjectPtr<OBJ_>(this);
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,cutoffAddPile,return )

 ::Pile Pile_obj::subtractPile( ::Pile p){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_152_subtractPile)
HXLINE( 153)		{
HXLINE( 153)			 ::Dynamic r = p->resources->keys();
HXDLIN( 153)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 153)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE( 154)				this->subtract(r1,( (int)(p->resources->get(r1)) ));
            			}
            		}
HXLINE( 156)		return ::hx::ObjectPtr<OBJ_>(this);
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,subtractPile,return )

 ::Pile Pile_obj::cutoffSubtractPile( ::Pile p){
            	HX_STACKFRAME(&_hx_pos_7948705dd54df91b_159_cutoffSubtractPile)
HXLINE( 160)		{
HXLINE( 160)			 ::Dynamic r = p->resources->keys();
HXDLIN( 160)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 160)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE( 161)				this->cutoffSubtract(r1,( (int)(p->resources->get(r1)) ));
            			}
            		}
HXLINE( 163)		return ::hx::ObjectPtr<OBJ_>(this);
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,cutoffSubtractPile,return )

 ::Pile Pile_obj::multiplyAndRound(Float f){
            	HX_GC_STACKFRAME(&_hx_pos_7948705dd54df91b_176_multiplyAndRound)
HXLINE( 177)		 ::Pile product =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE( 179)		{
HXLINE( 179)			 ::Dynamic r = this->resources->keys();
HXDLIN( 179)			while(( (bool)(r->__Field(HX_("hasNext",6d,a5,46,18),::hx::paccDynamic)()) )){
HXLINE( 179)				 ::Resource r1 = r->__Field(HX_("next",f3,84,02,49),::hx::paccDynamic)();
HXLINE( 180)				product->add(r1,::Math_obj::floor(((( (Float)(this->resources->get(r1)) ) * f) + ((Float)0.5))));
            			}
            		}
HXLINE( 183)		return product;
            	}


HX_DEFINE_DYNAMIC_FUNC1(Pile_obj,multiplyAndRound,return )


::hx::ObjectPtr< Pile_obj > Pile_obj::__new( ::haxe::ds::EnumValueMap resources) {
	::hx::ObjectPtr< Pile_obj > __this = new Pile_obj();
	__this->__construct(resources);
	return __this;
}

::hx::ObjectPtr< Pile_obj > Pile_obj::__alloc(::hx::Ctx *_hx_ctx, ::haxe::ds::EnumValueMap resources) {
	Pile_obj *__this = (Pile_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(Pile_obj), true, "Pile"));
	*(void **)__this = Pile_obj::_hx_vtable;
	__this->__construct(resources);
	return __this;
}

Pile_obj::Pile_obj()
{
}

void Pile_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(Pile);
	HX_MARK_MEMBER_NAME(resources,"resources");
	HX_MARK_END_CLASS();
}

void Pile_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(resources,"resources");
}

::hx::Val Pile_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"get") ) { return ::hx::Val( get_dyn() ); }
		if (HX_FIELD_EQ(inName,"add") ) { return ::hx::Val( add_dyn() ); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"hasPile") ) { return ::hx::Val( hasPile_dyn() ); }
		if (HX_FIELD_EQ(inName,"addPile") ) { return ::hx::Val( addPile_dyn() ); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toString") ) { return ::hx::Val( toString_dyn() ); }
		if (HX_FIELD_EQ(inName,"subtract") ) { return ::hx::Val( subtract_dyn() ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"resources") ) { return ::hx::Val( resources ); }
		if (HX_FIELD_EQ(inName,"cutoffAdd") ) { return ::hx::Val( cutoffAdd_dyn() ); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"subtractPile") ) { return ::hx::Val( subtractPile_dyn() ); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"cutoffAddPile") ) { return ::hx::Val( cutoffAddPile_dyn() ); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"cutoffSubtract") ) { return ::hx::Val( cutoffSubtract_dyn() ); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"multiplyAndRound") ) { return ::hx::Val( multiplyAndRound_dyn() ); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"cutoffSubtractPile") ) { return ::hx::Val( cutoffSubtractPile_dyn() ); }
		break;
	case 19:
		if (HX_FIELD_EQ(inName,"toLeftAlignedString") ) { return ::hx::Val( toLeftAlignedString_dyn() ); }
		break;
	case 23:
		if (HX_FIELD_EQ(inName,"toResourceAlignedString") ) { return ::hx::Val( toResourceAlignedString_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val Pile_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 9:
		if (HX_FIELD_EQ(inName,"resources") ) { resources=inValue.Cast<  ::haxe::ds::EnumValueMap >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Pile_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("resources",e5,d7,b0,39));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo Pile_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::haxe::ds::EnumValueMap */ ,(int)offsetof(Pile_obj,resources),HX_("resources",e5,d7,b0,39)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *Pile_obj_sStaticStorageInfo = 0;
#endif

static ::String Pile_obj_sMemberFields[] = {
	HX_("resources",e5,d7,b0,39),
	HX_("toString",ac,d0,6e,38),
	HX_("toLeftAlignedString",d3,39,0b,b1),
	HX_("toResourceAlignedString",2c,1b,f3,9e),
	HX_("get",96,80,4e,00),
	HX_("hasPile",2c,11,9c,19),
	HX_("add",21,f2,49,00),
	HX_("cutoffAdd",f4,38,3d,ef),
	HX_("subtract",14,75,11,f8),
	HX_("cutoffSubtract",61,91,cd,50),
	HX_("addPile",73,33,95,86),
	HX_("cutoffAddPile",c6,df,2f,f5),
	HX_("subtractPile",e6,ab,a4,6f),
	HX_("cutoffSubtractPile",b3,72,79,64),
	HX_("multiplyAndRound",3b,24,7d,af),
	::String(null()) };

::hx::Class Pile_obj::__mClass;

void Pile_obj::__register()
{
	Pile_obj _hx_dummy;
	Pile_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Pile",d2,1c,31,35);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(Pile_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< Pile_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Pile_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Pile_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

