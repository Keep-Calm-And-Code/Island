#include <hxcpp.h>

#ifndef INCLUDED_Point2D
#include <Point2D.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_fa19d541445307bf_426_new,"Point2D","new",0xda0985f4,"Point2D.new","Grid.hx",426,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_fa19d541445307bf_431_toString,"Point2D","toString",0xd3ba6298,"Point2D.toString","Grid.hx",431,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_fa19d541445307bf_435_coordsToString,"Point2D","coordsToString",0x01cb49d6,"Point2D.coordsToString","Grid.hx",435,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_fa19d541445307bf_438_isPoint,"Point2D","isPoint",0x7997679a,"Point2D.isPoint","Grid.hx",438,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_fa19d541445307bf_446_xFromString,"Point2D","xFromString",0x6ceae207,"Point2D.xFromString","Grid.hx",446,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_fa19d541445307bf_449_yFromString,"Point2D","yFromString",0xedc94d48,"Point2D.yFromString","Grid.hx",449,0xd4729398)
HX_LOCAL_STACK_FRAME(_hx_pos_fa19d541445307bf_459_pointFromString,"Point2D","pointFromString",0xa4992ddf,"Point2D.pointFromString","Grid.hx",459,0xd4729398)

void Point2D_obj::__construct(int newx,int newy){
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_426_new)
HXLINE( 427)		this->x = newx;
HXDLIN( 427)		this->y = newy;
            	}

Dynamic Point2D_obj::__CreateEmpty() { return new Point2D_obj; }

void *Point2D_obj::_hx_vtable = 0;

Dynamic Point2D_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Point2D_obj > _hx_result = new Point2D_obj();
	_hx_result->__construct(inArgs[0],inArgs[1]);
	return _hx_result;
}

bool Point2D_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x18c0077a;
}

::String Point2D_obj::toString(){
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_431_toString)
HXDLIN( 431)		return (((HX_("",00,00,00,00) + this->x) + HX_(", ",74,26,00,00)) + this->y);
            	}


HX_DEFINE_DYNAMIC_FUNC0(Point2D_obj,toString,return )

::String Point2D_obj::coordsToString(int x,int y){
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_435_coordsToString)
HXDLIN( 435)		return (((HX_("",00,00,00,00) + x) + HX_(", ",74,26,00,00)) + y);
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Point2D_obj,coordsToString,return )

bool Point2D_obj::isPoint(::String str){
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_438_isPoint)
HXLINE( 439)		bool _hx_tmp;
HXDLIN( 439)		if (::hx::IsNotNull( ::Point2D_obj::xFromString(str) )) {
HXLINE( 439)			_hx_tmp = ::hx::IsNull( ::Point2D_obj::yFromString(str) );
            		}
            		else {
HXLINE( 439)			_hx_tmp = true;
            		}
HXDLIN( 439)		if (_hx_tmp) {
HXLINE( 439)			return false;
            		}
HXLINE( 441)		return true;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Point2D_obj,isPoint,return )

 ::Dynamic Point2D_obj::xFromString(::String str){
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_446_xFromString)
HXDLIN( 446)		return ::Std_obj::parseInt(str);
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Point2D_obj,xFromString,return )

 ::Dynamic Point2D_obj::yFromString(::String str){
            	HX_STACKFRAME(&_hx_pos_fa19d541445307bf_449_yFromString)
HXLINE( 450)		::Array< ::String > coords = str.split(HX_(",",2c,00,00,00));
HXLINE( 451)		if ((coords->length >= 2)) {
HXLINE( 452)			return ::Std_obj::parseInt(coords->__get(1));
            		}
            		else {
HXLINE( 455)			return null();
            		}
HXLINE( 451)		return 0;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Point2D_obj,yFromString,return )

 ::Point2D Point2D_obj::pointFromString(::String str){
            	HX_GC_STACKFRAME(&_hx_pos_fa19d541445307bf_459_pointFromString)
HXLINE( 460)		 ::Dynamic x = ::Point2D_obj::xFromString(str);
HXLINE( 461)		 ::Dynamic y = ::Point2D_obj::yFromString(str);
HXLINE( 463)		bool _hx_tmp;
HXDLIN( 463)		if (::hx::IsNotNull( x )) {
HXLINE( 463)			_hx_tmp = ::hx::IsNotNull( y );
            		}
            		else {
HXLINE( 463)			_hx_tmp = false;
            		}
HXDLIN( 463)		if (_hx_tmp) {
HXLINE( 463)			return  ::Point2D_obj::__alloc( HX_CTX ,( (int)(x) ),( (int)(y) ));
            		}
            		else {
HXLINE( 464)			return null();
            		}
HXLINE( 463)		return null();
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Point2D_obj,pointFromString,return )


Point2D_obj::Point2D_obj()
{
}

::hx::Val Point2D_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"x") ) { return ::hx::Val( x ); }
		if (HX_FIELD_EQ(inName,"y") ) { return ::hx::Val( y ); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"toString") ) { return ::hx::Val( toString_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

bool Point2D_obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 7:
		if (HX_FIELD_EQ(inName,"isPoint") ) { outValue = isPoint_dyn(); return true; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"xFromString") ) { outValue = xFromString_dyn(); return true; }
		if (HX_FIELD_EQ(inName,"yFromString") ) { outValue = yFromString_dyn(); return true; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"coordsToString") ) { outValue = coordsToString_dyn(); return true; }
		break;
	case 15:
		if (HX_FIELD_EQ(inName,"pointFromString") ) { outValue = pointFromString_dyn(); return true; }
	}
	return false;
}

::hx::Val Point2D_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 1:
		if (HX_FIELD_EQ(inName,"x") ) { x=inValue.Cast< int >(); return inValue; }
		if (HX_FIELD_EQ(inName,"y") ) { y=inValue.Cast< int >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void Point2D_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("x",78,00,00,00));
	outFields->push(HX_("y",79,00,00,00));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo Point2D_obj_sMemberStorageInfo[] = {
	{::hx::fsInt,(int)offsetof(Point2D_obj,x),HX_("x",78,00,00,00)},
	{::hx::fsInt,(int)offsetof(Point2D_obj,y),HX_("y",79,00,00,00)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *Point2D_obj_sStaticStorageInfo = 0;
#endif

static ::String Point2D_obj_sMemberFields[] = {
	HX_("x",78,00,00,00),
	HX_("y",79,00,00,00),
	HX_("toString",ac,d0,6e,38),
	::String(null()) };

::hx::Class Point2D_obj::__mClass;

static ::String Point2D_obj_sStaticFields[] = {
	HX_("coordsToString",ea,7e,33,5e),
	HX_("isPoint",06,58,15,63),
	HX_("xFromString",73,78,67,b3),
	HX_("yFromString",b4,e3,45,34),
	HX_("pointFromString",4b,6a,5f,23),
	::String(null())
};

void Point2D_obj::__register()
{
	Point2D_obj _hx_dummy;
	Point2D_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Point2D",02,bc,72,1e);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Point2D_obj::__GetStatic;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Point2D_obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(Point2D_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< Point2D_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Point2D_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Point2D_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

