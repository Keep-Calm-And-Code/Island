#include <hxcpp.h>

#ifndef INCLUDED_Resource
#include <Resource.h>
#endif

::Resource Resource_obj::Fish;

::Resource Resource_obj::Goods;

::Resource Resource_obj::Grain;

::Resource Resource_obj::Metal;

::Resource Resource_obj::Tools;

::Resource Resource_obj::Wood;

bool Resource_obj::__GetStatic(const ::String &inName, ::Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Fish",b8,00,95,2e)) { outValue = Resource_obj::Fish; return true; }
	if (inName==HX_("Goods",76,70,26,2b)) { outValue = Resource_obj::Goods; return true; }
	if (inName==HX_("Grain",1b,79,17,2d)) { outValue = Resource_obj::Grain; return true; }
	if (inName==HX_("Metal",e7,91,f5,98)) { outValue = Resource_obj::Metal; return true; }
	if (inName==HX_("Tools",fb,01,5c,a7)) { outValue = Resource_obj::Tools; return true; }
	if (inName==HX_("Wood",4d,2b,d6,39)) { outValue = Resource_obj::Wood; return true; }
	return super::__GetStatic(inName, outValue, inCallProp);
}

HX_DEFINE_CREATE_ENUM(Resource_obj)

int Resource_obj::__FindIndex(::String inName)
{
	if (inName==HX_("Fish",b8,00,95,2e)) return 1;
	if (inName==HX_("Goods",76,70,26,2b)) return 5;
	if (inName==HX_("Grain",1b,79,17,2d)) return 0;
	if (inName==HX_("Metal",e7,91,f5,98)) return 3;
	if (inName==HX_("Tools",fb,01,5c,a7)) return 4;
	if (inName==HX_("Wood",4d,2b,d6,39)) return 2;
	return super::__FindIndex(inName);
}

int Resource_obj::__FindArgCount(::String inName)
{
	if (inName==HX_("Fish",b8,00,95,2e)) return 0;
	if (inName==HX_("Goods",76,70,26,2b)) return 0;
	if (inName==HX_("Grain",1b,79,17,2d)) return 0;
	if (inName==HX_("Metal",e7,91,f5,98)) return 0;
	if (inName==HX_("Tools",fb,01,5c,a7)) return 0;
	if (inName==HX_("Wood",4d,2b,d6,39)) return 0;
	return super::__FindArgCount(inName);
}

::hx::Val Resource_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Fish",b8,00,95,2e)) return Fish;
	if (inName==HX_("Goods",76,70,26,2b)) return Goods;
	if (inName==HX_("Grain",1b,79,17,2d)) return Grain;
	if (inName==HX_("Metal",e7,91,f5,98)) return Metal;
	if (inName==HX_("Tools",fb,01,5c,a7)) return Tools;
	if (inName==HX_("Wood",4d,2b,d6,39)) return Wood;
	return super::__Field(inName,inCallProp);
}

static ::String Resource_obj_sStaticFields[] = {
	HX_("Grain",1b,79,17,2d),
	HX_("Fish",b8,00,95,2e),
	HX_("Wood",4d,2b,d6,39),
	HX_("Metal",e7,91,f5,98),
	HX_("Tools",fb,01,5c,a7),
	HX_("Goods",76,70,26,2b),
	::String(null())
};

::hx::Class Resource_obj::__mClass;

Dynamic __Create_Resource_obj() { return new Resource_obj; }

void Resource_obj::__register()
{

::hx::Static(__mClass) = ::hx::_hx_RegisterClass(HX_("Resource",ee,18,52,ec), ::hx::TCanCast< Resource_obj >,Resource_obj_sStaticFields,0,
	&__Create_Resource_obj, &__Create,
	&super::__SGetClass(), &CreateResource_obj, 0
#ifdef HXCPP_VISIT_ALLOCS
    , 0
#endif
#ifdef HXCPP_SCRIPTABLE
    , 0
#endif
);
	__mClass->mGetStaticField = &Resource_obj::__GetStatic;
}

void Resource_obj::__boot()
{
Fish = ::hx::CreateConstEnum< Resource_obj >(HX_("Fish",b8,00,95,2e),1);
Goods = ::hx::CreateConstEnum< Resource_obj >(HX_("Goods",76,70,26,2b),5);
Grain = ::hx::CreateConstEnum< Resource_obj >(HX_("Grain",1b,79,17,2d),0);
Metal = ::hx::CreateConstEnum< Resource_obj >(HX_("Metal",e7,91,f5,98),3);
Tools = ::hx::CreateConstEnum< Resource_obj >(HX_("Tools",fb,01,5c,a7),4);
Wood = ::hx::CreateConstEnum< Resource_obj >(HX_("Wood",4d,2b,d6,39),2);
}


