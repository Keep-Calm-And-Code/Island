#include <hxcpp.h>

#ifndef INCLUDED_Terrain
#include <Terrain.h>
#endif

::Terrain Terrain_obj::Forest;

::Terrain Terrain_obj::Grass;

::Terrain Terrain_obj::Hills;

bool Terrain_obj::__GetStatic(const ::String &inName, ::Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Forest",fd,00,1d,32)) { outValue = Terrain_obj::Forest; return true; }
	if (inName==HX_("Grass",d6,81,17,2d)) { outValue = Terrain_obj::Grass; return true; }
	if (inName==HX_("Hills",72,7d,93,ba)) { outValue = Terrain_obj::Hills; return true; }
	return super::__GetStatic(inName, outValue, inCallProp);
}

HX_DEFINE_CREATE_ENUM(Terrain_obj)

int Terrain_obj::__FindIndex(::String inName)
{
	if (inName==HX_("Forest",fd,00,1d,32)) return 1;
	if (inName==HX_("Grass",d6,81,17,2d)) return 0;
	if (inName==HX_("Hills",72,7d,93,ba)) return 2;
	return super::__FindIndex(inName);
}

int Terrain_obj::__FindArgCount(::String inName)
{
	if (inName==HX_("Forest",fd,00,1d,32)) return 0;
	if (inName==HX_("Grass",d6,81,17,2d)) return 0;
	if (inName==HX_("Hills",72,7d,93,ba)) return 0;
	return super::__FindArgCount(inName);
}

::hx::Val Terrain_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	if (inName==HX_("Forest",fd,00,1d,32)) return Forest;
	if (inName==HX_("Grass",d6,81,17,2d)) return Grass;
	if (inName==HX_("Hills",72,7d,93,ba)) return Hills;
	return super::__Field(inName,inCallProp);
}

static ::String Terrain_obj_sStaticFields[] = {
	HX_("Grass",d6,81,17,2d),
	HX_("Forest",fd,00,1d,32),
	HX_("Hills",72,7d,93,ba),
	::String(null())
};

::hx::Class Terrain_obj::__mClass;

Dynamic __Create_Terrain_obj() { return new Terrain_obj; }

void Terrain_obj::__register()
{

::hx::Static(__mClass) = ::hx::_hx_RegisterClass(HX_("Terrain",95,d3,68,f6), ::hx::TCanCast< Terrain_obj >,Terrain_obj_sStaticFields,0,
	&__Create_Terrain_obj, &__Create,
	&super::__SGetClass(), &CreateTerrain_obj, 0
#ifdef HXCPP_VISIT_ALLOCS
    , 0
#endif
#ifdef HXCPP_SCRIPTABLE
    , 0
#endif
);
	__mClass->mGetStaticField = &Terrain_obj::__GetStatic;
}

void Terrain_obj::__boot()
{
Forest = ::hx::CreateConstEnum< Terrain_obj >(HX_("Forest",fd,00,1d,32),1);
Grass = ::hx::CreateConstEnum< Terrain_obj >(HX_("Grass",d6,81,17,2d),0);
Hills = ::hx::CreateConstEnum< Terrain_obj >(HX_("Hills",72,7d,93,ba),2);
}


