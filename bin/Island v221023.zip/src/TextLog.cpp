#include <hxcpp.h>

#ifndef INCLUDED_TextLog
#include <TextLog.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif
#ifndef INCLUDED_haxe_Exception
#include <haxe/Exception.h>
#endif
#ifndef INCLUDED_haxe_ds_List
#include <haxe/ds/List.h>
#endif
#ifndef INCLUDED_haxe_ds__List_ListNode
#include <haxe/ds/_List/ListNode.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_a7ff0b1dc3aff463_321_new,"TextLog","new",0x195f1a29,"TextLog.new","TextScreen.hx",321,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_a7ff0b1dc3aff463_329_log,"TextLog","log",0x195d9e4d,"TextLog.log","TextScreen.hx",329,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_a7ff0b1dc3aff463_336_render,"TextLog","render",0xaa6da52d,"TextLog.render","TextScreen.hx",336,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_a7ff0b1dc3aff463_348_clear,"TextLog","clear",0x32237f96,"TextLog.clear","TextScreen.hx",348,0x3762d845)

void TextLog_obj::__construct(::hx::Null< int >  __o_rows,::hx::Null< int >  __o_columns,::hx::Null< int >  __o_length){
            		int rows = __o_rows.Default(24);
            		int columns = __o_columns.Default(80);
            		int length = __o_length.Default(10);
            	HX_GC_STACKFRAME(&_hx_pos_a7ff0b1dc3aff463_321_new)
HXLINE( 322)		if ((length < 1)) {
HXLINE( 322)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("length must be a positive integer",d6,31,74,82)));
            		}
HXLINE( 323)		this->maxLength = length;
HXLINE( 324)		this->stringBuffer =  ::haxe::ds::List_obj::__alloc( HX_CTX );
HXLINE( 326)		super::__construct(rows,columns,null());
            	}

Dynamic TextLog_obj::__CreateEmpty() { return new TextLog_obj; }

void *TextLog_obj::_hx_vtable = 0;

Dynamic TextLog_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< TextLog_obj > _hx_result = new TextLog_obj();
	_hx_result->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return _hx_result;
}

bool TextLog_obj::_hx_isInstanceOf(int inClassId) {
	if (inClassId<=(int)0x16534825) {
		if (inClassId<=(int)0x0b23efa1) {
			return inClassId==(int)0x00000001 || inClassId==(int)0x0b23efa1;
		} else {
			return inClassId==(int)0x16534825;
		}
	} else {
		return inClassId==(int)0x2c3276f7;
	}
}

void TextLog_obj::log(::String string){
            	HX_STACKFRAME(&_hx_pos_a7ff0b1dc3aff463_329_log)
HXLINE( 330)		this->stringBuffer->add(string);
HXLINE( 331)		bool _hx_tmp;
HXDLIN( 331)		if ((this->maxLength != 0)) {
HXLINE( 331)			_hx_tmp = (this->stringBuffer->length > this->maxLength);
            		}
            		else {
HXLINE( 331)			_hx_tmp = false;
            		}
HXDLIN( 331)		if (_hx_tmp) {
HXLINE( 332)			this->stringBuffer->pop();
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC1(TextLog_obj,log,(void))

void TextLog_obj::render(){
            	HX_STACKFRAME(&_hx_pos_a7ff0b1dc3aff463_336_render)
HXLINE( 337)		int firstLineToRender = ::Utils_obj::maxInt((this->stringBuffer->length - this->rows),0);
HXLINE( 338)		int currentRow = 0;
HXLINE( 339)		{
HXLINE( 339)			 ::haxe::ds::_List::ListNode _g_head = this->stringBuffer->h;
HXDLIN( 339)			while(::hx::IsNotNull( _g_head )){
HXLINE( 339)				::String val = ( (::String)(_g_head->item) );
HXDLIN( 339)				_g_head = _g_head->next;
HXDLIN( 339)				::String line = val;
HXLINE( 340)				if ((currentRow >= firstLineToRender)) {
HXLINE( 341)					this->write(line,null(),currentRow,null());
            				}
HXLINE( 343)				currentRow = (currentRow + 1);
            			}
            		}
HXLINE( 345)		this->super::render();
            	}


void TextLog_obj::clear(::String fill){
            	HX_STACKFRAME(&_hx_pos_a7ff0b1dc3aff463_348_clear)
HXLINE( 349)		this->stringBuffer->clear();
HXLINE( 350)		this->super::clear(null());
            	}



::hx::ObjectPtr< TextLog_obj > TextLog_obj::__new(::hx::Null< int >  __o_rows,::hx::Null< int >  __o_columns,::hx::Null< int >  __o_length) {
	::hx::ObjectPtr< TextLog_obj > __this = new TextLog_obj();
	__this->__construct(__o_rows,__o_columns,__o_length);
	return __this;
}

::hx::ObjectPtr< TextLog_obj > TextLog_obj::__alloc(::hx::Ctx *_hx_ctx,::hx::Null< int >  __o_rows,::hx::Null< int >  __o_columns,::hx::Null< int >  __o_length) {
	TextLog_obj *__this = (TextLog_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(TextLog_obj), true, "TextLog"));
	*(void **)__this = TextLog_obj::_hx_vtable;
	__this->__construct(__o_rows,__o_columns,__o_length);
	return __this;
}

TextLog_obj::TextLog_obj()
{
}

void TextLog_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TextLog);
	HX_MARK_MEMBER_NAME(stringBuffer,"stringBuffer");
	HX_MARK_MEMBER_NAME(maxLength,"maxLength");
	 ::TextWindow_obj::__Mark(HX_MARK_ARG);
	HX_MARK_END_CLASS();
}

void TextLog_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(stringBuffer,"stringBuffer");
	HX_VISIT_MEMBER_NAME(maxLength,"maxLength");
	 ::TextWindow_obj::__Visit(HX_VISIT_ARG);
}

::hx::Val TextLog_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"log") ) { return ::hx::Val( log_dyn() ); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"clear") ) { return ::hx::Val( clear_dyn() ); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"render") ) { return ::hx::Val( render_dyn() ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"maxLength") ) { return ::hx::Val( maxLength ); }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"stringBuffer") ) { return ::hx::Val( stringBuffer ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val TextLog_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 9:
		if (HX_FIELD_EQ(inName,"maxLength") ) { maxLength=inValue.Cast< int >(); return inValue; }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"stringBuffer") ) { stringBuffer=inValue.Cast<  ::haxe::ds::List >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void TextLog_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("stringBuffer",b1,4c,ed,67));
	outFields->push(HX_("maxLength",aa,a6,92,ce));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo TextLog_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::haxe::ds::List */ ,(int)offsetof(TextLog_obj,stringBuffer),HX_("stringBuffer",b1,4c,ed,67)},
	{::hx::fsInt,(int)offsetof(TextLog_obj,maxLength),HX_("maxLength",aa,a6,92,ce)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *TextLog_obj_sStaticStorageInfo = 0;
#endif

static ::String TextLog_obj_sMemberFields[] = {
	HX_("stringBuffer",b1,4c,ed,67),
	HX_("maxLength",aa,a6,92,ce),
	HX_("log",84,54,52,00),
	HX_("render",56,6b,29,05),
	HX_("clear",8d,71,5b,48),
	::String(null()) };

::hx::Class TextLog_obj::__mClass;

void TextLog_obj::__register()
{
	TextLog_obj _hx_dummy;
	TextLog_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("TextLog",b7,d1,12,6c);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(TextLog_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< TextLog_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = TextLog_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = TextLog_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

