#include <hxcpp.h>

#ifndef INCLUDED_MenuOption
#include <MenuOption.h>
#endif
#ifndef INCLUDED_TextMenu
#include <TextMenu.h>
#endif
#ifndef INCLUDED_TextMenuType
#include <TextMenuType.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_d37172d54d65225f_363_new,"TextMenu","new",0x36df6bfe,"TextMenu.new","TextScreen.hx",363,0x3762d845)

void TextMenu_obj::__construct(){
            	HX_STACKFRAME(&_hx_pos_d37172d54d65225f_363_new)
HXDLIN( 363)		super::__construct(null(),null(),null());
            	}

Dynamic TextMenu_obj::__CreateEmpty() { return new TextMenu_obj; }

void *TextMenu_obj::_hx_vtable = 0;

Dynamic TextMenu_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< TextMenu_obj > _hx_result = new TextMenu_obj();
	_hx_result->__construct();
	return _hx_result;
}

bool TextMenu_obj::_hx_isInstanceOf(int inClassId) {
	if (inClassId<=(int)0x16534825) {
		if (inClassId<=(int)0x0b23efa1) {
			return inClassId==(int)0x00000001 || inClassId==(int)0x0b23efa1;
		} else {
			return inClassId==(int)0x16534825;
		}
	} else {
		return inClassId==(int)0x2e5b1294;
	}
}


::hx::ObjectPtr< TextMenu_obj > TextMenu_obj::__new() {
	::hx::ObjectPtr< TextMenu_obj > __this = new TextMenu_obj();
	__this->__construct();
	return __this;
}

::hx::ObjectPtr< TextMenu_obj > TextMenu_obj::__alloc(::hx::Ctx *_hx_ctx) {
	TextMenu_obj *__this = (TextMenu_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(TextMenu_obj), true, "TextMenu"));
	*(void **)__this = TextMenu_obj::_hx_vtable;
	__this->__construct();
	return __this;
}

TextMenu_obj::TextMenu_obj()
{
}

void TextMenu_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TextMenu);
	HX_MARK_MEMBER_NAME(orientation,"orientation");
	HX_MARK_MEMBER_NAME(menuOptions,"menuOptions");
	 ::TextWindow_obj::__Mark(HX_MARK_ARG);
	HX_MARK_END_CLASS();
}

void TextMenu_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(orientation,"orientation");
	HX_VISIT_MEMBER_NAME(menuOptions,"menuOptions");
	 ::TextWindow_obj::__Visit(HX_VISIT_ARG);
}

::hx::Val TextMenu_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 11:
		if (HX_FIELD_EQ(inName,"orientation") ) { return ::hx::Val( orientation ); }
		if (HX_FIELD_EQ(inName,"menuOptions") ) { return ::hx::Val( menuOptions ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val TextMenu_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 11:
		if (HX_FIELD_EQ(inName,"orientation") ) { orientation=inValue.Cast<  ::TextMenuType >(); return inValue; }
		if (HX_FIELD_EQ(inName,"menuOptions") ) { menuOptions=inValue.Cast< ::Array< ::Dynamic> >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void TextMenu_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("orientation",d0,ee,fe,fd));
	outFields->push(HX_("menuOptions",7f,97,2d,31));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo TextMenu_obj_sMemberStorageInfo[] = {
	{::hx::fsObject /*  ::TextMenuType */ ,(int)offsetof(TextMenu_obj,orientation),HX_("orientation",d0,ee,fe,fd)},
	{::hx::fsObject /* ::Array< ::Dynamic> */ ,(int)offsetof(TextMenu_obj,menuOptions),HX_("menuOptions",7f,97,2d,31)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *TextMenu_obj_sStaticStorageInfo = 0;
#endif

static ::String TextMenu_obj_sMemberFields[] = {
	HX_("orientation",d0,ee,fe,fd),
	HX_("menuOptions",7f,97,2d,31),
	::String(null()) };

::hx::Class TextMenu_obj::__mClass;

void TextMenu_obj::__register()
{
	TextMenu_obj _hx_dummy;
	TextMenu_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("TextMenu",0c,55,06,25);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(TextMenu_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< TextMenu_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = TextMenu_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = TextMenu_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

