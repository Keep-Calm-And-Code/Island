#include <hxcpp.h>

#ifndef INCLUDED_TextMenuType
#include <TextMenuType.h>
#endif


void TextMenuType_obj::__construct() { }

Dynamic TextMenuType_obj::__CreateEmpty() { return new TextMenuType_obj; }

void *TextMenuType_obj::_hx_vtable = 0;

Dynamic TextMenuType_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< TextMenuType_obj > _hx_result = new TextMenuType_obj();
	_hx_result->__construct();
	return _hx_result;
}

bool TextMenuType_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x38e73ca6;
}


TextMenuType_obj::TextMenuType_obj()
{
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *TextMenuType_obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo *TextMenuType_obj_sStaticStorageInfo = 0;
#endif

::hx::Class TextMenuType_obj::__mClass;

void TextMenuType_obj::__register()
{
	TextMenuType_obj _hx_dummy;
	TextMenuType_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("TextMenuType",e6,e9,05,50);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< TextMenuType_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = TextMenuType_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = TextMenuType_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

