#include <hxcpp.h>

#ifndef INCLUDED_95f339a1d026d52c
#define INCLUDED_95f339a1d026d52c
#include "hxMath.h"
#endif
#ifndef INCLUDED_ChildWindowInfo
#include <ChildWindowInfo.h>
#endif
#ifndef INCLUDED_ColoredChar
#include <ColoredChar.h>
#endif
#ifndef INCLUDED_Sys
#include <Sys.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif
#ifndef INCLUDED_haxe_Exception
#include <haxe/Exception.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_76_new,"TextScreen","new",0x3f1ee18b,"TextScreen.new","TextScreen.hx",76,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_104_write,"TextScreen","write",0xa4eb5eca,"TextScreen.write","TextScreen.hx",104,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_119_writeLeft,"TextScreen","writeLeft",0x226cbff1,"TextScreen.writeLeft","TextScreen.hx",119,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_125_clear,"TextScreen","clear",0x1ced6378,"TextScreen.clear","TextScreen.hx",125,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_139_addChild,"TextScreen","addChild",0x42e6a2b0,"TextScreen.addChild","TextScreen.hx",139,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_148_removeChild,"TextScreen","removeChild",0x3c3e3ae3,"TextScreen.removeChild","TextScreen.hx",148,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_155_findChild,"TextScreen","findChild",0x06b99e0e,"TextScreen.findChild","TextScreen.hx",155,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_165_render,"TextScreen","render",0x304b270b,"TextScreen.render","TextScreen.hx",165,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_188_display,"TextScreen","display",0x4dacaced,"TextScreen.display","TextScreen.hx",188,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_191_displayColour,"TextScreen","displayColour",0xbcefd919,"TextScreen.displayColour","TextScreen.hx",191,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_207_displayMonochrome,"TextScreen","displayMonochrome",0x05e30d2a,"TextScreen.displayMonochrome","TextScreen.hx",207,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_222_pad,"TextScreen","pad",0x3f20627e,"TextScreen.pad","TextScreen.hx",222,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_225_padRight,"TextScreen","padRight",0xc3c5507e,"TextScreen.padRight","TextScreen.hx",225,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_fb46f54d0b1f8f19_238_padLeft,"TextScreen","padLeft",0x52ffada5,"TextScreen.padLeft","TextScreen.hx",238,0x3762d845)

void TextScreen_obj::__construct( ::Dynamic __o_rows, ::Dynamic __o_columns){
            		 ::Dynamic rows = __o_rows;
            		if (::hx::IsNull(__o_rows)) rows = 24;
            		 ::Dynamic columns = __o_columns;
            		if (::hx::IsNull(__o_columns)) columns = 80;
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_76_new)
HXLINE(  79)		this->defaultTextColor = HX_("\x1b""[0;37m",3e,ae,9f,8f);
HXLINE(  78)		this->defaultChar = HX_(" ",20,00,00,00);
HXLINE(  88)		if (::hx::IsLess( rows,1 )) {
HXLINE(  88)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("rows must be a positive integer",83,92,fc,3a)));
            		}
HXLINE(  89)		if (::hx::IsLess( columns,1 )) {
HXLINE(  89)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("columns must be a positive integer",3f,61,99,99)));
            		}
HXLINE(  90)		this->rows = ( (int)(rows) );
HXLINE(  91)		this->columns = ( (int)(columns) );
HXLINE(  93)		::Array< ::Dynamic> this1 = ::Array_obj< ::Dynamic>::__new(( (int)(rows) ));
HXDLIN(  93)		this->displayBuffer = this1;
HXLINE(  94)		{
HXLINE(  94)			int _g = 0;
HXDLIN(  94)			 ::Dynamic _g1 = rows;
HXDLIN(  94)			while(::hx::IsLess( _g,_g1 )){
HXLINE(  94)				_g = (_g + 1);
HXDLIN(  94)				int i = (_g - 1);
HXLINE(  95)				{
HXLINE(  95)					::Array< ::Dynamic> this1 = this->displayBuffer;
HXDLIN(  95)					::Array< ::Dynamic> this2 = ::Array_obj< ::Dynamic>::__new(( (int)(columns) ));
HXDLIN(  95)					this1->__unsafe_set(i,this2);
            				}
            			}
            		}
HXLINE(  98)		this->childWindowInfoList = ::Array_obj< ::Dynamic>::__new();
HXLINE( 100)		this->clear(null());
            	}

Dynamic TextScreen_obj::__CreateEmpty() { return new TextScreen_obj; }

void *TextScreen_obj::_hx_vtable = 0;

Dynamic TextScreen_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< TextScreen_obj > _hx_result = new TextScreen_obj();
	_hx_result->__construct(inArgs[0],inArgs[1]);
	return _hx_result;
}

bool TextScreen_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x0b23efa1;
}

void TextScreen_obj::write(::String text,::String color, ::Dynamic __o_row, ::Dynamic __o_column){
            		 ::Dynamic row = __o_row;
            		if (::hx::IsNull(__o_row)) row = 0;
            		 ::Dynamic column = __o_column;
            		if (::hx::IsNull(__o_column)) column = 0;
            	HX_GC_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_104_write)
HXLINE( 106)		bool _hx_tmp;
HXDLIN( 106)		if (::hx::IsGreaterEq( row,0 )) {
HXLINE( 106)			int a = ( (int)(row) );
HXDLIN( 106)			int b = this->rows;
HXDLIN( 106)			bool aNeg = (a < 0);
HXDLIN( 106)			bool bNeg = (b < 0);
HXDLIN( 106)			if ((aNeg != bNeg)) {
HXLINE( 106)				_hx_tmp = aNeg;
            			}
            			else {
HXLINE( 106)				_hx_tmp = (a >= b);
            			}
            		}
            		else {
HXLINE( 106)			_hx_tmp = true;
            		}
HXDLIN( 106)		if (_hx_tmp) {
HXLINE( 106)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("row outside of range",15,a5,3b,4d)));
            		}
HXLINE( 107)		if (::hx::IsLess( column,0 )) {
HXLINE( 108)			int writeFrom = ::Utils_obj::minInt(text.length,-(column),null());
HXLINE( 109)			text = text.substr(writeFrom,null());
HXLINE( 110)			column = 0;
            		}
HXLINE( 113)		if (::hx::IsNull( color )) {
HXLINE( 113)			color = this->defaultTextColor;
            		}
HXLINE( 114)		{
HXLINE( 114)			int _g = 0;
HXDLIN( 114)			int _hx_int = (this->columns - ( (int)(column) ));
HXDLIN( 114)			Float _g1;
HXDLIN( 114)			if ((_hx_int < 0)) {
HXLINE( 114)				_g1 = (((Float)4294967296.0) + _hx_int);
            			}
            			else {
HXLINE( 114)				_g1 = (_hx_int + ((Float)0.0));
            			}
HXDLIN( 114)			int _g2 = ::Math_obj::round(::Math_obj::min(( (Float)(text.length) ),_g1));
HXDLIN( 114)			while((_g < _g2)){
HXLINE( 114)				_g = (_g + 1);
HXDLIN( 114)				int i = (_g - 1);
HXLINE( 115)				{
HXLINE( 115)					::Array< ::Dynamic> this1 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,( (int)(row) ))) );
HXDLIN( 115)					 ::ColoredChar val =  ::ColoredChar_obj::__alloc( HX_CTX ,text.charAt(i),color);
HXDLIN( 115)					this1->__unsafe_set((column + i),val);
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC4(TextScreen_obj,write,(void))

void TextScreen_obj::writeLeft(::String text,::String color, ::Dynamic __o_rows, ::Dynamic column){
            		 ::Dynamic rows = __o_rows;
            		if (::hx::IsNull(__o_rows)) rows = 0;
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_119_writeLeft)
HXLINE( 120)		if (::hx::IsNull( column )) {
HXLINE( 120)			column = (this->columns - 1);
            		}
HXLINE( 121)		this->write(text,color,rows,((( (int)(column) ) - text.length) + 1));
            	}


HX_DEFINE_DYNAMIC_FUNC4(TextScreen_obj,writeLeft,(void))

void TextScreen_obj::clear(::String fill){
            	HX_GC_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_125_clear)
HXLINE( 126)		if (::hx::IsNull( fill )) {
HXLINE( 126)			fill = this->defaultChar;
            		}
HXLINE( 127)		fill = fill.charAt(0);
HXLINE( 129)		{
HXLINE( 129)			int _g = 0;
HXDLIN( 129)			int _g1 = this->rows;
HXDLIN( 129)			while((_g < _g1)){
HXLINE( 129)				_g = (_g + 1);
HXDLIN( 129)				int i = (_g - 1);
HXLINE( 130)				{
HXLINE( 130)					int _g1 = 0;
HXDLIN( 130)					int _g2 = this->columns;
HXDLIN( 130)					while((_g1 < _g2)){
HXLINE( 130)						_g1 = (_g1 + 1);
HXDLIN( 130)						int j = (_g1 - 1);
HXLINE( 131)						{
HXLINE( 131)							::Array< ::Dynamic> this1 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,i)) );
HXDLIN( 131)							 ::ColoredChar val =  ::ColoredChar_obj::__alloc( HX_CTX ,fill,this->defaultTextColor);
HXDLIN( 131)							this1->__unsafe_set(j,val);
            						}
            					}
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC1(TextScreen_obj,clear,(void))

void TextScreen_obj::addChild( ::TextWindow child,::hx::Null< int >  __o_parentFirstRow,::hx::Null< int >  __o_parentFirstCol,::hx::Null< int >  __o_displayFirstRow,::hx::Null< int >  __o_displayFirstCol, ::Dynamic displayRows, ::Dynamic displayCols,::hx::Null< bool >  __o_isVisible){
            		int parentFirstRow = __o_parentFirstRow.Default(0);
            		int parentFirstCol = __o_parentFirstCol.Default(0);
            		int displayFirstRow = __o_displayFirstRow.Default(0);
            		int displayFirstCol = __o_displayFirstCol.Default(0);
            		bool isVisible = __o_isVisible.Default(true);
            	HX_GC_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_139_addChild)
HXLINE( 140)		 ::ChildWindowInfo info =  ::ChildWindowInfo_obj::__alloc( HX_CTX ,child,parentFirstRow,parentFirstCol,displayFirstRow,displayFirstCol,displayRows,displayCols,isVisible);
HXLINE( 143)		this->childWindowInfoList->push(info);
            	}


HX_DEFINE_DYNAMIC_FUNC8(TextScreen_obj,addChild,(void))

void TextScreen_obj::removeChild(::String name){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_148_removeChild)
HXDLIN( 148)		int _g = 0;
HXDLIN( 148)		::Array< ::Dynamic> _g1 = this->childWindowInfoList;
HXDLIN( 148)		while((_g < _g1->length)){
HXDLIN( 148)			 ::ChildWindowInfo info = _g1->__get(_g).StaticCast<  ::ChildWindowInfo >();
HXDLIN( 148)			_g = (_g + 1);
HXLINE( 149)			if ((info->window->name == name)) {
HXLINE( 150)				this->childWindowInfoList->remove(info);
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC1(TextScreen_obj,removeChild,(void))

 ::ChildWindowInfo TextScreen_obj::findChild(::String name){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_155_findChild)
HXLINE( 156)		{
HXLINE( 156)			int _g = 0;
HXDLIN( 156)			::Array< ::Dynamic> _g1 = this->childWindowInfoList;
HXDLIN( 156)			while((_g < _g1->length)){
HXLINE( 156)				 ::ChildWindowInfo info = _g1->__get(_g).StaticCast<  ::ChildWindowInfo >();
HXDLIN( 156)				_g = (_g + 1);
HXLINE( 157)				if ((info->window->name == name)) {
HXLINE( 158)					return info;
            				}
            			}
            		}
HXLINE( 161)		return null();
            	}


HX_DEFINE_DYNAMIC_FUNC1(TextScreen_obj,findChild,return )

void TextScreen_obj::render(){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_165_render)
HXLINE( 168)		int rowsToRender;
HXLINE( 169)		int columnsToRender;
HXLINE( 172)		{
HXLINE( 172)			int _g = 0;
HXDLIN( 172)			::Array< ::Dynamic> _g1 = this->childWindowInfoList;
HXDLIN( 172)			while((_g < _g1->length)){
HXLINE( 172)				 ::ChildWindowInfo child = _g1->__get(_g).StaticCast<  ::ChildWindowInfo >();
HXDLIN( 172)				_g = (_g + 1);
HXLINE( 173)				child->window->render();
HXLINE( 174)				rowsToRender = ::Utils_obj::minInt((child->window->rows - child->displayFirstRow),child->displayRows,(this->rows - child->parentFirstRow));
HXLINE( 175)				columnsToRender = ::Utils_obj::minInt((child->window->columns - child->displayFirstColumn),child->displayColumns,(this->columns - child->parentFirstColumn));
HXLINE( 176)				{
HXLINE( 176)					int _g2 = 0;
HXDLIN( 176)					int _g3 = rowsToRender;
HXDLIN( 176)					while((_g2 < _g3)){
HXLINE( 176)						_g2 = (_g2 + 1);
HXDLIN( 176)						int row = (_g2 - 1);
HXLINE( 177)						{
HXLINE( 177)							int _g = 0;
HXDLIN( 177)							int _g1 = columnsToRender;
HXDLIN( 177)							while((_g < _g1)){
HXLINE( 177)								_g = (_g + 1);
HXDLIN( 177)								int col = (_g - 1);
HXLINE( 178)								{
HXLINE( 178)									::Array< ::Dynamic> this1 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,(child->parentFirstRow + row))) );
HXDLIN( 178)									int index = (child->parentFirstColumn + col);
HXDLIN( 178)									::Array< ::Dynamic> this2 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(child->window->displayBuffer,(child->displayFirstRow + row))) );
HXDLIN( 178)									 ::ColoredChar val = ( ( ::ColoredChar)(_hx_array_unsafe_get(this2,(child->displayFirstColumn + col))) );
HXDLIN( 178)									this1->__unsafe_set(index,val);
            								}
            							}
            						}
            					}
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(TextScreen_obj,render,(void))

void TextScreen_obj::display(){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_188_display)
HXDLIN( 188)		this->displayMonochrome();
            	}


HX_DEFINE_DYNAMIC_FUNC0(TextScreen_obj,display,(void))

void TextScreen_obj::displayColour(){
            	HX_GC_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_191_displayColour)
HXLINE( 192)		this->render();
HXLINE( 193)		 ::ColoredChar currentChar =  ::ColoredChar_obj::__alloc( HX_CTX ,null(),null());
HXLINE( 194)		::String currentLine = HX_("",00,00,00,00);
HXLINE( 196)		{
HXLINE( 196)			int _g = 0;
HXDLIN( 196)			int _g1 = this->rows;
HXDLIN( 196)			while((_g < _g1)){
HXLINE( 196)				_g = (_g + 1);
HXDLIN( 196)				int i = (_g - 1);
HXLINE( 197)				currentLine = HX_("",00,00,00,00);
HXLINE( 198)				{
HXLINE( 198)					int _g1 = 0;
HXDLIN( 198)					int _g2 = this->columns;
HXDLIN( 198)					while((_g1 < _g2)){
HXLINE( 198)						_g1 = (_g1 + 1);
HXDLIN( 198)						int j = (_g1 - 1);
HXLINE( 199)						currentChar = ( ( ::ColoredChar)(_hx_array_unsafe_get(( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,i)) ),j)) );
HXLINE( 200)						currentLine = (currentLine + (currentChar->ansiColor + currentChar->_hx_char));
            					}
            				}
HXLINE( 202)				::Sys_obj::println(currentLine);
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(TextScreen_obj,displayColour,(void))

void TextScreen_obj::displayMonochrome(){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_207_displayMonochrome)
HXLINE( 208)		this->render();
HXLINE( 209)		::String currentLine = HX_("",00,00,00,00);
HXLINE( 211)		{
HXLINE( 211)			int _g = 0;
HXDLIN( 211)			int _g1 = this->rows;
HXDLIN( 211)			while((_g < _g1)){
HXLINE( 211)				_g = (_g + 1);
HXDLIN( 211)				int i = (_g - 1);
HXLINE( 212)				currentLine = HX_("",00,00,00,00);
HXLINE( 213)				{
HXLINE( 213)					int _g1 = 0;
HXDLIN( 213)					int _g2 = this->columns;
HXDLIN( 213)					while((_g1 < _g2)){
HXLINE( 213)						_g1 = (_g1 + 1);
HXDLIN( 213)						int j = (_g1 - 1);
HXLINE( 214)						currentLine = (currentLine + ( ( ::ColoredChar)(_hx_array_unsafe_get(( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,i)) ),j)) )->_hx_char);
            					}
            				}
HXLINE( 216)				::Sys_obj::println(currentLine);
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(TextScreen_obj,displayMonochrome,(void))

void TextScreen_obj::pad(::String str,int length){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_222_pad)
HXDLIN( 222)		::TextScreen_obj::padRight(str,length);
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(TextScreen_obj,pad,(void))

::String TextScreen_obj::padRight(::String str,int length){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_225_padRight)
HXLINE( 226)		if ((length < 0)) {
HXLINE( 226)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("length cannot be negative",cf,f6,ae,84)));
            		}
HXLINE( 227)		if ((str.length > length)) {
HXLINE( 228)			return str.substr(0,length);
            		}
            		else {
HXLINE( 231)			{
HXLINE( 231)				int _g = 0;
HXDLIN( 231)				int _g1 = (length - str.length);
HXDLIN( 231)				while((_g < _g1)){
HXLINE( 231)					_g = (_g + 1);
HXDLIN( 231)					int i = (_g - 1);
HXLINE( 232)					str = (str + HX_(" ",20,00,00,00));
            				}
            			}
HXLINE( 234)			return str;
            		}
HXLINE( 227)		return null();
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(TextScreen_obj,padRight,return )

::String TextScreen_obj::padLeft(::String str,int length){
            	HX_STACKFRAME(&_hx_pos_fb46f54d0b1f8f19_238_padLeft)
HXLINE( 239)		if ((length < 0)) {
HXLINE( 239)			HX_STACK_DO_THROW(::haxe::Exception_obj::thrown(HX_("length cannot be negative",cf,f6,ae,84)));
            		}
HXLINE( 240)		if ((str.length > length)) {
HXLINE( 241)			return str.substring((str.length - length),null());
            		}
            		else {
HXLINE( 244)			{
HXLINE( 244)				int _g = 0;
HXDLIN( 244)				int _g1 = (length - str.length);
HXDLIN( 244)				while((_g < _g1)){
HXLINE( 244)					_g = (_g + 1);
HXDLIN( 244)					int i = (_g - 1);
HXLINE( 245)					str = (HX_(" ",20,00,00,00) + str);
            				}
            			}
HXLINE( 247)			return str;
            		}
HXLINE( 240)		return null();
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(TextScreen_obj,padLeft,return )


::hx::ObjectPtr< TextScreen_obj > TextScreen_obj::__new( ::Dynamic __o_rows, ::Dynamic __o_columns) {
	::hx::ObjectPtr< TextScreen_obj > __this = new TextScreen_obj();
	__this->__construct(__o_rows,__o_columns);
	return __this;
}

::hx::ObjectPtr< TextScreen_obj > TextScreen_obj::__alloc(::hx::Ctx *_hx_ctx, ::Dynamic __o_rows, ::Dynamic __o_columns) {
	TextScreen_obj *__this = (TextScreen_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(TextScreen_obj), true, "TextScreen"));
	*(void **)__this = TextScreen_obj::_hx_vtable;
	__this->__construct(__o_rows,__o_columns);
	return __this;
}

TextScreen_obj::TextScreen_obj()
{
}

void TextScreen_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TextScreen);
	HX_MARK_MEMBER_NAME(defaultChar,"defaultChar");
	HX_MARK_MEMBER_NAME(defaultTextColor,"defaultTextColor");
	HX_MARK_MEMBER_NAME(rows,"rows");
	HX_MARK_MEMBER_NAME(columns,"columns");
	HX_MARK_MEMBER_NAME(displayBuffer,"displayBuffer");
	HX_MARK_MEMBER_NAME(childWindowInfoList,"childWindowInfoList");
	HX_MARK_END_CLASS();
}

void TextScreen_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(defaultChar,"defaultChar");
	HX_VISIT_MEMBER_NAME(defaultTextColor,"defaultTextColor");
	HX_VISIT_MEMBER_NAME(rows,"rows");
	HX_VISIT_MEMBER_NAME(columns,"columns");
	HX_VISIT_MEMBER_NAME(displayBuffer,"displayBuffer");
	HX_VISIT_MEMBER_NAME(childWindowInfoList,"childWindowInfoList");
}

::hx::Val TextScreen_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"rows") ) { return ::hx::Val( rows ); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"write") ) { return ::hx::Val( write_dyn() ); }
		if (HX_FIELD_EQ(inName,"clear") ) { return ::hx::Val( clear_dyn() ); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"render") ) { return ::hx::Val( render_dyn() ); }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"columns") ) { return ::hx::Val( columns ); }
		if (HX_FIELD_EQ(inName,"display") ) { return ::hx::Val( display_dyn() ); }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"addChild") ) { return ::hx::Val( addChild_dyn() ); }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"writeLeft") ) { return ::hx::Val( writeLeft_dyn() ); }
		if (HX_FIELD_EQ(inName,"findChild") ) { return ::hx::Val( findChild_dyn() ); }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"defaultChar") ) { return ::hx::Val( defaultChar ); }
		if (HX_FIELD_EQ(inName,"removeChild") ) { return ::hx::Val( removeChild_dyn() ); }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"displayBuffer") ) { return ::hx::Val( displayBuffer ); }
		if (HX_FIELD_EQ(inName,"displayColour") ) { return ::hx::Val( displayColour_dyn() ); }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"defaultTextColor") ) { return ::hx::Val( defaultTextColor ); }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"displayMonochrome") ) { return ::hx::Val( displayMonochrome_dyn() ); }
		break;
	case 19:
		if (HX_FIELD_EQ(inName,"childWindowInfoList") ) { return ::hx::Val( childWindowInfoList ); }
	}
	return super::__Field(inName,inCallProp);
}

bool TextScreen_obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"pad") ) { outValue = pad_dyn(); return true; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"padLeft") ) { outValue = padLeft_dyn(); return true; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"padRight") ) { outValue = padRight_dyn(); return true; }
	}
	return false;
}

::hx::Val TextScreen_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"rows") ) { rows=inValue.Cast< int >(); return inValue; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"columns") ) { columns=inValue.Cast< int >(); return inValue; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"defaultChar") ) { defaultChar=inValue.Cast< ::String >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"displayBuffer") ) { displayBuffer=inValue.Cast< ::Array< ::Dynamic> >(); return inValue; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"defaultTextColor") ) { defaultTextColor=inValue.Cast< ::String >(); return inValue; }
		break;
	case 19:
		if (HX_FIELD_EQ(inName,"childWindowInfoList") ) { childWindowInfoList=inValue.Cast< ::Array< ::Dynamic> >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void TextScreen_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("defaultChar",37,58,7e,13));
	outFields->push(HX_("defaultTextColor",75,68,42,a6));
	outFields->push(HX_("rows",19,f5,ae,4b));
	outFields->push(HX_("columns",dd,ac,59,f3));
	outFields->push(HX_("displayBuffer",e2,78,f7,91));
	outFields->push(HX_("childWindowInfoList",b8,66,cd,39));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo TextScreen_obj_sMemberStorageInfo[] = {
	{::hx::fsString,(int)offsetof(TextScreen_obj,defaultChar),HX_("defaultChar",37,58,7e,13)},
	{::hx::fsString,(int)offsetof(TextScreen_obj,defaultTextColor),HX_("defaultTextColor",75,68,42,a6)},
	{::hx::fsInt,(int)offsetof(TextScreen_obj,rows),HX_("rows",19,f5,ae,4b)},
	{::hx::fsInt,(int)offsetof(TextScreen_obj,columns),HX_("columns",dd,ac,59,f3)},
	{::hx::fsObject /* ::Array< ::Dynamic> */ ,(int)offsetof(TextScreen_obj,displayBuffer),HX_("displayBuffer",e2,78,f7,91)},
	{::hx::fsObject /* ::Array< ::Dynamic> */ ,(int)offsetof(TextScreen_obj,childWindowInfoList),HX_("childWindowInfoList",b8,66,cd,39)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *TextScreen_obj_sStaticStorageInfo = 0;
#endif

static ::String TextScreen_obj_sMemberFields[] = {
	HX_("defaultChar",37,58,7e,13),
	HX_("defaultTextColor",75,68,42,a6),
	HX_("rows",19,f5,ae,4b),
	HX_("columns",dd,ac,59,f3),
	HX_("displayBuffer",e2,78,f7,91),
	HX_("childWindowInfoList",b8,66,cd,39),
	HX_("write",df,6c,59,d0),
	HX_("writeLeft",86,fc,63,50),
	HX_("clear",8d,71,5b,48),
	HX_("addChild",bb,cf,16,bf),
	HX_("removeChild",b8,86,ed,43),
	HX_("findChild",a3,da,b0,34),
	HX_("render",56,6b,29,05),
	HX_("display",42,2a,4a,bb),
	HX_("displayColour",2e,84,e9,87),
	HX_("displayMonochrome",bf,66,f8,dd),
	::String(null()) };

::hx::Class TextScreen_obj::__mClass;

static ::String TextScreen_obj_sStaticFields[] = {
	HX_("pad",53,51,55,00),
	HX_("padRight",89,7d,f5,3f),
	HX_("padLeft",fa,2a,9d,c0),
	::String(null())
};

void TextScreen_obj::__register()
{
	TextScreen_obj _hx_dummy;
	TextScreen_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("TextScreen",19,c0,fe,74);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &TextScreen_obj::__GetStatic;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(TextScreen_obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(TextScreen_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< TextScreen_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = TextScreen_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = TextScreen_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

