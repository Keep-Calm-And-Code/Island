#include <hxcpp.h>

#ifndef INCLUDED_95f339a1d026d52c
#define INCLUDED_95f339a1d026d52c
#include "hxMath.h"
#endif
#ifndef INCLUDED_ColoredChar
#include <ColoredChar.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif

HX_DEFINE_STACK_FRAME(_hx_pos_8d7a2529b6b43049_268_new,"TextWindow","new",0x51becc0f,"TextWindow.new","TextScreen.hx",268,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_8d7a2529b6b43049_278_write,"TextWindow","write",0x8f3df24e,"TextWindow.write","TextScreen.hx",278,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_8d7a2529b6b43049_286_clear,"TextWindow","clear",0x073ff6fc,"TextWindow.clear","TextScreen.hx",286,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_8d7a2529b6b43049_299_render,"TextWindow","render",0x4e39a707,"TextWindow.render","TextScreen.hx",299,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_8d7a2529b6b43049_305_copyDataBuffer,"TextWindow","copyDataBuffer",0x3c72ab90,"TextWindow.copyDataBuffer","TextScreen.hx",305,0x3762d845)

void TextWindow_obj::__construct( ::Dynamic __o_rows, ::Dynamic __o_columns,::String __o_name){
            		 ::Dynamic rows = __o_rows;
            		if (::hx::IsNull(__o_rows)) rows = 24;
            		 ::Dynamic columns = __o_columns;
            		if (::hx::IsNull(__o_columns)) columns = 80;
            		::String name = __o_name;
            		if (::hx::IsNull(__o_name)) name = HX_("",00,00,00,00);
            	HX_STACKFRAME(&_hx_pos_8d7a2529b6b43049_268_new)
HXLINE( 269)		this->name = name;
HXLINE( 270)		::Array< ::Dynamic> this1 = ::Array_obj< ::Dynamic>::__new(( (int)(rows) ));
HXDLIN( 270)		this->dataBuffer = this1;
HXLINE( 271)		{
HXLINE( 271)			int _g = 0;
HXDLIN( 271)			 ::Dynamic _g1 = rows;
HXDLIN( 271)			while(::hx::IsLess( _g,_g1 )){
HXLINE( 271)				_g = (_g + 1);
HXDLIN( 271)				int i = (_g - 1);
HXLINE( 272)				{
HXLINE( 272)					::Array< ::Dynamic> this1 = this->dataBuffer;
HXDLIN( 272)					::Array< ::Dynamic> this2 = ::Array_obj< ::Dynamic>::__new(( (int)(columns) ));
HXDLIN( 272)					this1->__unsafe_set(i,this2);
            				}
            			}
            		}
HXLINE( 275)		super::__construct(rows,columns);
            	}

Dynamic TextWindow_obj::__CreateEmpty() { return new TextWindow_obj; }

void *TextWindow_obj::_hx_vtable = 0;

Dynamic TextWindow_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< TextWindow_obj > _hx_result = new TextWindow_obj();
	_hx_result->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return _hx_result;
}

bool TextWindow_obj::_hx_isInstanceOf(int inClassId) {
	if (inClassId<=(int)0x0b23efa1) {
		return inClassId==(int)0x00000001 || inClassId==(int)0x0b23efa1;
	} else {
		return inClassId==(int)0x16534825;
	}
}

void TextWindow_obj::write(::String text,::String color, ::Dynamic __o_row, ::Dynamic __o_column){
            		 ::Dynamic row = __o_row;
            		if (::hx::IsNull(__o_row)) row = 0;
            		 ::Dynamic column = __o_column;
            		if (::hx::IsNull(__o_column)) column = 0;
            	HX_GC_STACKFRAME(&_hx_pos_8d7a2529b6b43049_278_write)
HXLINE( 280)		if (::hx::IsNull( color )) {
HXLINE( 280)			color = this->defaultTextColor;
            		}
HXLINE( 281)		{
HXLINE( 281)			int _g = 0;
HXDLIN( 281)			int _hx_int = (this->columns - ( (int)(column) ));
HXDLIN( 281)			Float _g1;
HXDLIN( 281)			if ((_hx_int < 0)) {
HXLINE( 281)				_g1 = (((Float)4294967296.0) + _hx_int);
            			}
            			else {
HXLINE( 281)				_g1 = (_hx_int + ((Float)0.0));
            			}
HXDLIN( 281)			int _g2 = ::Math_obj::round(::Math_obj::min(( (Float)(text.length) ),_g1));
HXDLIN( 281)			while((_g < _g2)){
HXLINE( 281)				_g = (_g + 1);
HXDLIN( 281)				int i = (_g - 1);
HXLINE( 282)				{
HXLINE( 282)					::Array< ::Dynamic> this1 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->dataBuffer,( (int)(row) ))) );
HXDLIN( 282)					 ::ColoredChar val =  ::ColoredChar_obj::__alloc( HX_CTX ,text.charAt(i),color);
HXDLIN( 282)					this1->__unsafe_set((column + i),val);
            				}
            			}
            		}
            	}


void TextWindow_obj::clear(::String fill){
            	HX_GC_STACKFRAME(&_hx_pos_8d7a2529b6b43049_286_clear)
HXLINE( 287)		if (::hx::IsNull( fill )) {
HXLINE( 287)			fill = this->defaultChar;
            		}
HXLINE( 288)		fill = fill.charAt(0);
HXLINE( 290)		{
HXLINE( 290)			int _g = 0;
HXDLIN( 290)			int _g1 = this->rows;
HXDLIN( 290)			while((_g < _g1)){
HXLINE( 290)				_g = (_g + 1);
HXDLIN( 290)				int i = (_g - 1);
HXLINE( 291)				{
HXLINE( 291)					int _g1 = 0;
HXDLIN( 291)					int _g2 = this->columns;
HXDLIN( 291)					while((_g1 < _g2)){
HXLINE( 291)						_g1 = (_g1 + 1);
HXDLIN( 291)						int j = (_g1 - 1);
HXLINE( 292)						{
HXLINE( 292)							::Array< ::Dynamic> this1 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,i)) );
HXDLIN( 292)							 ::ColoredChar val =  ::ColoredChar_obj::__alloc( HX_CTX ,this->defaultChar,this->defaultTextColor);
HXDLIN( 292)							this1->__unsafe_set(j,val);
            						}
HXLINE( 293)						{
HXLINE( 293)							::Array< ::Dynamic> this2 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->dataBuffer,i)) );
HXDLIN( 293)							 ::ColoredChar val1 =  ::ColoredChar_obj::__alloc( HX_CTX ,this->defaultChar,this->defaultTextColor);
HXDLIN( 293)							this2->__unsafe_set(j,val1);
            						}
            					}
            				}
            			}
            		}
            	}


void TextWindow_obj::render(){
            	HX_STACKFRAME(&_hx_pos_8d7a2529b6b43049_299_render)
HXLINE( 300)		this->copyDataBuffer();
HXLINE( 301)		this->super::render();
            	}


void TextWindow_obj::copyDataBuffer(){
            	HX_STACKFRAME(&_hx_pos_8d7a2529b6b43049_305_copyDataBuffer)
HXDLIN( 305)		int _g = 0;
HXDLIN( 305)		int _g1 = this->rows;
HXDLIN( 305)		while((_g < _g1)){
HXDLIN( 305)			_g = (_g + 1);
HXDLIN( 305)			int row = (_g - 1);
HXLINE( 306)			{
HXLINE( 306)				int _g1 = 0;
HXDLIN( 306)				int _g2 = this->columns;
HXDLIN( 306)				while((_g1 < _g2)){
HXLINE( 306)					_g1 = (_g1 + 1);
HXDLIN( 306)					int col = (_g1 - 1);
HXLINE( 307)					{
HXLINE( 307)						::Array< ::Dynamic> this1 = ( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->displayBuffer,row)) );
HXDLIN( 307)						 ::ColoredChar val = ( ( ::ColoredChar)(_hx_array_unsafe_get(( (::Array< ::Dynamic>)(_hx_array_unsafe_get(this->dataBuffer,row)) ),col)) );
HXDLIN( 307)						this1->__unsafe_set(col,val);
            					}
            				}
            			}
            		}
            	}


HX_DEFINE_DYNAMIC_FUNC0(TextWindow_obj,copyDataBuffer,(void))


::hx::ObjectPtr< TextWindow_obj > TextWindow_obj::__new( ::Dynamic __o_rows, ::Dynamic __o_columns,::String __o_name) {
	::hx::ObjectPtr< TextWindow_obj > __this = new TextWindow_obj();
	__this->__construct(__o_rows,__o_columns,__o_name);
	return __this;
}

::hx::ObjectPtr< TextWindow_obj > TextWindow_obj::__alloc(::hx::Ctx *_hx_ctx, ::Dynamic __o_rows, ::Dynamic __o_columns,::String __o_name) {
	TextWindow_obj *__this = (TextWindow_obj*)(::hx::Ctx::alloc(_hx_ctx, sizeof(TextWindow_obj), true, "TextWindow"));
	*(void **)__this = TextWindow_obj::_hx_vtable;
	__this->__construct(__o_rows,__o_columns,__o_name);
	return __this;
}

TextWindow_obj::TextWindow_obj()
{
}

void TextWindow_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TextWindow);
	HX_MARK_MEMBER_NAME(name,"name");
	HX_MARK_MEMBER_NAME(dataBuffer,"dataBuffer");
	 ::TextScreen_obj::__Mark(HX_MARK_ARG);
	HX_MARK_END_CLASS();
}

void TextWindow_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(name,"name");
	HX_VISIT_MEMBER_NAME(dataBuffer,"dataBuffer");
	 ::TextScreen_obj::__Visit(HX_VISIT_ARG);
}

::hx::Val TextWindow_obj::__Field(const ::String &inName,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { return ::hx::Val( name ); }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"write") ) { return ::hx::Val( write_dyn() ); }
		if (HX_FIELD_EQ(inName,"clear") ) { return ::hx::Val( clear_dyn() ); }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"render") ) { return ::hx::Val( render_dyn() ); }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"dataBuffer") ) { return ::hx::Val( dataBuffer ); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"copyDataBuffer") ) { return ::hx::Val( copyDataBuffer_dyn() ); }
	}
	return super::__Field(inName,inCallProp);
}

::hx::Val TextWindow_obj::__SetField(const ::String &inName,const ::hx::Val &inValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"name") ) { name=inValue.Cast< ::String >(); return inValue; }
		break;
	case 10:
		if (HX_FIELD_EQ(inName,"dataBuffer") ) { dataBuffer=inValue.Cast< ::Array< ::Dynamic> >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

void TextWindow_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_("name",4b,72,ff,48));
	outFields->push(HX_("dataBuffer",ca,82,36,bc));
	super::__GetFields(outFields);
};

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo TextWindow_obj_sMemberStorageInfo[] = {
	{::hx::fsString,(int)offsetof(TextWindow_obj,name),HX_("name",4b,72,ff,48)},
	{::hx::fsObject /* ::Array< ::Dynamic> */ ,(int)offsetof(TextWindow_obj,dataBuffer),HX_("dataBuffer",ca,82,36,bc)},
	{ ::hx::fsUnknown, 0, null()}
};
static ::hx::StaticInfo *TextWindow_obj_sStaticStorageInfo = 0;
#endif

static ::String TextWindow_obj_sMemberFields[] = {
	HX_("name",4b,72,ff,48),
	HX_("dataBuffer",ca,82,36,bc),
	HX_("write",df,6c,59,d0),
	HX_("clear",8d,71,5b,48),
	HX_("render",56,6b,29,05),
	HX_("copyDataBuffer",df,d6,45,e7),
	::String(null()) };

::hx::Class TextWindow_obj::__mClass;

void TextWindow_obj::__register()
{
	TextWindow_obj _hx_dummy;
	TextWindow_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("TextWindow",9d,18,2e,80);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &::hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(TextWindow_obj_sMemberFields);
	__mClass->mCanCast = ::hx::TCanCast< TextWindow_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = TextWindow_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = TextWindow_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

