#include <hxcpp.h>

#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_Type
#include <Type.h>
#endif
#ifndef INCLUDED_haxe_Exception
#include <haxe/Exception.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_0204e134993bc8c3_158_enumParameters,"Type","enumParameters",0xf9e1b41f,"Type.enumParameters","D:\\HaxeToolkit\\haxe\\std/cpp/_std/Type.hx",158,0x1797891d)
HX_LOCAL_STACK_FRAME(_hx_pos_0204e134993bc8c3_170_allEnums,"Type","allEnums",0x86200985,"Type.allEnums","D:\\HaxeToolkit\\haxe\\std/cpp/_std/Type.hx",170,0x1797891d)

void Type_obj::__construct() { }

Dynamic Type_obj::__CreateEmpty() { return new Type_obj; }

void *Type_obj::_hx_vtable = 0;

Dynamic Type_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Type_obj > _hx_result = new Type_obj();
	_hx_result->__construct();
	return _hx_result;
}

bool Type_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x0c3514fe;
}

::cpp::VirtualArray Type_obj::enumParameters( ::Dynamic e){
            	HX_STACKFRAME(&_hx_pos_0204e134993bc8c3_158_enumParameters)
HXLINE( 159)		 hx::EnumBase value = ( ( hx::EnumBase)(e) );
HXLINE( 160)		return value->_hx_getParameters();
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Type_obj,enumParameters,return )

::cpp::VirtualArray Type_obj::allEnums(::hx::Class e){
            	HX_STACKFRAME(&_hx_pos_0204e134993bc8c3_170_allEnums)
HXLINE( 171)		::Array< ::String > names = ( (::Array< ::String >)(e->GetClassFields()) );
HXLINE( 172)		::cpp::VirtualArray enums = ::cpp::VirtualArray_obj::__new();
HXLINE( 173)		{
HXLINE( 173)			int _g = 0;
HXDLIN( 173)			while((_g < names->length)){
HXLINE( 173)				::String name = names->__get(_g);
HXDLIN( 173)				_g = (_g + 1);
HXLINE( 174)				try {
            					HX_STACK_CATCHABLE( ::Dynamic, 0);
HXLINE( 175)					 ::Dynamic result = e->ConstructEnum(name,null());
HXLINE( 176)					if (::hx::IsNotNull( result )) {
HXLINE( 177)						enums->push(result);
            					}
            				} catch( ::Dynamic _hx_e) {
            					if (_hx_e.IsClass<  ::Dynamic >() ){
            						HX_STACK_BEGIN_CATCH
            						 ::Dynamic _g = _hx_e;
HXLINE( 178)						{
HXLINE( 178)							null();
            						}
HXLINE( 174)						if (!(::Std_obj::isOfType(::haxe::Exception_obj::caught(_g)->unwrap(),::hx::ClassOf< ::String >()))) {
HXLINE( 174)							HX_STACK_DO_THROW(_g);
            						}
            					}
            					else {
            						HX_STACK_DO_THROW(_hx_e);
            					}
            				}
            			}
            		}
HXLINE( 180)		return enums;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Type_obj,allEnums,return )


Type_obj::Type_obj()
{
}

bool Type_obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 8:
		if (HX_FIELD_EQ(inName,"allEnums") ) { outValue = allEnums_dyn(); return true; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"enumParameters") ) { outValue = enumParameters_dyn(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *Type_obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo *Type_obj_sStaticStorageInfo = 0;
#endif

::hx::Class Type_obj::__mClass;

static ::String Type_obj_sStaticFields[] = {
	HX_("enumParameters",0b,59,78,fa),
	HX_("allEnums",71,f5,6a,69),
	::String(null())
};

void Type_obj::__register()
{
	Type_obj _hx_dummy;
	Type_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Type",da,1e,e2,37);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Type_obj::__GetStatic;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Type_obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< Type_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Type_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Type_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

