#include <hxcpp.h>

#ifndef INCLUDED_95f339a1d026d52c
#define INCLUDED_95f339a1d026d52c
#include "hxMath.h"
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_fd08db6f3c3a61df_7_randomInt,"Utils","randomInt",0x1f5cca0f,"Utils.randomInt","Utils.hx",7,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_fd08db6f3c3a61df_18_maxInt,"Utils","maxInt",0xfe8e0968,"Utils.maxInt","Utils.hx",18,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_fd08db6f3c3a61df_22_minInt,"Utils","minInt",0x93268b3a,"Utils.minInt","Utils.hx",22,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_fd08db6f3c3a61df_28_round,"Utils","round",0x91d90e31,"Utils.round","Utils.hx",28,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_fd08db6f3c3a61df_34_roundInt,"Utils","roundInt",0xbd5eeb3e,"Utils.roundInt","Utils.hx",34,0x4c60094d)
HX_LOCAL_STACK_FRAME(_hx_pos_fd08db6f3c3a61df_37_randomElement,"Utils","randomElement",0xc3d67bdc,"Utils.randomElement","Utils.hx",37,0x4c60094d)

void Utils_obj::__construct() { }

Dynamic Utils_obj::__CreateEmpty() { return new Utils_obj; }

void *Utils_obj::_hx_vtable = 0;

Dynamic Utils_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Utils_obj > _hx_result = new Utils_obj();
	_hx_result->__construct();
	return _hx_result;
}

bool Utils_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x3250836d;
}

int Utils_obj::randomInt(int min, ::Dynamic __o_max){
            		 ::Dynamic max = __o_max;
            		if (::hx::IsNull(__o_max)) max = 0;
            	HX_STACKFRAME(&_hx_pos_fd08db6f3c3a61df_7_randomInt)
HXLINE(   8)		if (::hx::IsGreater( min,max )) {
HXLINE(   9)			int temp = min;
HXLINE(  10)			max = min;
HXLINE(  11)			min = temp;
            		}
HXLINE(  14)		return ::Math_obj::floor((min + (::Math_obj::random() * ( (Float)(((( (int)(max) ) - min) + 1)) ))));
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Utils_obj,randomInt,return )

int Utils_obj::maxInt(int a,int b){
            	HX_STACKFRAME(&_hx_pos_fd08db6f3c3a61df_18_maxInt)
HXDLIN(  18)		if ((a > b)) {
HXDLIN(  18)			return a;
            		}
            		else {
HXDLIN(  18)			return b;
            		}
HXDLIN(  18)		return 0;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Utils_obj,maxInt,return )

int Utils_obj::minInt(int a,int b, ::Dynamic c){
            	HX_STACKFRAME(&_hx_pos_fd08db6f3c3a61df_22_minInt)
HXDLIN(  22)		if (::hx::IsNull( c )) {
HXLINE(  23)			if ((a < b)) {
HXLINE(  23)				return a;
            			}
            			else {
HXLINE(  23)				return b;
            			}
            		}
            		else {
HXLINE(  25)			return ::Utils_obj::minInt(a,::Utils_obj::minInt(b,( (int)(c) ),null()),null());
            		}
HXLINE(  22)		return 0;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC3(Utils_obj,minInt,return )

Float Utils_obj::round(Float f, ::Dynamic __o_places){
            		 ::Dynamic places = __o_places;
            		if (::hx::IsNull(__o_places)) places = 0;
            	HX_STACKFRAME(&_hx_pos_fd08db6f3c3a61df_28_round)
HXLINE(  29)		int _hx_int = ( (int)(places) );
HXDLIN(  29)		Float shift;
HXDLIN(  29)		if ((_hx_int < 0)) {
HXLINE(  29)			shift = (((Float)4294967296.0) + _hx_int);
            		}
            		else {
HXLINE(  29)			shift = (_hx_int + ((Float)0.0));
            		}
HXDLIN(  29)		Float shift1 = ::Math_obj::pow(( (Float)(10) ),shift);
HXLINE(  30)		return (( (Float)(::Math_obj::floor(((f * shift1) + ((Float)0.5)))) ) / shift1);
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Utils_obj,round,return )

int Utils_obj::roundInt(Float f){
            	HX_STACKFRAME(&_hx_pos_fd08db6f3c3a61df_34_roundInt)
HXDLIN(  34)		return ::Math_obj::floor((f + ((Float)0.5)));
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Utils_obj,roundInt,return )

::String Utils_obj::randomElement(::cpp::VirtualArray a){
            	HX_STACKFRAME(&_hx_pos_fd08db6f3c3a61df_37_randomElement)
HXLINE(  38)		if ((a->get_length() == 0)) {
HXLINE(  38)			return null();
            		}
HXLINE(  40)		return ( (::String)(a->__get(::Utils_obj::randomInt(0,(a->get_length() - 1)))) );
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(Utils_obj,randomElement,return )


Utils_obj::Utils_obj()
{
}

bool Utils_obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"round") ) { outValue = round_dyn(); return true; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"maxInt") ) { outValue = maxInt_dyn(); return true; }
		if (HX_FIELD_EQ(inName,"minInt") ) { outValue = minInt_dyn(); return true; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"roundInt") ) { outValue = roundInt_dyn(); return true; }
		break;
	case 9:
		if (HX_FIELD_EQ(inName,"randomInt") ) { outValue = randomInt_dyn(); return true; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"randomElement") ) { outValue = randomElement_dyn(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *Utils_obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo *Utils_obj_sStaticStorageInfo = 0;
#endif

::hx::Class Utils_obj::__mClass;

static ::String Utils_obj_sStaticFields[] = {
	HX_("randomInt",ac,86,45,a7),
	HX_("maxInt",ab,f8,4d,be),
	HX_("minInt",7d,7a,e6,52),
	HX_("round",4e,f8,65,ed),
	HX_("roundInt",41,71,6b,e0),
	HX_("randomElement",f9,4a,b6,1a),
	::String(null())
};

void Utils_obj::__register()
{
	Utils_obj _hx_dummy;
	Utils_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Utils",11,1a,0c,3e);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Utils_obj::__GetStatic;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Utils_obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< Utils_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Utils_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Utils_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

