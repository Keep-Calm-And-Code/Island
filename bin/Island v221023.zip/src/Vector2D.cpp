#include <hxcpp.h>

#ifndef INCLUDED_Vector2D
#include <Vector2D.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_245f3a8bbecb271a_77_create,"Vector2D","create",0x7a2936d5,"Vector2D.create","Utils.hx",77,0x4c60094d)

void Vector2D_obj::__construct() { }

Dynamic Vector2D_obj::__CreateEmpty() { return new Vector2D_obj; }

void *Vector2D_obj::_hx_vtable = 0;

Dynamic Vector2D_obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Vector2D_obj > _hx_result = new Vector2D_obj();
	_hx_result->__construct();
	return _hx_result;
}

bool Vector2D_obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x51c44cfd;
}

::Array< ::Dynamic> Vector2D_obj::create(int h,int w){
            	HX_STACKFRAME(&_hx_pos_245f3a8bbecb271a_77_create)
HXLINE(  78)		::Array< ::Dynamic> this1 = ::Array_obj< ::Dynamic>::__new(h);
HXDLIN(  78)		::Array< ::Dynamic> v = this1;
HXLINE(  79)		{
HXLINE(  79)			int _g = 0;
HXDLIN(  79)			int _g1 = h;
HXDLIN(  79)			while((_g < _g1)){
HXLINE(  79)				_g = (_g + 1);
HXDLIN(  79)				int i = (_g - 1);
HXLINE(  81)				{
HXLINE(  81)					::cpp::VirtualArray this1 = ::cpp::VirtualArray_obj::__new(w);
HXDLIN(  81)					v->__unsafe_set(i,this1);
            				}
            			}
            		}
HXLINE(  83)		return v;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Vector2D_obj,create,return )


Vector2D_obj::Vector2D_obj()
{
}

bool Vector2D_obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"create") ) { outValue = create_dyn(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *Vector2D_obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo *Vector2D_obj_sStaticStorageInfo = 0;
#endif

::hx::Class Vector2D_obj::__mClass;

static ::String Vector2D_obj_sStaticFields[] = {
	HX_("create",fc,66,0f,7c),
	::String(null())
};

void Vector2D_obj::__register()
{
	Vector2D_obj _hx_dummy;
	Vector2D_obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("Vector2D",75,8f,6f,48);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Vector2D_obj::__GetStatic;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Vector2D_obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< Vector2D_obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Vector2D_obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Vector2D_obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

