#include <hxcpp.h>

#ifndef INCLUDED_Building
#include <Building.h>
#endif
#ifndef INCLUDED_Pile
#include <Pile.h>
#endif
#ifndef INCLUDED_Resource
#include <Resource.h>
#endif
#ifndef INCLUDED__Building_Building_Fields_
#include <_Building/Building_Fields_.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_1f26bc199d6ac4a1_33_CostToBuild,"_Building.Building_Fields_","CostToBuild",0xa80facee,"_Building.Building_Fields_.CostToBuild","Building.hx",33,0x95d3f8aa)
HX_LOCAL_STACK_FRAME(_hx_pos_1f26bc199d6ac4a1_19_boot,"_Building.Building_Fields_","boot",0x70819f0a,"_Building.Building_Fields_.boot","Building.hx",19,0x95d3f8aa)
namespace _Building{

void Building_Fields__obj::__construct() { }

Dynamic Building_Fields__obj::__CreateEmpty() { return new Building_Fields__obj; }

void *Building_Fields__obj::_hx_vtable = 0;

Dynamic Building_Fields__obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Building_Fields__obj > _hx_result = new Building_Fields__obj();
	_hx_result->__construct();
	return _hx_result;
}

bool Building_Fields__obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x14cfff8a;
}

 ::haxe::ds::EnumValueMap Building_Fields__obj::names;

 ::Pile Building_Fields__obj::CostToBuild( ::Building b,int n){
            	HX_GC_STACKFRAME(&_hx_pos_1f26bc199d6ac4a1_33_CostToBuild)
HXLINE(  35)		 ::Pile cost =  ::Pile_obj::__alloc( HX_CTX ,null());
HXLINE(  37)		switch((int)(b->_hx_getIndex())){
            			case (int)0: {
HXLINE(  40)				cost->add(::Resource_obj::Grain_dyn(),(12 + ((3 * n) * n)));
HXLINE(  41)				cost->add(::Resource_obj::Wood_dyn(),(30 + ((5 * n) * (n + 1))));
HXLINE(  42)				if ((n >= 4)) {
HXLINE(  42)					cost->add(::Resource_obj::Tools_dyn(),((4 * (n - 3)) * (n - 2)));
            				}
HXLINE(  43)				return cost;
            			}
            			break;
            			case (int)1: {
HXLINE(  46)				cost->add(::Resource_obj::Wood_dyn(),(10 + ((5 * n) * (n + 1))));
HXLINE(  47)				if ((n >= 3)) {
HXLINE(  47)					cost->add(::Resource_obj::Tools_dyn(),((3 * (n - 2)) * (n - 1)));
            				}
HXLINE(  48)				return cost;
            			}
            			break;
            			case (int)2: {
HXLINE(  51)				cost->add(::Resource_obj::Grain_dyn(),(6 + ((3 * n) * (n + 1))));
HXLINE(  52)				cost->add(::Resource_obj::Metal_dyn(),(6 + ((3 * n) * (n + 1))));
HXLINE(  53)				if ((n >= 5)) {
HXLINE(  53)					cost->add(::Resource_obj::Tools_dyn(),((5 * (n - 3)) * (n - 3)));
            				}
HXLINE(  54)				return cost;
            			}
            			break;
            			case (int)3: {
HXLINE(  57)				cost->add(::Resource_obj::Wood_dyn(),(8 + ((4 * n) * (n + 1))));
HXLINE(  58)				cost->add(::Resource_obj::Grain_dyn(),(6 + ((3 * n) * (n + 1))));
HXLINE(  59)				return cost;
            			}
            			break;
            			case (int)4: {
HXLINE(  62)				cost->add(::Resource_obj::Wood_dyn(),(6 + ((3 * n) * (n + 1))));
HXLINE(  63)				cost->add(::Resource_obj::Metal_dyn(),(8 + ((4 * n) * (n + 1))));
HXLINE(  64)				return cost;
            			}
            			break;
            			case (int)5: {
HXLINE(  67)				cost->add(::Resource_obj::Wood_dyn(),(8 + ((4 * n) * (n + 1))));
HXLINE(  68)				cost->add(::Resource_obj::Metal_dyn(),(6 + ((3 * n) * (n + 1))));
HXLINE(  69)				if ((n >= 3)) {
HXLINE(  69)					cost->add(::Resource_obj::Tools_dyn(),((4 * (n - 2)) * (n - 1)));
            				}
HXLINE(  70)				return cost;
            			}
            			break;
            			case (int)6: {
HXLINE(  73)				cost->add(::Resource_obj::Grain_dyn(),(5 + ((5 * n) * (n + 2))));
HXLINE(  74)				cost->add(::Resource_obj::Wood_dyn(),(10 + ((3 * n) * (n + 1))));
HXLINE(  75)				if ((n >= 3)) {
HXLINE(  75)					cost->add(::Resource_obj::Metal_dyn(),(10 + ((4 * n) * (n - 1))));
            				}
HXLINE(  76)				return cost;
            			}
            			break;
            		}
HXLINE(  37)		return null();
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC2(Building_Fields__obj,CostToBuild,return )


Building_Fields__obj::Building_Fields__obj()
{
}

bool Building_Fields__obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"names") ) { outValue = ( names ); return true; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"CostToBuild") ) { outValue = CostToBuild_dyn(); return true; }
	}
	return false;
}

bool Building_Fields__obj::__SetStatic(const ::String &inName,Dynamic &ioValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"names") ) { names=ioValue.Cast<  ::haxe::ds::EnumValueMap >(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *Building_Fields__obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo Building_Fields__obj_sStaticStorageInfo[] = {
	{::hx::fsObject /*  ::haxe::ds::EnumValueMap */ ,(void *) &Building_Fields__obj::names,HX_("names",c8,8f,84,96)},
	{ ::hx::fsUnknown, 0, null()}
};
#endif

static void Building_Fields__obj_sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Building_Fields__obj::names,"names");
};

#ifdef HXCPP_VISIT_ALLOCS
static void Building_Fields__obj_sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Building_Fields__obj::names,"names");
};

#endif

::hx::Class Building_Fields__obj::__mClass;

static ::String Building_Fields__obj_sStaticFields[] = {
	HX_("names",c8,8f,84,96),
	HX_("CostToBuild",c6,3c,8e,1c),
	::String(null())
};

void Building_Fields__obj::__register()
{
	Building_Fields__obj _hx_dummy;
	Building_Fields__obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("_Building.Building_Fields_",96,34,d4,d4);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Building_Fields__obj::__GetStatic;
	__mClass->mSetStaticField = &Building_Fields__obj::__SetStatic;
	__mClass->mMarkFunc = Building_Fields__obj_sMarkStatics;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Building_Fields__obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< Building_Fields__obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = Building_Fields__obj_sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Building_Fields__obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Building_Fields__obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

void Building_Fields__obj::__boot()
{
{
            		HX_BEGIN_LOCAL_FUNC_S0(::hx::LocalFunc,_hx_Closure_0) HXARGC(0)
            		 ::haxe::ds::EnumValueMap _hx_run(){
            			HX_GC_STACKFRAME(&_hx_pos_1f26bc199d6ac4a1_19_boot)
HXDLIN(  19)			 ::haxe::ds::EnumValueMap _g =  ::haxe::ds::EnumValueMap_obj::__alloc( HX_CTX );
HXDLIN(  19)			_g->set(::Building_obj::House_dyn(),HX_("House",80,9f,91,be));
HXDLIN(  19)			_g->set(::Building_obj::Farm_dyn(),HX_("Farm",d6,ed,8e,2e));
HXDLIN(  19)			_g->set(::Building_obj::Sawmill_dyn(),HX_("Sawmill",65,d5,1e,11));
HXDLIN(  19)			_g->set(::Building_obj::Mine_dyn(),HX_("Mine",b3,7a,35,33));
HXDLIN(  19)			_g->set(::Building_obj::Blacksmith_dyn(),HX_("Blacksmith",c4,03,96,99));
HXDLIN(  19)			_g->set(::Building_obj::Port_dyn(),HX_("Port",a1,af,35,35));
HXDLIN(  19)			_g->set(::Building_obj::Temple_dyn(),HX_("Temple",ad,82,d4,05));
HXDLIN(  19)			return _g;
            		}
            		HX_END_LOCAL_FUNC0(return)

            	HX_STACKFRAME(&_hx_pos_1f26bc199d6ac4a1_19_boot)
HXDLIN(  19)		names = ( ( ::haxe::ds::EnumValueMap)( ::Dynamic(new _hx_Closure_0())()) );
            	}
}

} // end namespace _Building
