#include <hxcpp.h>

#ifndef INCLUDED_Terrain
#include <Terrain.h>
#endif
#ifndef INCLUDED__Island_Island_Fields_
#include <_Island/Island_Fields_.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_59f5a27777308c25_739_boot,"_Island.Island_Fields_","boot",0xa9effbea,"_Island.Island_Fields_.boot","Island.hx",739,0xc47cb6e9)
HX_LOCAL_STACK_FRAME(_hx_pos_59f5a27777308c25_743_boot,"_Island.Island_Fields_","boot",0xa9effbea,"_Island.Island_Fields_.boot","Island.hx",743,0xc47cb6e9)
namespace _Island{

void Island_Fields__obj::__construct() { }

Dynamic Island_Fields__obj::__CreateEmpty() { return new Island_Fields__obj; }

void *Island_Fields__obj::_hx_vtable = 0;

Dynamic Island_Fields__obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Island_Fields__obj > _hx_result = new Island_Fields__obj();
	_hx_result->__construct();
	return _hx_result;
}

bool Island_Fields__obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x60672ccc;
}

 ::haxe::ds::EnumValueMap Island_Fields__obj::terrainNames;

 ::haxe::ds::EnumValueMap Island_Fields__obj::terrainChars;


Island_Fields__obj::Island_Fields__obj()
{
}

bool Island_Fields__obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 12:
		if (HX_FIELD_EQ(inName,"terrainNames") ) { outValue = ( terrainNames ); return true; }
		if (HX_FIELD_EQ(inName,"terrainChars") ) { outValue = ( terrainChars ); return true; }
	}
	return false;
}

bool Island_Fields__obj::__SetStatic(const ::String &inName,Dynamic &ioValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 12:
		if (HX_FIELD_EQ(inName,"terrainNames") ) { terrainNames=ioValue.Cast<  ::haxe::ds::EnumValueMap >(); return true; }
		if (HX_FIELD_EQ(inName,"terrainChars") ) { terrainChars=ioValue.Cast<  ::haxe::ds::EnumValueMap >(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *Island_Fields__obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo Island_Fields__obj_sStaticStorageInfo[] = {
	{::hx::fsObject /*  ::haxe::ds::EnumValueMap */ ,(void *) &Island_Fields__obj::terrainNames,HX_("terrainNames",d3,c3,86,12)},
	{::hx::fsObject /*  ::haxe::ds::EnumValueMap */ ,(void *) &Island_Fields__obj::terrainChars,HX_("terrainChars",e8,d0,b5,c1)},
	{ ::hx::fsUnknown, 0, null()}
};
#endif

static void Island_Fields__obj_sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Island_Fields__obj::terrainNames,"terrainNames");
	HX_MARK_MEMBER_NAME(Island_Fields__obj::terrainChars,"terrainChars");
};

#ifdef HXCPP_VISIT_ALLOCS
static void Island_Fields__obj_sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Island_Fields__obj::terrainNames,"terrainNames");
	HX_VISIT_MEMBER_NAME(Island_Fields__obj::terrainChars,"terrainChars");
};

#endif

::hx::Class Island_Fields__obj::__mClass;

static ::String Island_Fields__obj_sStaticFields[] = {
	HX_("terrainNames",d3,c3,86,12),
	HX_("terrainChars",e8,d0,b5,c1),
	::String(null())
};

void Island_Fields__obj::__register()
{
	Island_Fields__obj _hx_dummy;
	Island_Fields__obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("_Island.Island_Fields_",b6,03,c3,e7);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Island_Fields__obj::__GetStatic;
	__mClass->mSetStaticField = &Island_Fields__obj::__SetStatic;
	__mClass->mMarkFunc = Island_Fields__obj_sMarkStatics;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Island_Fields__obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< Island_Fields__obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = Island_Fields__obj_sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Island_Fields__obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Island_Fields__obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

void Island_Fields__obj::__boot()
{
{
            		HX_BEGIN_LOCAL_FUNC_S0(::hx::LocalFunc,_hx_Closure_0) HXARGC(0)
            		 ::haxe::ds::EnumValueMap _hx_run(){
            			HX_GC_STACKFRAME(&_hx_pos_59f5a27777308c25_739_boot)
HXDLIN( 739)			 ::haxe::ds::EnumValueMap _g =  ::haxe::ds::EnumValueMap_obj::__alloc( HX_CTX );
HXDLIN( 739)			_g->set(::Terrain_obj::Grass_dyn(),HX_("Grass",d6,81,17,2d));
HXDLIN( 739)			_g->set(::Terrain_obj::Forest_dyn(),HX_("Forest",fd,00,1d,32));
HXDLIN( 739)			_g->set(::Terrain_obj::Hills_dyn(),HX_("Hills",72,7d,93,ba));
HXDLIN( 739)			return _g;
            		}
            		HX_END_LOCAL_FUNC0(return)

            	HX_STACKFRAME(&_hx_pos_59f5a27777308c25_739_boot)
HXDLIN( 739)		terrainNames = ( ( ::haxe::ds::EnumValueMap)( ::Dynamic(new _hx_Closure_0())()) );
            	}
{
            		HX_BEGIN_LOCAL_FUNC_S0(::hx::LocalFunc,_hx_Closure_0) HXARGC(0)
            		 ::haxe::ds::EnumValueMap _hx_run(){
            			HX_GC_STACKFRAME(&_hx_pos_59f5a27777308c25_743_boot)
HXDLIN( 743)			 ::haxe::ds::EnumValueMap _g =  ::haxe::ds::EnumValueMap_obj::__alloc( HX_CTX );
HXDLIN( 743)			_g->set(::Terrain_obj::Grass_dyn(),HX_(".",2e,00,00,00));
HXDLIN( 743)			_g->set(::Terrain_obj::Forest_dyn(),HX_("&",26,00,00,00));
HXDLIN( 743)			_g->set(::Terrain_obj::Hills_dyn(),HX_("^",5e,00,00,00));
HXDLIN( 743)			return _g;
            		}
            		HX_END_LOCAL_FUNC0(return)

            	HX_STACKFRAME(&_hx_pos_59f5a27777308c25_743_boot)
HXDLIN( 743)		terrainChars = ( ( ::haxe::ds::EnumValueMap)( ::Dynamic(new _hx_Closure_0())()) );
            	}
}

} // end namespace _Island
