#include <hxcpp.h>

#ifndef INCLUDED_Resource
#include <Resource.h>
#endif
#ifndef INCLUDED__Resource_Resource_Fields_
#include <_Resource/Resource_Fields_.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_2027ee6cb0e8b2de_18_boot,"_Resource.Resource_Fields_","boot",0x3bb2c24a,"_Resource.Resource_Fields_.boot","Resource.hx",18,0x8d80f290)
namespace _Resource{

void Resource_Fields__obj::__construct() { }

Dynamic Resource_Fields__obj::__CreateEmpty() { return new Resource_Fields__obj; }

void *Resource_Fields__obj::_hx_vtable = 0;

Dynamic Resource_Fields__obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< Resource_Fields__obj > _hx_result = new Resource_Fields__obj();
	_hx_result->__construct();
	return _hx_result;
}

bool Resource_Fields__obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x17fb05da;
}

 ::haxe::ds::EnumValueMap Resource_Fields__obj::names;


Resource_Fields__obj::Resource_Fields__obj()
{
}

bool Resource_Fields__obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"names") ) { outValue = ( names ); return true; }
	}
	return false;
}

bool Resource_Fields__obj::__SetStatic(const ::String &inName,Dynamic &ioValue,::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 5:
		if (HX_FIELD_EQ(inName,"names") ) { names=ioValue.Cast<  ::haxe::ds::EnumValueMap >(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *Resource_Fields__obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo Resource_Fields__obj_sStaticStorageInfo[] = {
	{::hx::fsObject /*  ::haxe::ds::EnumValueMap */ ,(void *) &Resource_Fields__obj::names,HX_("names",c8,8f,84,96)},
	{ ::hx::fsUnknown, 0, null()}
};
#endif

static void Resource_Fields__obj_sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Resource_Fields__obj::names,"names");
};

#ifdef HXCPP_VISIT_ALLOCS
static void Resource_Fields__obj_sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Resource_Fields__obj::names,"names");
};

#endif

::hx::Class Resource_Fields__obj::__mClass;

static ::String Resource_Fields__obj_sStaticFields[] = {
	HX_("names",c8,8f,84,96),
	::String(null())
};

void Resource_Fields__obj::__register()
{
	Resource_Fields__obj _hx_dummy;
	Resource_Fields__obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("_Resource.Resource_Fields_",56,d9,b5,85);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Resource_Fields__obj::__GetStatic;
	__mClass->mSetStaticField = &Resource_Fields__obj::__SetStatic;
	__mClass->mMarkFunc = Resource_Fields__obj_sMarkStatics;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(Resource_Fields__obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< Resource_Fields__obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = Resource_Fields__obj_sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = Resource_Fields__obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = Resource_Fields__obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

void Resource_Fields__obj::__boot()
{
{
            		HX_BEGIN_LOCAL_FUNC_S0(::hx::LocalFunc,_hx_Closure_0) HXARGC(0)
            		 ::haxe::ds::EnumValueMap _hx_run(){
            			HX_GC_STACKFRAME(&_hx_pos_2027ee6cb0e8b2de_18_boot)
HXDLIN(  18)			 ::haxe::ds::EnumValueMap _g =  ::haxe::ds::EnumValueMap_obj::__alloc( HX_CTX );
HXDLIN(  18)			_g->set(::Resource_obj::Grain_dyn(),HX_("Grain",1b,79,17,2d));
HXDLIN(  18)			_g->set(::Resource_obj::Fish_dyn(),HX_("Fish",b8,00,95,2e));
HXDLIN(  18)			_g->set(::Resource_obj::Wood_dyn(),HX_("Wood",4d,2b,d6,39));
HXDLIN(  18)			_g->set(::Resource_obj::Metal_dyn(),HX_("Metal",e7,91,f5,98));
HXDLIN(  18)			_g->set(::Resource_obj::Tools_dyn(),HX_("Tools",fb,01,5c,a7));
HXDLIN(  18)			_g->set(::Resource_obj::Goods_dyn(),HX_("Goods",76,70,26,2b));
HXDLIN(  18)			return _g;
            		}
            		HX_END_LOCAL_FUNC0(return)

            	HX_STACKFRAME(&_hx_pos_2027ee6cb0e8b2de_18_boot)
HXDLIN(  18)		names = ( ( ::haxe::ds::EnumValueMap)( ::Dynamic(new _hx_Closure_0())()) );
            	}
}

} // end namespace _Resource
