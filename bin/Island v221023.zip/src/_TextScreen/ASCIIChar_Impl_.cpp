#include <hxcpp.h>

#ifndef INCLUDED__TextScreen_ASCIIChar_Impl_
#include <_TextScreen/ASCIIChar_Impl_.h>
#endif

HX_LOCAL_STACK_FRAME(_hx_pos_73f068f63b95a019_390__new,"_TextScreen.ASCIIChar_Impl_","_new",0xfa28519e,"_TextScreen.ASCIIChar_Impl_._new","TextScreen.hx",390,0x3762d845)
HX_LOCAL_STACK_FRAME(_hx_pos_73f068f63b95a019_396_fromInt,"_TextScreen.ASCIIChar_Impl_","fromInt",0x39b12588,"_TextScreen.ASCIIChar_Impl_.fromInt","TextScreen.hx",396,0x3762d845)
namespace _TextScreen{

void ASCIIChar_Impl__obj::__construct() { }

Dynamic ASCIIChar_Impl__obj::__CreateEmpty() { return new ASCIIChar_Impl__obj; }

void *ASCIIChar_Impl__obj::_hx_vtable = 0;

Dynamic ASCIIChar_Impl__obj::__Create(::hx::DynamicArray inArgs)
{
	::hx::ObjectPtr< ASCIIChar_Impl__obj > _hx_result = new ASCIIChar_Impl__obj();
	_hx_result->__construct();
	return _hx_result;
}

bool ASCIIChar_Impl__obj::_hx_isInstanceOf(int inClassId) {
	return inClassId==(int)0x00000001 || inClassId==(int)0x1160c67b;
}

::String ASCIIChar_Impl__obj::_new(::String str){
            	HX_STACKFRAME(&_hx_pos_73f068f63b95a019_390__new)
HXDLIN( 390)		::String this1 = str;
HXDLIN( 390)		return this1;
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(ASCIIChar_Impl__obj,_new,return )

::String ASCIIChar_Impl__obj::fromInt(int i){
            	HX_STACKFRAME(&_hx_pos_73f068f63b95a019_396_fromInt)
HXDLIN( 396)		switch((int)(i)){
            			case (int)32: {
HXLINE( 398)				::String this1 = HX_(" ",20,00,00,00);
HXDLIN( 398)				return this1;
            			}
            			break;
            			case (int)48: {
HXLINE( 400)				::String this1 = HX_("0",30,00,00,00);
HXDLIN( 400)				return this1;
            			}
            			break;
            			case (int)49: {
HXLINE( 402)				::String this1 = HX_("1",31,00,00,00);
HXDLIN( 402)				return this1;
            			}
            			break;
            			case (int)50: {
HXLINE( 404)				::String this1 = HX_("2",32,00,00,00);
HXDLIN( 404)				return this1;
            			}
            			break;
            			case (int)51: {
HXLINE( 406)				::String this1 = HX_("3",33,00,00,00);
HXDLIN( 406)				return this1;
            			}
            			break;
            			case (int)52: {
HXLINE( 408)				::String this1 = HX_("4",34,00,00,00);
HXDLIN( 408)				return this1;
            			}
            			break;
            			case (int)53: {
HXLINE( 410)				::String this1 = HX_("5",35,00,00,00);
HXDLIN( 410)				return this1;
            			}
            			break;
            			case (int)54: {
HXLINE( 412)				::String this1 = HX_("6",36,00,00,00);
HXDLIN( 412)				return this1;
            			}
            			break;
            			case (int)55: {
HXLINE( 414)				::String this1 = HX_("7",37,00,00,00);
HXDLIN( 414)				return this1;
            			}
            			break;
            			case (int)56: {
HXLINE( 416)				::String this1 = HX_("8",38,00,00,00);
HXDLIN( 416)				return this1;
            			}
            			break;
            			case (int)57: {
HXLINE( 418)				::String this1 = HX_("9",39,00,00,00);
HXDLIN( 418)				return this1;
            			}
            			break;
            			case (int)65: {
HXLINE( 420)				::String this1 = HX_("A",41,00,00,00);
HXDLIN( 420)				return this1;
            			}
            			break;
            			case (int)66: {
HXLINE( 422)				::String this1 = HX_("B",42,00,00,00);
HXDLIN( 422)				return this1;
            			}
            			break;
            			case (int)67: {
HXLINE( 424)				::String this1 = HX_("C",43,00,00,00);
HXDLIN( 424)				return this1;
            			}
            			break;
            			case (int)68: {
HXLINE( 426)				::String this1 = HX_("D",44,00,00,00);
HXDLIN( 426)				return this1;
            			}
            			break;
            			case (int)69: {
HXLINE( 428)				::String this1 = HX_("E",45,00,00,00);
HXDLIN( 428)				return this1;
            			}
            			break;
            			case (int)70: {
HXLINE( 430)				::String this1 = HX_("F",46,00,00,00);
HXDLIN( 430)				return this1;
            			}
            			break;
            			case (int)71: {
HXLINE( 432)				::String this1 = HX_("G",47,00,00,00);
HXDLIN( 432)				return this1;
            			}
            			break;
            			case (int)72: {
HXLINE( 434)				::String this1 = HX_("H",48,00,00,00);
HXDLIN( 434)				return this1;
            			}
            			break;
            			case (int)73: {
HXLINE( 436)				::String this1 = HX_("I",49,00,00,00);
HXDLIN( 436)				return this1;
            			}
            			break;
            			case (int)74: {
HXLINE( 438)				::String this1 = HX_("J",4a,00,00,00);
HXDLIN( 438)				return this1;
            			}
            			break;
            			case (int)75: {
HXLINE( 440)				::String this1 = HX_("K",4b,00,00,00);
HXDLIN( 440)				return this1;
            			}
            			break;
            			case (int)76: {
HXLINE( 442)				::String this1 = HX_("L",4c,00,00,00);
HXDLIN( 442)				return this1;
            			}
            			break;
            			case (int)77: {
HXLINE( 444)				::String this1 = HX_("M",4d,00,00,00);
HXDLIN( 444)				return this1;
            			}
            			break;
            			case (int)78: {
HXLINE( 446)				::String this1 = HX_("N",4e,00,00,00);
HXDLIN( 446)				return this1;
            			}
            			break;
            			case (int)79: {
HXLINE( 448)				::String this1 = HX_("O",4f,00,00,00);
HXDLIN( 448)				return this1;
            			}
            			break;
            			case (int)80: {
HXLINE( 450)				::String this1 = HX_("P",50,00,00,00);
HXDLIN( 450)				return this1;
            			}
            			break;
            			case (int)81: {
HXLINE( 452)				::String this1 = HX_("Q",51,00,00,00);
HXDLIN( 452)				return this1;
            			}
            			break;
            			case (int)82: {
HXLINE( 454)				::String this1 = HX_("R",52,00,00,00);
HXDLIN( 454)				return this1;
            			}
            			break;
            			case (int)83: {
HXLINE( 456)				::String this1 = HX_("S",53,00,00,00);
HXDLIN( 456)				return this1;
            			}
            			break;
            			case (int)84: {
HXLINE( 458)				::String this1 = HX_("T",54,00,00,00);
HXDLIN( 458)				return this1;
            			}
            			break;
            			case (int)85: {
HXLINE( 460)				::String this1 = HX_("U",55,00,00,00);
HXDLIN( 460)				return this1;
            			}
            			break;
            			case (int)86: {
HXLINE( 462)				::String this1 = HX_("V",56,00,00,00);
HXDLIN( 462)				return this1;
            			}
            			break;
            			case (int)87: {
HXLINE( 464)				::String this1 = HX_("W",57,00,00,00);
HXDLIN( 464)				return this1;
            			}
            			break;
            			case (int)88: {
HXLINE( 466)				::String this1 = HX_("X",58,00,00,00);
HXDLIN( 466)				return this1;
            			}
            			break;
            			case (int)89: {
HXLINE( 468)				::String this1 = HX_("Y",59,00,00,00);
HXDLIN( 468)				return this1;
            			}
            			break;
            			case (int)90: {
HXLINE( 470)				::String this1 = HX_("Z",5a,00,00,00);
HXDLIN( 470)				return this1;
            			}
            			break;
            			case (int)91: {
HXLINE( 472)				::String this1 = HX_("[",5b,00,00,00);
HXDLIN( 472)				return this1;
            			}
            			break;
            			case (int)92: {
HXLINE( 474)				::String this1 = HX_("\\",5c,00,00,00);
HXDLIN( 474)				return this1;
            			}
            			break;
            			case (int)93: {
HXLINE( 476)				::String this1 = HX_("]",5d,00,00,00);
HXDLIN( 476)				return this1;
            			}
            			break;
            			case (int)94: {
HXLINE( 478)				::String this1 = HX_("^",5e,00,00,00);
HXDLIN( 478)				return this1;
            			}
            			break;
            			case (int)95: {
HXLINE( 480)				::String this1 = HX_("_",5f,00,00,00);
HXDLIN( 480)				return this1;
            			}
            			break;
            			case (int)96: {
HXLINE( 482)				::String this1 = HX_("`",60,00,00,00);
HXDLIN( 482)				return this1;
            			}
            			break;
            			case (int)97: {
HXLINE( 484)				::String this1 = HX_("a",61,00,00,00);
HXDLIN( 484)				return this1;
            			}
            			break;
            			case (int)98: {
HXLINE( 486)				::String this1 = HX_("b",62,00,00,00);
HXDLIN( 486)				return this1;
            			}
            			break;
            			case (int)99: {
HXLINE( 488)				::String this1 = HX_("c",63,00,00,00);
HXDLIN( 488)				return this1;
            			}
            			break;
            			case (int)100: {
HXLINE( 490)				::String this1 = HX_("d",64,00,00,00);
HXDLIN( 490)				return this1;
            			}
            			break;
            			case (int)101: {
HXLINE( 492)				::String this1 = HX_("e",65,00,00,00);
HXDLIN( 492)				return this1;
            			}
            			break;
            			case (int)102: {
HXLINE( 494)				::String this1 = HX_("f",66,00,00,00);
HXDLIN( 494)				return this1;
            			}
            			break;
            			case (int)103: {
HXLINE( 496)				::String this1 = HX_("g",67,00,00,00);
HXDLIN( 496)				return this1;
            			}
            			break;
            			case (int)104: {
HXLINE( 498)				::String this1 = HX_("h",68,00,00,00);
HXDLIN( 498)				return this1;
            			}
            			break;
            			case (int)105: {
HXLINE( 500)				::String this1 = HX_("i",69,00,00,00);
HXDLIN( 500)				return this1;
            			}
            			break;
            			case (int)106: {
HXLINE( 502)				::String this1 = HX_("j",6a,00,00,00);
HXDLIN( 502)				return this1;
            			}
            			break;
            			case (int)107: {
HXLINE( 504)				::String this1 = HX_("k",6b,00,00,00);
HXDLIN( 504)				return this1;
            			}
            			break;
            			case (int)108: {
HXLINE( 506)				::String this1 = HX_("l",6c,00,00,00);
HXDLIN( 506)				return this1;
            			}
            			break;
            			case (int)109: {
HXLINE( 508)				::String this1 = HX_("m",6d,00,00,00);
HXDLIN( 508)				return this1;
            			}
            			break;
            			case (int)110: {
HXLINE( 510)				::String this1 = HX_("n",6e,00,00,00);
HXDLIN( 510)				return this1;
            			}
            			break;
            			case (int)111: {
HXLINE( 512)				::String this1 = HX_("o",6f,00,00,00);
HXDLIN( 512)				return this1;
            			}
            			break;
            			case (int)112: {
HXLINE( 514)				::String this1 = HX_("p",70,00,00,00);
HXDLIN( 514)				return this1;
            			}
            			break;
            			case (int)113: {
HXLINE( 516)				::String this1 = HX_("q",71,00,00,00);
HXDLIN( 516)				return this1;
            			}
            			break;
            			case (int)114: {
HXLINE( 518)				::String this1 = HX_("r",72,00,00,00);
HXDLIN( 518)				return this1;
            			}
            			break;
            			case (int)115: {
HXLINE( 520)				::String this1 = HX_("s",73,00,00,00);
HXDLIN( 520)				return this1;
            			}
            			break;
            			case (int)116: {
HXLINE( 522)				::String this1 = HX_("t",74,00,00,00);
HXDLIN( 522)				return this1;
            			}
            			break;
            			case (int)117: {
HXLINE( 524)				::String this1 = HX_("u",75,00,00,00);
HXDLIN( 524)				return this1;
            			}
            			break;
            			case (int)118: {
HXLINE( 526)				::String this1 = HX_("v",76,00,00,00);
HXDLIN( 526)				return this1;
            			}
            			break;
            			case (int)119: {
HXLINE( 528)				::String this1 = HX_("w",77,00,00,00);
HXDLIN( 528)				return this1;
            			}
            			break;
            			case (int)120: {
HXLINE( 530)				::String this1 = HX_("x",78,00,00,00);
HXDLIN( 530)				return this1;
            			}
            			break;
            			case (int)121: {
HXLINE( 532)				::String this1 = HX_("y",79,00,00,00);
HXDLIN( 532)				return this1;
            			}
            			break;
            			case (int)122: {
HXLINE( 534)				::String this1 = HX_("z",7a,00,00,00);
HXDLIN( 534)				return this1;
            			}
            			break;
            			default:{
HXLINE( 536)				::String this1 = HX_("other",d0,66,76,36);
HXDLIN( 536)				return this1;
            			}
            		}
HXLINE( 396)		return null();
            	}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(ASCIIChar_Impl__obj,fromInt,return )


ASCIIChar_Impl__obj::ASCIIChar_Impl__obj()
{
}

bool ASCIIChar_Impl__obj::__GetStatic(const ::String &inName, Dynamic &outValue, ::hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"_new") ) { outValue = _new_dyn(); return true; }
		break;
	case 7:
		if (HX_FIELD_EQ(inName,"fromInt") ) { outValue = fromInt_dyn(); return true; }
	}
	return false;
}

#ifdef HXCPP_SCRIPTABLE
static ::hx::StorageInfo *ASCIIChar_Impl__obj_sMemberStorageInfo = 0;
static ::hx::StaticInfo *ASCIIChar_Impl__obj_sStaticStorageInfo = 0;
#endif

::hx::Class ASCIIChar_Impl__obj::__mClass;

static ::String ASCIIChar_Impl__obj_sStaticFields[] = {
	HX_("_new",61,15,1f,3f),
	HX_("fromInt",a5,dd,fa,57),
	::String(null())
};

void ASCIIChar_Impl__obj::__register()
{
	ASCIIChar_Impl__obj _hx_dummy;
	ASCIIChar_Impl__obj::_hx_vtable = *(void **)&_hx_dummy;
	::hx::Static(__mClass) = new ::hx::Class_obj();
	__mClass->mName = HX_("_TextScreen.ASCIIChar_Impl_",51,8d,6e,c7);
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &ASCIIChar_Impl__obj::__GetStatic;
	__mClass->mSetStaticField = &::hx::Class_obj::SetNoStaticField;
	__mClass->mStatics = ::hx::Class_obj::dupFunctions(ASCIIChar_Impl__obj_sStaticFields);
	__mClass->mMembers = ::hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = ::hx::TCanCast< ASCIIChar_Impl__obj >;
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = ASCIIChar_Impl__obj_sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = ASCIIChar_Impl__obj_sStaticStorageInfo;
#endif
	::hx::_hx_RegisterClass(__mClass->mName, __mClass);
}

} // end namespace _TextScreen
