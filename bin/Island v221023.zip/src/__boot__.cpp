#include <hxcpp.h>

#ifndef INCLUDED_Resource
#include <Resource.h>
#endif
#ifndef INCLUDED_Terrain
#include <Terrain.h>
#endif
#ifndef INCLUDED_MenuState
#include <MenuState.h>
#endif
#ifndef INCLUDED_GenerationType
#include <GenerationType.h>
#endif
#ifndef INCLUDED_Direction
#include <Direction.h>
#endif
#ifndef INCLUDED_Building
#include <Building.h>
#endif
#ifndef INCLUDED__Resource_Resource_Fields_
#include <_Resource/Resource_Fields_.h>
#endif
#ifndef INCLUDED__Island_Island_Fields_
#include <_Island/Island_Fields_.h>
#endif
#ifndef INCLUDED_Island
#include <Island.h>
#endif
#ifndef INCLUDED__Building_Building_Fields_
#include <_Building/Building_Fields_.h>
#endif
#ifndef INCLUDED_haxe_iterators_ArrayIterator
#include <haxe/iterators/ArrayIterator.h>
#endif
#ifndef INCLUDED_haxe_ds_StringMap
#include <haxe/ds/StringMap.h>
#endif
#ifndef INCLUDED_haxe_ds__List_ListNode
#include <haxe/ds/_List/ListNode.h>
#endif
#ifndef INCLUDED_haxe_ds_List
#include <haxe/ds/List.h>
#endif
#ifndef INCLUDED_haxe_ds_EnumValueMap
#include <haxe/ds/EnumValueMap.h>
#endif
#ifndef INCLUDED_haxe_ds_TreeNode
#include <haxe/ds/TreeNode.h>
#endif
#ifndef INCLUDED_haxe_ds_BalancedTree
#include <haxe/ds/BalancedTree.h>
#endif
#ifndef INCLUDED_haxe_ValueException
#include <haxe/ValueException.h>
#endif
#ifndef INCLUDED_haxe_NativeStackTrace
#include <haxe/NativeStackTrace.h>
#endif
#ifndef INCLUDED_haxe_Exception
#include <haxe/Exception.h>
#endif
#ifndef INCLUDED_haxe_IMap
#include <haxe/IMap.h>
#endif
#ifndef INCLUDED_Vector2D
#include <Vector2D.h>
#endif
#ifndef INCLUDED_DescIter
#include <DescIter.h>
#endif
#ifndef INCLUDED_Utils
#include <Utils.h>
#endif
#ifndef INCLUDED_Type
#include <Type.h>
#endif
#ifndef INCLUDED__TextScreen_ASCIIChar_Impl_
#include <_TextScreen/ASCIIChar_Impl_.h>
#endif
#ifndef INCLUDED_MenuOption
#include <MenuOption.h>
#endif
#ifndef INCLUDED_TextMenuType
#include <TextMenuType.h>
#endif
#ifndef INCLUDED_TextMenu
#include <TextMenu.h>
#endif
#ifndef INCLUDED_TextLog
#include <TextLog.h>
#endif
#ifndef INCLUDED_ChildWindowInfo
#include <ChildWindowInfo.h>
#endif
#ifndef INCLUDED_ColoredChar
#include <ColoredChar.h>
#endif
#ifndef INCLUDED_Sys
#include <Sys.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_Pile
#include <Pile.h>
#endif
#ifndef INCLUDED_Reflect
#include <Reflect.h>
#endif
#ifndef INCLUDED_Main
#include <Main.h>
#endif
#ifndef INCLUDED_IslandCell
#include <IslandCell.h>
#endif
#ifndef INCLUDED_Point2D
#include <Point2D.h>
#endif
#ifndef INCLUDED_Cell
#include <Cell.h>
#endif
#ifndef INCLUDED_TextWindow
#include <TextWindow.h>
#endif
#ifndef INCLUDED_TextScreen
#include <TextScreen.h>
#endif
#ifndef INCLUDED_HexGrid
#include <HexGrid.h>
#endif
#ifndef INCLUDED_Grid
#include <Grid.h>
#endif

void __files__boot();

void __boot_all()
{
__files__boot();
::hx::RegisterResources( ::hx::GetResources() );
::Resource_obj::__register();
::Terrain_obj::__register();
::MenuState_obj::__register();
::GenerationType_obj::__register();
::Direction_obj::__register();
::Building_obj::__register();
::_Resource::Resource_Fields__obj::__register();
::_Island::Island_Fields__obj::__register();
::Island_obj::__register();
::_Building::Building_Fields__obj::__register();
::haxe::iterators::ArrayIterator_obj::__register();
::haxe::ds::StringMap_obj::__register();
::haxe::ds::_List::ListNode_obj::__register();
::haxe::ds::List_obj::__register();
::haxe::ds::EnumValueMap_obj::__register();
::haxe::ds::TreeNode_obj::__register();
::haxe::ds::BalancedTree_obj::__register();
::haxe::ValueException_obj::__register();
::haxe::NativeStackTrace_obj::__register();
::haxe::Exception_obj::__register();
::haxe::IMap_obj::__register();
::Vector2D_obj::__register();
::DescIter_obj::__register();
::Utils_obj::__register();
::Type_obj::__register();
::_TextScreen::ASCIIChar_Impl__obj::__register();
::MenuOption_obj::__register();
::TextMenuType_obj::__register();
::TextMenu_obj::__register();
::TextLog_obj::__register();
::ChildWindowInfo_obj::__register();
::ColoredChar_obj::__register();
::Sys_obj::__register();
::Std_obj::__register();
::Pile_obj::__register();
::Reflect_obj::__register();
::Main_obj::__register();
::IslandCell_obj::__register();
::Point2D_obj::__register();
::Cell_obj::__register();
::TextWindow_obj::__register();
::TextScreen_obj::__register();
::HexGrid_obj::__register();
::Grid_obj::__register();
::Resource_obj::__boot();
::Terrain_obj::__boot();
::MenuState_obj::__boot();
::GenerationType_obj::__boot();
::Direction_obj::__boot();
::Building_obj::__boot();
::_Building::Building_Fields__obj::__boot();
::Island_obj::__boot();
::_Island::Island_Fields__obj::__boot();
::_Resource::Resource_Fields__obj::__boot();
}

