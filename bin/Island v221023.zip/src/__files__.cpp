#include <hxcpp.h>

namespace hx {
const char *__hxcpp_all_files[] = {
#ifdef HXCPP_DEBUGGER
"?",
"Building.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/Reflect.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/Std.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/Sys.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/Type.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/haxe/Exception.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/haxe/NativeStackTrace.hx",
"D:\\HaxeToolkit\\haxe\\std/cpp/_std/haxe/ds/StringMap.hx",
"D:\\HaxeToolkit\\haxe\\std/haxe/ValueException.hx",
"D:\\HaxeToolkit\\haxe\\std/haxe/ds/BalancedTree.hx",
"D:\\HaxeToolkit\\haxe\\std/haxe/ds/EnumValueMap.hx",
"D:\\HaxeToolkit\\haxe\\std/haxe/ds/List.hx",
"D:\\HaxeToolkit\\haxe\\std/haxe/iterators/ArrayIterator.hx",
"Grid.hx",
"Island.hx",
"Main.hx",
"Resource.hx",
"TextScreen.hx",
"Utils.hx",
#endif
 0 };

const char *__hxcpp_all_files_fullpath[] = {
#ifdef HXCPP_DEBUGGER
"D:\\Haxe Projects\\Island\\?",
"D:\\Haxe Projects\\Island\\src\\Building.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\Reflect.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\Std.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\Sys.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\Type.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\haxe\\Exception.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\haxe\\NativeStackTrace.hx",
"D:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\haxe\\ds\\StringMap.hx",
"D:\\HaxeToolkit\\haxe\\std\\haxe\\ValueException.hx",
"D:\\HaxeToolkit\\haxe\\std\\haxe\\ds\\BalancedTree.hx",
"D:\\HaxeToolkit\\haxe\\std\\haxe\\ds\\EnumValueMap.hx",
"D:\\HaxeToolkit\\haxe\\std\\haxe\\ds\\List.hx",
"D:\\HaxeToolkit\\haxe\\std\\haxe\\iterators\\ArrayIterator.hx",
"D:\\Haxe Projects\\Island\\src\\Grid.hx",
"D:\\Haxe Projects\\Island\\src\\Island.hx",
"D:\\Haxe Projects\\Island\\src\\Main.hx",
"D:\\Haxe Projects\\Island\\src\\Resource.hx",
"D:\\Haxe Projects\\Island\\src\\TextScreen.hx",
"D:\\Haxe Projects\\Island\\src\\Utils.hx",
#endif
 0 };

const char *__hxcpp_all_classes[] = {
#ifdef HXCPP_DEBUGGER
"_Building.Building_Fields_",
"Grid",
"HexGrid",
"TextScreen",
"TextWindow",
"Cell",
"Point2D",
"Island",
"IslandCell",
"_Island.Island_Fields_",
"Main",
"Reflect",
"Pile",
"_Resource.Resource_Fields_",
"Std",
"Sys",
"ColoredChar",
"ChildWindowInfo",
"TextLog",
"TextMenu",
"TextMenuType",
"MenuOption",
"_TextScreen.ASCIIChar_Impl_",
"Type",
"Utils",
"DescIter",
"Vector2D",
"haxe.Exception",
"haxe.NativeStackTrace",
"haxe.ValueException",
"haxe.ds.BalancedTree",
"haxe.ds.TreeNode",
"haxe.ds.EnumValueMap",
"haxe.ds.List",
"haxe.ds._List.ListNode",
"haxe.ds.StringMap",
"haxe.iterators.ArrayIterator",
#endif
 0 };
} // namespace hx
void __files__boot() { __hxcpp_set_debugger_info(::hx::__hxcpp_all_classes, ::hx::__hxcpp_all_files_fullpath); }
