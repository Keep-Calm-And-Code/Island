#include <hxcpp.h>

namespace hx {
}

::hx::Resource __Resources[] = {
	{ ::String(null()),0,0 }
};

namespace hx { Resource *GetResources() { return __Resources; } }
